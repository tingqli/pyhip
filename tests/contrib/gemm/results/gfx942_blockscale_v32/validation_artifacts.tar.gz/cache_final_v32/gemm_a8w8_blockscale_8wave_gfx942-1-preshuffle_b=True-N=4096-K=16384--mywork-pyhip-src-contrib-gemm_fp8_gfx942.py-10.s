	.amdgcn_target "amdgcn-amd-amdhsa--gfx942"
	.amdhsa_code_object_version 6
	.text
	.protected	_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i ; -- Begin function _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
	.globl	_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
	.p2align	8
	.type	_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i,@function
_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i: ; @_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
; %bb.0:
	;;#ASMSTART
	 ; blockIdx.x s2, blockIdx.y s3, blockIdx.z s4
	;;#ASMEND
	;;#ASMSTART
	
_jit_main:	 ;BB#0 predecessors:[] successors:[_bb_no_name_1,_if_else_28_0]
	s_load_dwordx2 s[6:7],s[0:1],0x0  ; # asmjit.py:4434 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'pA's[6:7]    s:7(7) v:1(0) a:0(0)    sid:0 pA,kargs,0,;	s[6:7] = load_dwordx2_from(s[0:1] + 0x0, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_load_dwordx2 s[8:9],s[0:1],0x8  ; # asmjit.py:4434 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'pB's[8:9]    s:9(9) v:1(0) a:0(0)    sid:1 pB,kargs,8,;	s[8:9] = load_dwordx2_from(s[0:1] + 0x8, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_load_dwordx2 s[10:11],s[0:1],0x10  ; # asmjit.py:4434 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'pC's[10:11]    s:11(11) v:1(0) a:0(0)    sid:2 pC,kargs,16,;	s[10:11] = load_dwordx2_from(s[0:1] + 0x10, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_load_dwordx2 s[12:13],s[0:1],0x18  ; # asmjit.py:4434 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'pScaleA's[12:13]    s:13(13) v:1(0) a:0(0)    sid:3 pScaleA,kargs,24,;	s[12:13] = load_dwordx2_from(s[0:1] + 0x18, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_load_dwordx2 s[14:15],s[0:1],0x20  ; # asmjit.py:4434 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'pScaleB's[14:15]    s:15(15) v:1(0) a:0(0)    sid:4 pScaleB,kargs,32,;	s[14:15] = load_dwordx2_from(s[0:1] + 0x20, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_load_dword s5,s[0:1],0x28  ; # asmjit.py:4443 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'M's5    s:16(15) v:1(0) a:0(0)    sid:5 M,kargs,40,;	s5 = load_dword_from(s[0:1] + 0x28, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	v_lshrrev_b32 v1,0x6,v0  ; # asmjit.py:4273 asmjit.py:4461 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'idst'v1    s:16(15) v:2(1) a:0(0)    sid:6 idst,6,threadIdx.x,;	v1.b32 = v0 >> 0x6[4:0];
	s_nop 0x1  ; #   sid:7 1,                        ;	s_nop  wait 2 cycles
	v_readfirstlane_b32 s16,v1  ; # asmjit.py:4273 asmjit.py:4461 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 free 'idst'v1 alloc '_warp_id's16    s:17(16) v:1(0) a:0(0)    sid:8 _warp_id,idst,
	v_and_b32 v1,0x3f,v0  ; # asmjit.py:4280 asmjit.py:4462 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc '_lane_id'v1    s:17(16) v:2(1) a:0(0)    sid:9 _lane_id,63,threadIdx.x,;	v1.u32 = (0x3f & v0.u32)
	s_waitcnt  lgkmcnt(0) ; # asmjit.py:4465 asmjit.py:4501 test_a8w8_f32_blockscale.py:228   sid:10 
	s_add_i32 s17,0x100,s5  ; # loaders.py:19 alloc 'src0_gprs's17    s:18(17) v:2(1) a:0(0)    sid:11 src0_gprs,256,M,;	s17.i32 = 0x100 + s5; scc=overflow_or_carry
	s_sub_i32 s17,s17,0x1  ; # loaders.py:19 free 'src0_gprs's17 alloc 'src0_gprs's17    s:18(17) v:2(1) a:0(0)    sid:12 src0_gprs,src0_gprs,1,;	s17.i32 = (s17.i32 - 0x1.i32); scc=(overflow or carry-out of last arith);
	s_ashr_i32 s17,s17,0x8  ; # loaders.py:19 free 'src0_gprs's17 alloc 'M0's17    s:18(17) v:2(1) a:0(0)    sid:13 M0,src0_gprs,8,
	s_lshl_b32 s18,s17,0x4  ; # loaders.py:22 alloc 'src1_gprs's18    s:19(18) v:2(1) a:0(0)    sid:14 src1_gprs,M0,4,;	s18 = s17 << 0x4[4:0]; scc=(s18!=0);
	s_add_i32 s18,0x8,s18  ; # loaders.py:22 free 'src1_gprs's18 alloc 'src0_gprs's18    s:19(18) v:2(1) a:0(0)    sid:15 src0_gprs,8,src1_gprs,;	s18.i32 = 0x8 + s18; scc=overflow_or_carry
	s_sub_i32 s18,s18,0x1  ; # loaders.py:22 free 'src0_gprs's18 alloc 'src0_gprs's18    s:19(18) v:2(1) a:0(0)    sid:16 src0_gprs,src0_gprs,1,;	s18.i32 = (s18.i32 - 0x1.i32); scc=(overflow or carry-out of last arith);
	s_ashr_i32 s18,s18,0x3  ; # loaders.py:22 free 'src0_gprs's18 alloc 'src0_gprs's18    s:19(18) v:2(1) a:0(0)    sid:17 src0_gprs,src0_gprs,3,
	s_lshl_b32 s18,s18,0x3  ; # loaders.py:22 free 'src0_gprs's18 alloc 'src0_gprs's18    s:19(18) v:2(1) a:0(0)    sid:18 src0_gprs,src0_gprs,3,;	s18 = s18 << 0x3[4:0]; scc=(s18!=0);
	s_lshl_b32 s19,s17,0x4  ; # loaders.py:22 alloc 'src1_gprs's19    s:20(19) v:2(1) a:0(0)    sid:19 src1_gprs,M0,4,;	s19 = s17 << 0x4[4:0]; scc=(s19!=0);
	s_sub_i32 s18,s18,s19  ; # loaders.py:22 free 'src0_gprs's18 free 'src1_gprs's19 alloc 'src1_gprs's18    s:19(18) v:2(1) a:0(0)    sid:20 src1_gprs,src0_gprs,src1_gprs,;	s18.i32 = (s18.i32 - s19.i32); scc=(overflow or carry-out of last arith);
	s_sub_i32 s18,0x8,s18  ; # loaders.py:22 free 'src1_gprs's18 alloc 'big_group_num's18    s:19(18) v:2(1) a:0(0)    sid:21 big_group_num,8,src1_gprs,;	s18.i32 = (0x8.i32 - s18.i32); scc=(overflow or carry-out of last arith);
	s_lshr_b32 s19,s2,0x3  ; # loaders.py:23 alloc 'group_id_y's19    s:20(19) v:2(1) a:0(0)    sid:22 group_id_y,blockIdx.x,3,
	s_lshl_b32 s20,s19,0x3  ; # loaders.py:24 alloc 'src1_gprs's20    s:21(20) v:2(1) a:0(0)    sid:23 src1_gprs,group_id_y,3,;	s20 = s19 << 0x3[4:0]; scc=(s20!=0);
	s_sub_u32 s20,s2,s20  ; # loaders.py:24 free 'src1_gprs's20 alloc 'group_id_x's20    s:21(20) v:2(1) a:0(0)    sid:24 group_id_x,blockIdx.x,src1_gprs,;	s20.u32 = (s2.u32 - s20.u32); scc=(overflow or carry-out of last arith);
	s_lshl_b32 s21,s17,0x4  ; # loaders.py:26 alloc 'src1_gprs's21    s:22(21) v:2(1) a:0(0)    sid:25 src1_gprs,M0,4,;	s21 = s17 << 0x4[4:0]; scc=(s21!=0);
	s_add_u32 s21,0x8,s21  ; # loaders.py:26 free 'src1_gprs's21 alloc 'src0_gprs's21    s:22(21) v:2(1) a:0(0)    sid:26 src0_gprs,8,src1_gprs,;	s21.u32 = 0x8 + s21; scc=overflow_or_carry
	s_sub_u32 s21,s21,0x1  ; # loaders.py:26 free 'src0_gprs's21 alloc 'src0_gprs's21    s:22(21) v:2(1) a:0(0)    sid:27 src0_gprs,src0_gprs,1,;	s21.u32 = (s21.u32 - 0x1.u32); scc=(overflow or carry-out of last arith);
	s_lshr_b32 s21,s21,0x3  ; # loaders.py:26 free 'src0_gprs's21 alloc 'src1_gprs's21    s:22(21) v:2(1) a:0(0)    sid:28 src1_gprs,src0_gprs,3,
	s_mul_i32 s21,s20,s21  ; # loaders.py:26 free 'src1_gprs's21 alloc 'src0_gprs's21    s:22(21) v:2(1) a:0(0)    sid:29 src0_gprs,group_id_x,src1_gprs,;	s21 = s20 * s21
	s_add_u32 s19,s21,s19  ; # loaders.py:26 free 'group_id_y's19 free 'src0_gprs's21 alloc 'remap_block_1d_id's19    s:21(20) v:2(1) a:0(0)    sid:30 remap_block_1d_id,src0_gprs,group_id_y,;	s19.u32 = s21 + s19; scc=overflow_or_carry
	s_cmp_gt_u32 s20,s18  ; # asmjit.py:1421 contextlib.py:137   sid:31 group_id_x,big_group_num,;	scc = (s20.u32 > s18.u32)
	s_cbranch_scc0  _if_else_28_0 ; # asmjit.py:1367 asmjit.py:1421 contextlib.py:137   sid:32;	jump if scc is 0 (scc == 0)
_bb_no_name_1:	 ;BB#1 predecessors:[_jit_main] successors:[_if_else_28_0]
	s_sub_u32 s18,s18,s20  ; # loaders.py:29 free 'big_group_num's18 free 'group_id_x's20 alloc 'src1_gprs's18    s:20(19) v:2(1) a:0(0)    sid:33 src1_gprs,big_group_num,group_id_x,;	s18.u32 = (s18.u32 - s20.u32); scc=(overflow or carry-out of last arith);
	s_add_u32 s19,s19,s18  ; # loaders.py:29 free 'src1_gprs's18   sid:34 remap_block_1d_id,remap_block_1d_id,src1_gprs,;	s19.u32 = s19 + s18; scc=overflow_or_carry
_if_else_28_0:	 ;BB#2 predecessors:[_bb_no_name_1,_jit_main] successors:[_bb_no_name_3,_if_else_218_1]
	s_lshr_b32 s18,s19,0x4  ; # loaders.py:31 alloc 'idx_M0's18    s:20(19) v:2(1) a:0(0)    sid:35 idx_M0,remap_block_1d_id,4,
	s_lshl_b32 s20,s18,0x4  ; # loaders.py:32 alloc 'src1_gprs's20    s:21(20) v:2(1) a:0(0)    sid:36 src1_gprs,idx_M0,4,;	s20 = s18 << 0x4[4:0]; scc=(s20!=0);
	s_sub_u32 s19,s19,s20  ; # loaders.py:32 free 'remap_block_1d_id's19 free 'src1_gprs's20 alloc 'idx_N0's19    s:20(19) v:2(1) a:0(0)    sid:37 idx_N0,remap_block_1d_id,src1_gprs,;	s19.u32 = (s19.u32 - s20.u32); scc=(overflow or carry-out of last arith);
	s_ashr_i32 s20,s17,0x3  ; # loaders.py:34 alloc 'M0_tmp's20    s:21(20) v:2(1) a:0(0)    sid:38 M0_tmp,M0,3,
	s_lshl_b32 s20,s20,0x3  ; # loaders.py:35 free 'M0_tmp's20 alloc 'src1_gprs's20    s:21(20) v:2(1) a:0(0)    sid:39 src1_gprs,M0_tmp,3,;	s20 = s20 << 0x3[4:0]; scc=(s20!=0);
	s_sub_i32 s20,s17,s20  ; # loaders.py:35 free 'src1_gprs's20 alloc 'M0_mod_M01's20    s:21(20) v:2(1) a:0(0)    sid:40 M0_mod_M01,M0,src1_gprs,;	s20.i32 = (s17.i32 - s20.i32); scc=(overflow or carry-out of last arith);
	s_sub_u32 s17,s17,s20  ; # loaders.py:39 free 'M0's17 alloc 'src1_gprs's17    s:21(20) v:2(1) a:0(0)    sid:41 src1_gprs,M0,M0_mod_M01,;	s17.u32 = (s17.u32 - s20.u32); scc=(overflow or carry-out of last arith);
	s_cmp_lt_u32 s18,s17  ; # loaders.py:39 free 'src1_gprs's17   sid:42 idx_M0,src1_gprs,;	scc = (s18.u32 < s17.u32)
	s_cselect_b32 s17,0x8,s20  ; # loaders.py:40 free 'M0_mod_M01's20 alloc 'M01_adapt's17    s:20(19) v:2(1) a:0(0)    sid:43 M01_adapt,8,M0_mod_M01,;	s17 = scc ? 0x8 : s20
	s_lshr_b32 s20,s18,0x3  ; # loaders.py:42 alloc 'idx_M00's20    s:21(20) v:2(1) a:0(0)    sid:44 idx_M00,idx_M0,3,
	s_lshl_b32 s21,s20,0x3  ; # loaders.py:43 alloc 'src1_gprs's21    s:22(21) v:2(1) a:0(0)    sid:45 src1_gprs,idx_M00,3,;	s21 = s20 << 0x3[4:0]; scc=(s21!=0);
	s_sub_u32 s18,s18,s21  ; # loaders.py:43 free 'idx_M0's18 free 'src1_gprs's21 alloc 'idx_M01's18    s:21(20) v:2(1) a:0(0)    sid:46 idx_M01,idx_M0,src1_gprs,;	s18.u32 = (s18.u32 - s21.u32); scc=(overflow or carry-out of last arith);
	s_lshl_b32 s18,s18,0x4  ; # loaders.py:44 free 'idx_M01's18 alloc 'src1_gprs's18    s:21(20) v:2(1) a:0(0)    sid:47 src1_gprs,idx_M01,4,;	s18 = s18 << 0x4[4:0]; scc=(s18!=0);
	s_add_u32 s18,s19,s18  ; # loaders.py:44 free 'idx_N0's19 free 'src1_gprs's18 alloc 'idx_N0_M01_local's18    s:20(20) v:2(1) a:0(0)    sid:48 idx_N0_M01_local,idx_N0,src1_gprs,;	s18.u32 = s19 + s18; scc=overflow_or_carry
	s_abs_i32 s19,s17  ; # asmjit.py:2552 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 's4's19    s:21(20) v:2(1) a:0(0)    sid:49 s4,M01_adapt,
	v_cvt_f32_u32_e32 v2,s19  ; # asmjit.py:2553 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 'v1'v2    s:21(20) v:3(2) a:0(0)    sid:50 v1,s4,
	s_sub_i32 s21,0x0,s19  ; # asmjit.py:2554 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 's5's21    s:22(21) v:3(2) a:0(0)    sid:51 s5,0,s4,;	s21.i32 = (0x0.i32 - s19.i32); scc=(overflow or carry-out of last arith);
	s_xor_b32 s22,s18,s17  ; # asmjit.py:2555 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 's3's22    s:23(22) v:3(2) a:0(0)    sid:52 s3,idx_N0_M01_local,M01_adapt,;	s22 = s18 ^ s17;  scc=(s22!=0);
	s_abs_i32 s23,s18  ; # asmjit.py:2556 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 'N_out's23    s:24(23) v:3(2) a:0(0)    sid:53 N_out,idx_N0_M01_local,
	v_rcp_iflag_f32_e32 v2,v2  ; # asmjit.py:2557 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:54 v1,v1,
	s_ashr_i32 s22,s22,0x1f  ; # asmjit.py:2558 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:55 s3,s3,31,
	v_mul_f32_e32 v2,0x4f7ffffe,v2  ; # asmjit.py:2559 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:56 v1,1333788670,v1,
	v_cvt_u32_f32_e32 v2,v2  ; # asmjit.py:2560 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:57 v1,v1,
	s_nop  0 ; # asmjit.py:2561 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:58;	s_nop  wait 1 cycles
	v_readfirstlane_b32 s24,v2  ; # asmjit.py:2562 asmjit.py:1552 asmjit.py:1582 loaders.py:46 free 'v1'v2 alloc 's6's24    s:25(24) v:2(1) a:0(0)    sid:59 s6,v1,
	s_mul_i32 s21,s21,s24  ; # asmjit.py:2563 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:60 s5,s5,s6,;	s21 = s21 * s24
	s_mul_hi_u32 s21,s24,s21  ; # asmjit.py:2564 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:61 s5,s6,s5,;	s21 = s24 * s21
	s_add_i32 s24,s24,s21  ; # asmjit.py:2565 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:62 s6,s6,s5,;	s24.i32 = s24 + s21; scc=overflow_or_carry
	s_mul_hi_u32 s21,s23,s24  ; # asmjit.py:2566 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:63 s5,N_out,s6,;	s21 = s23 * s24
	s_mul_i32 s24,s21,s19  ; # asmjit.py:2567 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:64 s6,s5,s4,;	s24 = s21 * s19
	s_sub_i32 s23,s23,s24  ; # asmjit.py:2568 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:65 N_out,N_out,s6,;	s23.i32 = (s23.i32 - s24.i32); scc=(overflow or carry-out of last arith);
	s_add_i32 s25,s21,0x1  ; # asmjit.py:2569 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 's7's25    s:26(25) v:2(1) a:0(0)    sid:66 s7,s5,1,;	s25.i32 = s21 + 0x1; scc=overflow_or_carry
	s_sub_i32 s24,s23,s19  ; # asmjit.py:2570 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:67 s6,N_out,s4,;	s24.i32 = (s23.i32 - s19.i32); scc=(overflow or carry-out of last arith);
	s_cmp_ge_u32 s23,s19  ; # asmjit.py:2571 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:68 N_out,s4,;	scc = (s23.u32 >= s19.u32)
	s_cselect_b32 s21,s25,s21  ; # asmjit.py:2572 asmjit.py:1552 asmjit.py:1582 loaders.py:46 free 's7's25   sid:69 s5,s7,s5,;	s21 = scc ? s25 : s21
	s_cselect_b32 s23,s24,s23  ; # asmjit.py:2573 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:70 N_out,s6,N_out,;	s23 = scc ? s24 : s23
	s_add_i32 s24,s21,0x1  ; # asmjit.py:2574 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:71 s6,s5,1,;	s24.i32 = s21 + 0x1; scc=overflow_or_carry
	s_cmp_ge_u32 s23,s19  ; # asmjit.py:2575 asmjit.py:1552 asmjit.py:1582 loaders.py:46 free 's4's19   sid:72 N_out,s4,;	scc = (s23.u32 >= s19.u32)
	s_cselect_b32 s23,s24,s21  ; # asmjit.py:2576 asmjit.py:1552 asmjit.py:1582 loaders.py:46 free 's5's21 free 's6's24   sid:73 N_out,s6,s5,;	s23 = scc ? s24 : s21
	s_xor_b32 s23,s23,s22  ; # asmjit.py:2577 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:74 N_out,N_out,s3,;	s23 = s23 ^ s22;  scc=(s23!=0);
	s_sub_i32 s23,s23,s22  ; # asmjit.py:2578 asmjit.py:1552 asmjit.py:1582 loaders.py:46 free 's3's22   sid:75 N_out,N_out,s3,;	s23.i32 = (s23.i32 - s22.i32); scc=(overflow or carry-out of last arith);
	s_mul_i32 s17,s23,s17  ; # loaders.py:47 free 'M01_adapt's17 alloc 'src1_gprs's17    s:21(23) v:2(1) a:0(0)    sid:76 src1_gprs,N_out,M01_adapt,;	s17 = s23 * s17
	s_sub_u32 s17,s18,s17  ; # loaders.py:47 free 'idx_N0_M01_local's18 free 'src1_gprs's17 alloc 'idx_loc_mod_M01's17    s:20(23) v:2(1) a:0(0)    sid:77 idx_loc_mod_M01,idx_N0_M01_local,src1_gprs,;	s17.u32 = (s18.u32 - s17.u32); scc=(overflow or carry-out of last arith);
	s_lshl_b32 s18,s20,0x3  ; # loaders.py:49 free 'idx_M00's20 alloc 'src1_gprs's18    s:20(23) v:2(1) a:0(0)    sid:78 src1_gprs,idx_M00,3,;	s18 = s20 << 0x3[4:0]; scc=(s18!=0);
	s_add_u32 s17,s17,s18  ; # loaders.py:49 free 'idx_loc_mod_M01's17 free 'src1_gprs's18 alloc 'M_out's17    s:19(23) v:2(1) a:0(0)    sid:79 M_out,idx_loc_mod_M01,src1_gprs,;	s17.u32 = s17 + s18; scc=overflow_or_carry
	s_lshr_b32 s18,s2,0x2  ; # asmjit.py:1627 gemm_fp8_gfx942.py:26 alloc 'src1_gprs's18    s:20(23) v:2(1) a:0(0)    sid:80 src1_gprs,blockIdx.x,2,
	s_and_b32 s18,0x3,s18  ; # asmjit.py:1627 gemm_fp8_gfx942.py:26 free 'src1_gprs's18 alloc 'packet_phase's18    s:20(23) v:2(1) a:0(0)    sid:81 packet_phase,3,src1_gprs,;	s18 = 0x3 & s18
	s_lshl_b32 s17,s17,0x8  ; # asmjit.py:1627 gemm_fp8_gfx942.py:27 free 'M_out's17 alloc 'row_base's17    s:20(23) v:2(1) a:0(0)    sid:82 row_base,M_out,8,;	s17 = s17 << 0x8[4:0]; scc=(s17!=0);
	s_lshl_b32 s19,s23,0x8  ; # asmjit.py:1627 gemm_fp8_gfx942.py:28 free 'N_out's23 alloc 'col_base's19    s:20(19) v:2(1) a:0(0)    sid:83 col_base,N_out,8,;	s19 = s23 << 0x8[4:0]; scc=(s19!=0);
	s_sub_i32 s20,s5,s17  ; # gemm_fp8_gfx942.py:31 alloc 'idst's20    s:21(20) v:2(1) a:0(0)    sid:84 idst,M,row_base,;	s20.i32 = (s5.i32 - s17.i32); scc=(overflow or carry-out of last arith);
	s_min_u32 s20,s20,0x100  ; # gemm_fp8_gfx942.py:31 free 'idst's20 alloc 'rows's20    s:21(20) v:2(1) a:0(0)    sid:85 rows,idst,256,
	s_sub_u32 s21,0x1000,s19  ; # gemm_fp8_gfx942.py:32 alloc 'idst's21    s:22(21) v:2(1) a:0(0)    sid:86 idst,4096,col_base,;	s21.u32 = (0x1000.u32 - s19.u32); scc=(overflow or carry-out of last arith);
	s_min_u32 s21,s21,0x100  ; # gemm_fp8_gfx942.py:32 free 'idst's21 alloc 'cols's21    s:22(21) v:2(1) a:0(0)    sid:87 cols,idst,256,
	s_lshl_b32 s22,s17,0xe  ; # gemm_fp8_gfx942.py:33 alloc 'src1_gprs's22    s:23(22) v:2(1) a:0(0)    sid:88 src1_gprs,row_base,14,;	s22 = s17 << 0xe[4:0]; scc=(s22!=0);
	s_add_u32 s6,s6,s22  ; # gemm_fp8_gfx942.py:33 free 'src1_gprs's22   sid:89 pA,pA,src1_gprs,;	s6.u32 = s6 + s22; scc=overflow_or_carry
	s_addc_u32 s7,s7,0x0  ; # gemm_fp8_gfx942.py:33   sid:90 pA,pA,0,;	s7.u32 = s7 + 0x0 + scc; scc=overflow_or_carry
	s_lshl_b32 s22,s19,0xe  ; # gemm_fp8_gfx942.py:34 alloc 'src1_gprs's22    s:23(22) v:2(1) a:0(0)    sid:91 src1_gprs,col_base,14,;	s22 = s19 << 0xe[4:0]; scc=(s22!=0);
	s_add_u32 s8,s8,s22  ; # gemm_fp8_gfx942.py:34 free 'src1_gprs's22   sid:92 pB,pB,src1_gprs,;	s8.u32 = s8 + s22; scc=overflow_or_carry
	s_addc_u32 s9,s9,0x0  ; # gemm_fp8_gfx942.py:34   sid:93 pB,pB,0,;	s9.u32 = s9 + 0x0 + scc; scc=overflow_or_carry
	s_lshl_b32 s22,s17,0xd  ; # gemm_fp8_gfx942.py:35 alloc 'src1_gprs's22    s:23(22) v:2(1) a:0(0)    sid:94 src1_gprs,row_base,13,;	s22 = s17 << 0xd[4:0]; scc=(s22!=0);
	s_add_u32 s10,s10,s22  ; # gemm_fp8_gfx942.py:35 free 'src1_gprs's22   sid:95 pC,pC,src1_gprs,;	s10.u32 = s10 + s22; scc=overflow_or_carry
	s_addc_u32 s11,s11,0x0  ; # gemm_fp8_gfx942.py:35   sid:96 pC,pC,0,;	s11.u32 = s11 + 0x0 + scc; scc=overflow_or_carry
	s_mov_b32 s22,s16  ; # gemm_fp8_gfx942.py:36 alloc 'wave_m's22    s:23(22) v:2(1) a:0(0)    sid:97 wave_m,_warp_id,;	s22 = s16
	s_lshr_b32 s16,s16,0x2  ; # asmjit.py:1627 gemm_fp8_gfx942.py:37 free '_warp_id's16 alloc 'group's16    s:23(22) v:2(1) a:0(0)    sid:98 group,_warp_id,2,
	v_lshrrev_b32 v2,0x1,s22  ; # gemm_fp8_gfx942.py:43 alloc 'src0_gprs'v2    s:23(22) v:3(2) a:0(0)    sid:99 src0_gprs,1,wave_m,;	v2.b32 = s22 >> 0x1[4:0];
	v_lshlrev_b32 v3,0x12,v2  ; # gemm_fp8_gfx942.py:43 alloc 'src0_gprs'v3    s:23(22) v:4(3) a:0(0)    sid:100 src0_gprs,18,src0_gprs,;	v3.b32 = v2 << 0x12[4:0];
	v_and_b32 v4,0x1,s22  ; # gemm_fp8_gfx942.py:43 alloc 'src0_gprs'v4    s:23(22) v:5(4) a:0(0)    sid:101 src0_gprs,1,wave_m,;	v4.u32 = (0x1 & s22.u32)
	v_lshlrev_b32 v5,0xa,v4  ; # gemm_fp8_gfx942.py:43 alloc 'src1_gprs'v5    s:23(22) v:6(5) a:0(0)    sid:102 src1_gprs,10,src0_gprs,;	v5.b32 = v4 << 0xa[4:0];
	v_add_u32_e32 v3,v3,v5  ; # gemm_fp8_gfx942.py:43 free 'src0_gprs'v3 free 'src1_gprs'v5 alloc 'src0_gprs'v3    s:23(22) v:5(4) a:0(0)    sid:103 src0_gprs,src0_gprs,src1_gprs,;	v3 = v3 + v5
	v_lshlrev_b32 v5,0x4,v1  ; # gemm_fp8_gfx942.py:43 alloc 'src1_gprs'v5    s:23(22) v:6(5) a:0(0)    sid:104 src1_gprs,4,_lane_id,;	v5.b32 = v1 << 0x4[4:0];
	v_add_u32_e32 v3,v3,v5  ; # gemm_fp8_gfx942.py:43 free 'src0_gprs'v3 free 'src1_gprs'v5 alloc 'lane_b'v3    s:23(22) v:5(4) a:0(0)    sid:105 lane_b,src0_gprs,src1_gprs,;	v3 = v3 + v5
	v_lshlrev_b32 v2,0x4,v2  ; # gemm_fp8_gfx942.py:46 free 'src0_gprs'v2 alloc 'src0_gprs'v2    s:23(22) v:5(4) a:0(0)    sid:106 src0_gprs,4,src0_gprs,;	v2.b32 = v2 << 0x4[4:0];
	v_and_b32 v5,0xf,v1  ; # gemm_fp8_gfx942.py:46 alloc 'src1_gprs'v5    s:23(22) v:6(5) a:0(0)    sid:107 src1_gprs,15,_lane_id,;	v5.u32 = (0xf & v1.u32)
	v_add_u32_e32 v2,v2,v5  ; # gemm_fp8_gfx942.py:46 free 'src0_gprs'v2 alloc 'write_row'v2    s:23(22) v:6(5) a:0(0)    sid:108 write_row,src0_gprs,src1_gprs,;	v2 = v2 + v5
	v_lshlrev_b32 v4,0x2,v4  ; # gemm_fp8_gfx942.py:47 free 'src0_gprs'v4 alloc 'src0_gprs'v4    s:23(22) v:6(5) a:0(0)    sid:109 src0_gprs,2,src0_gprs,;	v4.b32 = v4 << 0x2[4:0];
	v_lshrrev_b32 v6,0x4,v1  ; # gemm_fp8_gfx942.py:47 alloc 'src1_gprs'v6    s:23(22) v:7(6) a:0(0)    sid:110 src1_gprs,4,_lane_id,;	v6.b32 = v1 >> 0x4[4:0];
	v_add_u32_e32 v4,v4,v6  ; # gemm_fp8_gfx942.py:47 free 'src0_gprs'v4 alloc 'write_col'v4    s:23(22) v:7(6) a:0(0)    sid:111 write_col,src0_gprs,src1_gprs,;	v4 = v4 + v6
	v_lshlrev_b32 v7,0x7,v2  ; # gemm_fp8_gfx942.py:52 alloc 'src0_gprs'v7    s:23(22) v:8(7) a:0(0)    sid:112 src0_gprs,7,write_row,;	v7.b32 = v2 << 0x7[4:0];
	v_xor_b32 v2,v2,v4  ; # gemm_fp8_gfx942.py:52 free 'write_row'v2 free 'write_col'v4 alloc 'src1_gprs'v2    s:23(22) v:7(7) a:0(0)    sid:113 src1_gprs,write_row,write_col,;	v2.u32 = (v2 ^ v4.u32)
	v_and_b32 v2,0x7,v2  ; # gemm_fp8_gfx942.py:52 free 'src1_gprs'v2 alloc 'src0_gprs'v2    s:23(22) v:7(7) a:0(0)    sid:114 src0_gprs,7,src1_gprs,;	v2.u32 = (0x7 & v2.u32)
	v_lshlrev_b32 v2,0x4,v2  ; # gemm_fp8_gfx942.py:52 free 'src0_gprs'v2 alloc 'src1_gprs'v2    s:23(22) v:7(7) a:0(0)    sid:115 src1_gprs,4,src0_gprs,;	v2.b32 = v2 << 0x4[4:0];
	v_add_u32_e32 v2,v7,v2  ; # gemm_fp8_gfx942.py:52 free 'src0_gprs'v7 free 'src1_gprs'v2 alloc 'write_b'v2    s:23(22) v:6(6) a:0(0)    sid:116 write_b,src0_gprs,src1_gprs,;	v2 = v7 + v2
	v_xor_b32 v4,0x0,s18  ; # gemm_fp8_gfx942.py:56 alloc 'src0_gprs'v4    s:23(22) v:7(6) a:0(0)    sid:117 src0_gprs,0,packet_phase,;	v4.u32 = (0x0 ^ s18.u32)
	v_lshlrev_b32 v4,0x14,v4  ; # gemm_fp8_gfx942.py:56 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:23(22) v:7(6) a:0(0)    sid:118 src1_gprs,20,src0_gprs,;	v4.b32 = v4 << 0x14[4:0];
	v_add_u32_e32 v4,v3,v4  ; # gemm_fp8_gfx942.py:56 free 'src1_gprs'v4 alloc 'load_b[0:0]'v4    s:23(22) v:7(6) a:0(0)    sid:119 load_b[0:0],lane_b,src1_gprs,;	v4 = v3 + v4
	v_xor_b32 v7,0x1,s18  ; # gemm_fp8_gfx942.py:56 alloc 'src0_gprs'v7    s:23(22) v:8(7) a:0(0)    sid:120 src0_gprs,1,packet_phase,;	v7.u32 = (0x1 ^ s18.u32)
	v_lshlrev_b32 v7,0x14,v7  ; # gemm_fp8_gfx942.py:56 free 'src0_gprs'v7 alloc 'src1_gprs'v7    s:23(22) v:8(7) a:0(0)    sid:121 src1_gprs,20,src0_gprs,;	v7.b32 = v7 << 0x14[4:0];
	v_add_u32_e32 v7,v3,v7  ; # gemm_fp8_gfx942.py:56 free 'src1_gprs'v7 alloc 'load_b[1:1]'v7    s:23(22) v:8(7) a:0(0)    sid:122 load_b[1:1],lane_b,src1_gprs,;	v7 = v3 + v7
	v_xor_b32 v8,0x2,s18  ; # gemm_fp8_gfx942.py:56 alloc 'src0_gprs'v8    s:23(22) v:9(8) a:0(0)    sid:123 src0_gprs,2,packet_phase,;	v8.u32 = (0x2 ^ s18.u32)
	v_lshlrev_b32 v8,0x14,v8  ; # gemm_fp8_gfx942.py:56 free 'src0_gprs'v8 alloc 'src1_gprs'v8    s:23(22) v:9(8) a:0(0)    sid:124 src1_gprs,20,src0_gprs,;	v8.b32 = v8 << 0x14[4:0];
	v_add_u32_e32 v8,v3,v8  ; # gemm_fp8_gfx942.py:56 free 'src1_gprs'v8 alloc 'load_b[2:2]'v8    s:23(22) v:9(8) a:0(0)    sid:125 load_b[2:2],lane_b,src1_gprs,;	v8 = v3 + v8
	v_xor_b32 v9,0x3,s18  ; # gemm_fp8_gfx942.py:56 alloc 'src0_gprs'v9    s:23(22) v:10(9) a:0(0)    sid:126 src0_gprs,3,packet_phase,;	v9.u32 = (0x3 ^ s18.u32)
	v_lshlrev_b32 v9,0x14,v9  ; # gemm_fp8_gfx942.py:56 free 'src0_gprs'v9 alloc 'src1_gprs'v9    s:23(22) v:10(9) a:0(0)    sid:127 src1_gprs,20,src0_gprs,;	v9.b32 = v9 << 0x14[4:0];
	v_add_u32_e32 v3,v3,v9  ; # gemm_fp8_gfx942.py:56 free 'lane_b'v3 free 'src1_gprs'v9 alloc 'load_b[3:3]'v3    s:23(22) v:9(8) a:0(0)    sid:128 load_b[3:3],lane_b,src1_gprs,;	v3 = v3 + v9
	s_mov_b32 s27,0x20000  ; # asmjit.py:766 asmjit.py:1328 gemm_fp8_gfx942.py:57 alloc 'self.desc's[24:27]    s:27(27) v:9(8) a:0(0)    sid:129 self.desc,131072,;	s27 = 0x20000
	s_mov_b32 s24,s6  ; # asmjit.py:769 asmjit.py:1329 gemm_fp8_gfx942.py:57   sid:130 self.desc,pA,;	s24 = s6
	s_mov_b32 s25,s7  ; # asmjit.py:770 asmjit.py:1329 gemm_fp8_gfx942.py:57 free 'pA's[6:7]   sid:131 self.desc,pA,;	s25 = s7
	s_lshl_b32 s26,s20,0xe  ; # asmjit.py:771 asmjit.py:1329 gemm_fp8_gfx942.py:57   sid:132 self.desc,rows,14,;	s26 = s20 << 0xe[4:0]; scc=(s26!=0);
	s_mov_b32 s31,0x20000  ; # asmjit.py:766 asmjit.py:1328 gemm_fp8_gfx942.py:58 alloc 'self.desc's[28:31]    s:29(31) v:9(8) a:0(0)    sid:133 self.desc,131072,;	s31 = 0x20000
	s_mov_b32 s28,s8  ; # asmjit.py:769 asmjit.py:1329 gemm_fp8_gfx942.py:58   sid:134 self.desc,pB,;	s28 = s8
	s_mov_b32 s29,s9  ; # asmjit.py:770 asmjit.py:1329 gemm_fp8_gfx942.py:58 free 'pB's[8:9]   sid:135 self.desc,pB,;	s29 = s9
	s_lshl_b32 s30,s21,0xe  ; # asmjit.py:771 asmjit.py:1329 gemm_fp8_gfx942.py:58 free 'cols's21   sid:136 self.desc,cols,14,;	s30 = s21 << 0xe[4:0]; scc=(s30!=0);
	s_mov_b32 s35,0x20000  ; # asmjit.py:766 asmjit.py:1328 gemm_fp8_gfx942.py:59 alloc 'self.desc's[32:35]    s:30(35) v:9(8) a:0(0)    sid:137 self.desc,131072,;	s35 = 0x20000
	s_mov_b32 s32,s10  ; # asmjit.py:769 asmjit.py:1329 gemm_fp8_gfx942.py:59   sid:138 self.desc,pC,;	s32 = s10
	s_mov_b32 s33,s11  ; # asmjit.py:770 asmjit.py:1329 gemm_fp8_gfx942.py:59 free 'pC's[10:11]   sid:139 self.desc,pC,;	s33 = s11
	s_lshl_b32 s34,s20,0xd  ; # asmjit.py:771 asmjit.py:1329 gemm_fp8_gfx942.py:59 free 'rows's20   sid:140 self.desc,rows,13,;	s34 = s20 << 0xd[4:0]; scc=(s34!=0);
	s_mov_b32 s11,0x20000  ; # asmjit.py:766 asmjit.py:1328 gemm_fp8_gfx942.py:60 alloc 'self.desc's[8:11]    s:31(35) v:9(8) a:0(0)    sid:141 self.desc,131072,;	s11 = 0x20000
	s_mov_b32 s8,s12  ; # asmjit.py:769 asmjit.py:1329 gemm_fp8_gfx942.py:60   sid:142 self.desc,pScaleA,;	s8 = s12
	s_mov_b32 s9,s13  ; # asmjit.py:770 asmjit.py:1329 gemm_fp8_gfx942.py:60 free 'pScaleA's[12:13]   sid:143 self.desc,pScaleA,;	s9 = s13
	s_lshl_b32 s10,s5,0x9  ; # asmjit.py:771 asmjit.py:1329 gemm_fp8_gfx942.py:60   sid:144 self.desc,M,9,;	s10 = s5 << 0x9[4:0]; scc=(s10!=0);
	v_lshlrev_b32 v9,0x4,s22  ; # gemm_fp8_gfx942.py:63 free 'wave_m's22 alloc 'src0_gprs'v9    s:28(35) v:10(9) a:0(0)    sid:145 src0_gprs,4,wave_m,;	v9.b32 = s22 << 0x4[4:0];
	v_add_u32_e32 v9,v9,v5  ; # gemm_fp8_gfx942.py:63 free 'src0_gprs'v9 alloc 'local_row'v9    s:28(35) v:10(9) a:0(0)    sid:146 local_row,src0_gprs,src1_gprs,;	v9 = v9 + v5
	s_sub_u32 s6,s5,0x1  ; # asmjit.py:1627 gemm_fp8_gfx942.py:64 alloc 'last_row's6    s:29(35) v:10(9) a:0(0)    sid:147 last_row,M,1,;	s6.u32 = (s5.u32 - 0x1.u32); scc=(overflow or carry-out of last arith);
	v_add_u32_e32 v10,s17,v9  ; # gemm_fp8_gfx942.py:67 free 'row_base's17 alloc 'src1_gprs'v10    s:28(35) v:11(10) a:0(0)    sid:148 src1_gprs,row_base,local_row,;	v10 = s17 + v9
	v_add_u32_e32 v11,0x0,v10  ; # gemm_fp8_gfx942.py:67 alloc 'load_scale_a[0:0]'v11    s:28(35) v:12(11) a:0(0)    sid:149 load_scale_a[0:0],0,src1_gprs,;	v11 = 0x0 + v10
	v_min_u32 v11,s6,v11  ; # gemm_fp8_gfx942.py:69   sid:150 load_scale_a[0:0],last_row,load_scale_a[0:0],
	v_lshlrev_b32 v11,0x2,v11  ; # gemm_fp8_gfx942.py:70   sid:151 load_scale_a[0:0],2,load_scale_a[0:0],;	v11.b32 = v11 << 0x2[4:0];
	v_add_u32_e32 v10,0x80,v10  ; # gemm_fp8_gfx942.py:67 free 'src1_gprs'v10 alloc 'load_scale_a[1:1]'v10    s:28(35) v:12(11) a:0(0)    sid:152 load_scale_a[1:1],128,src1_gprs,;	v10 = 0x80 + v10
	v_min_u32 v10,s6,v10  ; # gemm_fp8_gfx942.py:69 free 'last_row's6   sid:153 load_scale_a[1:1],last_row,load_scale_a[1:1],
	v_lshlrev_b32 v10,0x2,v10  ; # gemm_fp8_gfx942.py:70   sid:154 load_scale_a[1:1],2,load_scale_a[1:1],;	v10.b32 = v10 << 0x2[4:0];
	s_lshr_b32 s6,s19,0x7  ; # gemm_fp8_gfx942.py:74 alloc 'src0_gprs's6    s:28(35) v:12(11) a:0(0)    sid:155 src0_gprs,col_base,7,
	s_lshr_b32 s7,s18,0x1  ; # gemm_fp8_gfx942.py:74 alloc 'src1_gprs's7    s:29(35) v:12(11) a:0(0)    sid:156 src1_gprs,packet_phase,1,
	s_add_u32 s6,s6,s7  ; # gemm_fp8_gfx942.py:74 free 'src0_gprs's6 free 'src1_gprs's7 alloc 'src0_gprs's6    s:28(35) v:12(11) a:0(0)    sid:157 src0_gprs,src0_gprs,src1_gprs,;	s6.u32 = s6 + s7; scc=overflow_or_carry
	s_lshl_b32 s6,s6,0x9  ; # gemm_fp8_gfx942.py:74 free 'src0_gprs's6 alloc 'scale_offset_b's[6:7]    s:29(35) v:12(11) a:0(0)    sid:158 scale_offset_b,src0_gprs,9,;	s6 = s6 << 0x9[4:0]; scc=(s6!=0);
	s_lshr_b32 s12,s19,0x7  ; # gemm_fp8_gfx942.py:75 alloc 'src0_gprs's12    s:30(35) v:12(11) a:0(0)    sid:159 src0_gprs,col_base,7,
	s_lshr_b32 s13,s18,0x1  ; # gemm_fp8_gfx942.py:75 alloc 'src1_gprs's13    s:31(35) v:12(11) a:0(0)    sid:160 src1_gprs,packet_phase,1,
	s_xor_b32 s13,0x1,s13  ; # gemm_fp8_gfx942.py:75 free 'src1_gprs's13 alloc 'src1_gprs's13    s:31(35) v:12(11) a:0(0)    sid:161 src1_gprs,1,src1_gprs,;	s13 = 0x1 ^ s13;  scc=(s13!=0);
	s_add_u32 s12,s12,s13  ; # gemm_fp8_gfx942.py:75 free 'src0_gprs's12 free 'src1_gprs's13 alloc 'src0_gprs's12    s:30(35) v:12(11) a:0(0)    sid:162 src0_gprs,src0_gprs,src1_gprs,;	s12.u32 = s12 + s13; scc=overflow_or_carry
	s_lshl_b32 s7,s12,0x9  ; # gemm_fp8_gfx942.py:75 free 'src0_gprs's12   sid:163 scale_offset_b,src0_gprs,9,;	s7 = s12 << 0x9[4:0]; scc=(s7!=0);
	s_min_u32 s7,s7,0x3e00  ; # gemm_fp8_gfx942.py:80   sid:164 scale_offset_b,scale_offset_b,15872,
	v_add_u32_e32 v12,0x0,v9  ; # gemm_fp8_gfx942.py:87 alloc 'src0_gprs'v12    s:29(35) v:13(12) a:0(0)    sid:165 src0_gprs,0,local_row,;	v12 = 0x0 + v9
	v_lshlrev_b32 v12,0xe,v12  ; # gemm_fp8_gfx942.py:87 free 'src0_gprs'v12 alloc 'src0_gprs'v12    s:29(35) v:13(12) a:0(0)    sid:166 src0_gprs,14,src0_gprs,;	v12.b32 = v12 << 0xe[4:0];
	v_add_u32_e32 v13,0x0,v6  ; # gemm_fp8_gfx942.py:87 alloc 'src0_gprs'v13    s:29(35) v:14(13) a:0(0)    sid:167 src0_gprs,0,src1_gprs,;	v13 = 0x0 + v6
	v_lshlrev_b32 v14,0x4,v13  ; # gemm_fp8_gfx942.py:87 alloc 'src1_gprs'v14    s:29(35) v:15(14) a:0(0)    sid:168 src1_gprs,4,src0_gprs,;	v14.b32 = v13 << 0x4[4:0];
	v_add_u32_e32 v15,v12,v14  ; # gemm_fp8_gfx942.py:87 alloc 'load_a[0:0]'v15    s:29(35) v:16(15) a:0(0)    sid:169 load_a[0:0],src0_gprs,src1_gprs,;	v15 = v12 + v14
	v_add_u32_e32 v16,0x80,v9  ; # gemm_fp8_gfx942.py:87 alloc 'src0_gprs'v16    s:29(35) v:17(16) a:0(0)    sid:170 src0_gprs,128,local_row,;	v16 = 0x80 + v9
	v_lshlrev_b32 v16,0xe,v16  ; # gemm_fp8_gfx942.py:87 free 'src0_gprs'v16 alloc 'src0_gprs'v16    s:29(35) v:17(16) a:0(0)    sid:171 src0_gprs,14,src0_gprs,;	v16.b32 = v16 << 0xe[4:0];
	v_add_u32_e32 v14,v16,v14  ; # gemm_fp8_gfx942.py:87 free 'src1_gprs'v14 alloc 'load_a[2:2]'v14    s:29(35) v:17(16) a:0(0)    sid:172 load_a[2:2],src0_gprs,src1_gprs,;	v14 = v16 + v14
	v_lshlrev_b32 v17,0x7,v5  ; # gemm_fp8_gfx942.py:88 alloc 'src0_gprs'v17    s:29(35) v:18(17) a:0(0)    sid:173 src0_gprs,7,src1_gprs,;	v17.b32 = v5 << 0x7[4:0];
	v_xor_b32 v13,v5,v13  ; # gemm_fp8_gfx942.py:88 free 'src0_gprs'v13 alloc 'src1_gprs'v13    s:29(35) v:18(17) a:0(0)    sid:174 src1_gprs,src1_gprs,src0_gprs,;	v13.u32 = (v5 ^ v13.u32)
	v_and_b32 v13,0x7,v13  ; # gemm_fp8_gfx942.py:88 free 'src1_gprs'v13 alloc 'src0_gprs'v13    s:29(35) v:18(17) a:0(0)    sid:175 src0_gprs,7,src1_gprs,;	v13.u32 = (0x7 & v13.u32)
	v_lshlrev_b32 v13,0x4,v13  ; # gemm_fp8_gfx942.py:88 free 'src0_gprs'v13 alloc 'src1_gprs'v13    s:29(35) v:18(17) a:0(0)    sid:176 src1_gprs,4,src0_gprs,;	v13.b32 = v13 << 0x4[4:0];
	v_add_u32_e32 v13,v17,v13  ; # gemm_fp8_gfx942.py:88 free 'src1_gprs'v13 alloc 'read_b[0:0]'v13    s:29(35) v:18(17) a:0(0)    sid:177 read_b[0:0],src0_gprs,src1_gprs,;	v13 = v17 + v13
	v_add_u32_e32 v6,0x4,v6  ; # gemm_fp8_gfx942.py:87 free 'src1_gprs'v6 alloc 'src0_gprs'v6    s:29(35) v:18(17) a:0(0)    sid:178 src0_gprs,4,src1_gprs,;	v6 = 0x4 + v6
	v_lshlrev_b32 v18,0x4,v6  ; # gemm_fp8_gfx942.py:87 alloc 'src1_gprs'v18    s:29(35) v:19(18) a:0(0)    sid:179 src1_gprs,4,src0_gprs,;	v18.b32 = v6 << 0x4[4:0];
	v_add_u32_e32 v12,v12,v18  ; # gemm_fp8_gfx942.py:87 free 'src0_gprs'v12 alloc 'load_a[1:1]'v12    s:29(35) v:19(18) a:0(0)    sid:180 load_a[1:1],src0_gprs,src1_gprs,;	v12 = v12 + v18
	v_add_u32_e32 v16,v16,v18  ; # gemm_fp8_gfx942.py:87 free 'src0_gprs'v16 free 'src1_gprs'v18 alloc 'load_a[3:3]'v16    s:29(35) v:18(17) a:0(0)    sid:181 load_a[3:3],src0_gprs,src1_gprs,;	v16 = v16 + v18
	v_xor_b32 v5,v5,v6  ; # gemm_fp8_gfx942.py:88 free 'src1_gprs'v5 free 'src0_gprs'v6 alloc 'src1_gprs'v5    s:29(35) v:17(17) a:0(0)    sid:182 src1_gprs,src1_gprs,src0_gprs,;	v5.u32 = (v5 ^ v6.u32)
	v_and_b32 v5,0x7,v5  ; # gemm_fp8_gfx942.py:88 free 'src1_gprs'v5 alloc 'src0_gprs'v5    s:29(35) v:17(17) a:0(0)    sid:183 src0_gprs,7,src1_gprs,;	v5.u32 = (0x7 & v5.u32)
	v_lshlrev_b32 v5,0x4,v5  ; # gemm_fp8_gfx942.py:88 free 'src0_gprs'v5 alloc 'src1_gprs'v5    s:29(35) v:17(17) a:0(0)    sid:184 src1_gprs,4,src0_gprs,;	v5.b32 = v5 << 0x4[4:0];
	v_add_u32_e32 v5,v17,v5  ; # gemm_fp8_gfx942.py:88 free 'src0_gprs'v17 free 'src1_gprs'v5 alloc 'read_b[1:1]'v5    s:29(35) v:16(16) a:0(0)    sid:185 read_b[1:1],src0_gprs,src1_gprs,;	v5 = v17 + v5
	v_mov_b32 v20,0x0  ; # gemm_fp8_gfx942.py:94 alloc 'partial[0:3]'v[20:23]    s:29(35) v:20(23) a:0(0)    sid:186 partial[0:3],0,;	v20 = 0x0;
	v_mov_b32 v21,0x0  ; # gemm_fp8_gfx942.py:94   sid:187 partial[0:3],0,;	v21 = 0x0;
	v_mov_b32 v22,0x0  ; # gemm_fp8_gfx942.py:94   sid:188 partial[0:3],0,;	v22 = 0x0;
	v_mov_b32 v23,0x0  ; # gemm_fp8_gfx942.py:94   sid:189 partial[0:3],0,;	v23 = 0x0;
	v_mov_b32 v24,0x0  ; # gemm_fp8_gfx942.py:94 alloc 'partial[4:7]'v[24:27]    s:29(35) v:24(27) a:0(0)    sid:190 partial[4:7],0,;	v24 = 0x0;
	v_mov_b32 v25,0x0  ; # gemm_fp8_gfx942.py:94   sid:191 partial[4:7],0,;	v25 = 0x0;
	v_mov_b32 v26,0x0  ; # gemm_fp8_gfx942.py:94   sid:192 partial[4:7],0,;	v26 = 0x0;
	v_mov_b32 v27,0x0  ; # gemm_fp8_gfx942.py:94   sid:193 partial[4:7],0,;	v27 = 0x0;
	v_mov_b32 v28,0x0  ; # gemm_fp8_gfx942.py:94 alloc 'partial[8:11]'v[28:31]    s:29(35) v:28(31) a:0(0)    sid:194 partial[8:11],0,;	v28 = 0x0;
	v_mov_b32 v29,0x0  ; # gemm_fp8_gfx942.py:94   sid:195 partial[8:11],0,;	v29 = 0x0;
	v_mov_b32 v30,0x0  ; # gemm_fp8_gfx942.py:94   sid:196 partial[8:11],0,;	v30 = 0x0;
	v_mov_b32 v31,0x0  ; # gemm_fp8_gfx942.py:94   sid:197 partial[8:11],0,;	v31 = 0x0;
	v_mov_b32 v32,0x0  ; # gemm_fp8_gfx942.py:94 alloc 'partial[12:15]'v[32:35]    s:29(35) v:32(35) a:0(0)    sid:198 partial[12:15],0,;	v32 = 0x0;
	v_mov_b32 v33,0x0  ; # gemm_fp8_gfx942.py:94   sid:199 partial[12:15],0,;	v33 = 0x0;
	v_mov_b32 v34,0x0  ; # gemm_fp8_gfx942.py:94   sid:200 partial[12:15],0,;	v34 = 0x0;
	v_mov_b32 v35,0x0  ; # gemm_fp8_gfx942.py:94   sid:201 partial[12:15],0,;	v35 = 0x0;
	v_mov_b32 v6,0x0  ; # gemm_fp8_gfx942.py:95 alloc 'partial_scale[0:0]'v6    s:29(35) v:33(35) a:0(0)    sid:202 partial_scale[0:0],0,;	v6 = 0x0;
	v_mov_b32 v17,0x0  ; # gemm_fp8_gfx942.py:95 alloc 'partial_scale[1:1]'v17    s:29(35) v:34(35) a:0(0)    sid:203 partial_scale[1:1],0,;	v17 = 0x0;
	v_mov_b32 v18,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[0:0]'v18    s:29(35) v:35(35) a:0(0)    sid:204 accum[0:0],0,;	v18 = 0x0;
	v_mov_b32 v19,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[1:1]'v19    s:29(35) v:36(35) a:0(0)    sid:205 accum[1:1],0,;	v19 = 0x0;
	v_mov_b32 v36,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[2:2]'v36    s:29(35) v:37(36) a:0(0)    sid:206 accum[2:2],0,;	v36 = 0x0;
	v_mov_b32 v37,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[3:3]'v37    s:29(35) v:38(37) a:0(0)    sid:207 accum[3:3],0,;	v37 = 0x0;
	v_mov_b32 v38,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[4:4]'v38    s:29(35) v:39(38) a:0(0)    sid:208 accum[4:4],0,;	v38 = 0x0;
	v_mov_b32 v39,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[5:5]'v39    s:29(35) v:40(39) a:0(0)    sid:209 accum[5:5],0,;	v39 = 0x0;
	v_mov_b32 v40,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[6:6]'v40    s:29(35) v:41(40) a:0(0)    sid:210 accum[6:6],0,;	v40 = 0x0;
	v_mov_b32 v41,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[7:7]'v41    s:29(35) v:42(41) a:0(0)    sid:211 accum[7:7],0,;	v41 = 0x0;
	v_mov_b32 v42,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[8:8]'v42    s:29(35) v:43(42) a:0(0)    sid:212 accum[8:8],0,;	v42 = 0x0;
	v_mov_b32 v43,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[9:9]'v43    s:29(35) v:44(43) a:0(0)    sid:213 accum[9:9],0,;	v43 = 0x0;
	v_mov_b32 v44,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[10:10]'v44    s:29(35) v:45(44) a:0(0)    sid:214 accum[10:10],0,;	v44 = 0x0;
	v_mov_b32 v45,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[11:11]'v45    s:29(35) v:46(45) a:0(0)    sid:215 accum[11:11],0,;	v45 = 0x0;
	v_mov_b32 v46,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[12:12]'v46    s:29(35) v:47(46) a:0(0)    sid:216 accum[12:12],0,;	v46 = 0x0;
	v_mov_b32 v47,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[13:13]'v47    s:29(35) v:48(47) a:0(0)    sid:217 accum[13:13],0,;	v47 = 0x0;
	v_mov_b32 v48,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[14:14]'v48    s:29(35) v:49(48) a:0(0)    sid:218 accum[14:14],0,;	v48 = 0x0;
	v_mov_b32 v49,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[15:15]'v49    s:29(35) v:50(49) a:0(0)    sid:219 accum[15:15],0,;	v49 = 0x0;
	v_mov_b32 v50,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[16:16]'v50    s:29(35) v:51(50) a:0(0)    sid:220 accum[16:16],0,;	v50 = 0x0;
	v_mov_b32 v51,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[17:17]'v51    s:29(35) v:52(51) a:0(0)    sid:221 accum[17:17],0,;	v51 = 0x0;
	v_mov_b32 v52,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[18:18]'v52    s:29(35) v:53(52) a:0(0)    sid:222 accum[18:18],0,;	v52 = 0x0;
	v_mov_b32 v53,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[19:19]'v53    s:29(35) v:54(53) a:0(0)    sid:223 accum[19:19],0,;	v53 = 0x0;
	v_mov_b32 v54,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[20:20]'v54    s:29(35) v:55(54) a:0(0)    sid:224 accum[20:20],0,;	v54 = 0x0;
	v_mov_b32 v55,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[21:21]'v55    s:29(35) v:56(55) a:0(0)    sid:225 accum[21:21],0,;	v55 = 0x0;
	v_mov_b32 v56,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[22:22]'v56    s:29(35) v:57(56) a:0(0)    sid:226 accum[22:22],0,;	v56 = 0x0;
	v_mov_b32 v57,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[23:23]'v57    s:29(35) v:58(57) a:0(0)    sid:227 accum[23:23],0,;	v57 = 0x0;
	v_mov_b32 v58,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[24:24]'v58    s:29(35) v:59(58) a:0(0)    sid:228 accum[24:24],0,;	v58 = 0x0;
	v_mov_b32 v59,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[25:25]'v59    s:29(35) v:60(59) a:0(0)    sid:229 accum[25:25],0,;	v59 = 0x0;
	v_mov_b32 v60,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[26:26]'v60    s:29(35) v:61(60) a:0(0)    sid:230 accum[26:26],0,;	v60 = 0x0;
	v_mov_b32 v61,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[27:27]'v61    s:29(35) v:62(61) a:0(0)    sid:231 accum[27:27],0,;	v61 = 0x0;
	v_mov_b32 v62,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[28:28]'v62    s:29(35) v:63(62) a:0(0)    sid:232 accum[28:28],0,;	v62 = 0x0;
	v_mov_b32 v63,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[29:29]'v63    s:29(35) v:64(63) a:0(0)    sid:233 accum[29:29],0,;	v63 = 0x0;
	v_mov_b32 v64,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[30:30]'v64    s:29(35) v:65(64) a:0(0)    sid:234 accum[30:30],0,;	v64 = 0x0;
	v_mov_b32 v65,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[31:31]'v65    s:29(35) v:66(65) a:0(0)    sid:235 accum[31:31],0,;	v65 = 0x0;
	v_mov_b32 v66,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[32:32]'v66    s:29(35) v:67(66) a:0(0)    sid:236 accum[32:32],0,;	v66 = 0x0;
	v_mov_b32 v67,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[33:33]'v67    s:29(35) v:68(67) a:0(0)    sid:237 accum[33:33],0,;	v67 = 0x0;
	v_mov_b32 v68,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[34:34]'v68    s:29(35) v:69(68) a:0(0)    sid:238 accum[34:34],0,;	v68 = 0x0;
	v_mov_b32 v69,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[35:35]'v69    s:29(35) v:70(69) a:0(0)    sid:239 accum[35:35],0,;	v69 = 0x0;
	v_mov_b32 v70,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[36:36]'v70    s:29(35) v:71(70) a:0(0)    sid:240 accum[36:36],0,;	v70 = 0x0;
	v_mov_b32 v71,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[37:37]'v71    s:29(35) v:72(71) a:0(0)    sid:241 accum[37:37],0,;	v71 = 0x0;
	v_mov_b32 v72,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[38:38]'v72    s:29(35) v:73(72) a:0(0)    sid:242 accum[38:38],0,;	v72 = 0x0;
	v_mov_b32 v73,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[39:39]'v73    s:29(35) v:74(73) a:0(0)    sid:243 accum[39:39],0,;	v73 = 0x0;
	v_mov_b32 v74,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[40:40]'v74    s:29(35) v:75(74) a:0(0)    sid:244 accum[40:40],0,;	v74 = 0x0;
	v_mov_b32 v75,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[41:41]'v75    s:29(35) v:76(75) a:0(0)    sid:245 accum[41:41],0,;	v75 = 0x0;
	v_mov_b32 v76,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[42:42]'v76    s:29(35) v:77(76) a:0(0)    sid:246 accum[42:42],0,;	v76 = 0x0;
	v_mov_b32 v77,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[43:43]'v77    s:29(35) v:78(77) a:0(0)    sid:247 accum[43:43],0,;	v77 = 0x0;
	v_mov_b32 v78,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[44:44]'v78    s:29(35) v:79(78) a:0(0)    sid:248 accum[44:44],0,;	v78 = 0x0;
	v_mov_b32 v79,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[45:45]'v79    s:29(35) v:80(79) a:0(0)    sid:249 accum[45:45],0,;	v79 = 0x0;
	v_mov_b32 v80,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[46:46]'v80    s:29(35) v:81(80) a:0(0)    sid:250 accum[46:46],0,;	v80 = 0x0;
	v_mov_b32 v81,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[47:47]'v81    s:29(35) v:82(81) a:0(0)    sid:251 accum[47:47],0,;	v81 = 0x0;
	v_mov_b32 v82,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[48:48]'v82    s:29(35) v:83(82) a:0(0)    sid:252 accum[48:48],0,;	v82 = 0x0;
	v_mov_b32 v83,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[49:49]'v83    s:29(35) v:84(83) a:0(0)    sid:253 accum[49:49],0,;	v83 = 0x0;
	v_mov_b32 v84,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[50:50]'v84    s:29(35) v:85(84) a:0(0)    sid:254 accum[50:50],0,;	v84 = 0x0;
	v_mov_b32 v85,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[51:51]'v85    s:29(35) v:86(85) a:0(0)    sid:255 accum[51:51],0,;	v85 = 0x0;
	v_mov_b32 v86,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[52:52]'v86    s:29(35) v:87(86) a:0(0)    sid:256 accum[52:52],0,;	v86 = 0x0;
	v_mov_b32 v87,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[53:53]'v87    s:29(35) v:88(87) a:0(0)    sid:257 accum[53:53],0,;	v87 = 0x0;
	v_mov_b32 v88,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[54:54]'v88    s:29(35) v:89(88) a:0(0)    sid:258 accum[54:54],0,;	v88 = 0x0;
	v_mov_b32 v89,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[55:55]'v89    s:29(35) v:90(89) a:0(0)    sid:259 accum[55:55],0,;	v89 = 0x0;
	v_mov_b32 v90,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[56:56]'v90    s:29(35) v:91(90) a:0(0)    sid:260 accum[56:56],0,;	v90 = 0x0;
	v_mov_b32 v91,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[57:57]'v91    s:29(35) v:92(91) a:0(0)    sid:261 accum[57:57],0,;	v91 = 0x0;
	v_mov_b32 v92,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[58:58]'v92    s:29(35) v:93(92) a:0(0)    sid:262 accum[58:58],0,;	v92 = 0x0;
	v_mov_b32 v93,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[59:59]'v93    s:29(35) v:94(93) a:0(0)    sid:263 accum[59:59],0,;	v93 = 0x0;
	v_mov_b32 v94,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[60:60]'v94    s:29(35) v:95(94) a:0(0)    sid:264 accum[60:60],0,;	v94 = 0x0;
	v_mov_b32 v95,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[61:61]'v95    s:29(35) v:96(95) a:0(0)    sid:265 accum[61:61],0,;	v95 = 0x0;
	v_mov_b32 v96,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[62:62]'v96    s:29(35) v:97(96) a:0(0)    sid:266 accum[62:62],0,;	v96 = 0x0;
	v_mov_b32 v97,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[63:63]'v97    s:29(35) v:98(97) a:0(0)    sid:267 accum[63:63],0,;	v97 = 0x0;
	v_mov_b32 v98,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[64:64]'v98    s:29(35) v:99(98) a:0(0)    sid:268 accum[64:64],0,;	v98 = 0x0;
	v_mov_b32 v99,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[65:65]'v99    s:29(35) v:100(99) a:0(0)    sid:269 accum[65:65],0,;	v99 = 0x0;
	v_mov_b32 v100,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[66:66]'v100    s:29(35) v:101(100) a:0(0)    sid:270 accum[66:66],0,;	v100 = 0x0;
	v_mov_b32 v101,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[67:67]'v101    s:29(35) v:102(101) a:0(0)    sid:271 accum[67:67],0,;	v101 = 0x0;
	v_mov_b32 v102,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[68:68]'v102    s:29(35) v:103(102) a:0(0)    sid:272 accum[68:68],0,;	v102 = 0x0;
	v_mov_b32 v103,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[69:69]'v103    s:29(35) v:104(103) a:0(0)    sid:273 accum[69:69],0,;	v103 = 0x0;
	v_mov_b32 v104,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[70:70]'v104    s:29(35) v:105(104) a:0(0)    sid:274 accum[70:70],0,;	v104 = 0x0;
	v_mov_b32 v105,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[71:71]'v105    s:29(35) v:106(105) a:0(0)    sid:275 accum[71:71],0,;	v105 = 0x0;
	v_mov_b32 v106,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[72:72]'v106    s:29(35) v:107(106) a:0(0)    sid:276 accum[72:72],0,;	v106 = 0x0;
	v_mov_b32 v107,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[73:73]'v107    s:29(35) v:108(107) a:0(0)    sid:277 accum[73:73],0,;	v107 = 0x0;
	v_mov_b32 v108,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[74:74]'v108    s:29(35) v:109(108) a:0(0)    sid:278 accum[74:74],0,;	v108 = 0x0;
	v_mov_b32 v109,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[75:75]'v109    s:29(35) v:110(109) a:0(0)    sid:279 accum[75:75],0,;	v109 = 0x0;
	v_mov_b32 v110,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[76:76]'v110    s:29(35) v:111(110) a:0(0)    sid:280 accum[76:76],0,;	v110 = 0x0;
	v_mov_b32 v111,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[77:77]'v111    s:29(35) v:112(111) a:0(0)    sid:281 accum[77:77],0,;	v111 = 0x0;
	v_mov_b32 v112,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[78:78]'v112    s:29(35) v:113(112) a:0(0)    sid:282 accum[78:78],0,;	v112 = 0x0;
	v_mov_b32 v113,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[79:79]'v113    s:29(35) v:114(113) a:0(0)    sid:283 accum[79:79],0,;	v113 = 0x0;
	v_mov_b32 v114,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[80:80]'v114    s:29(35) v:115(114) a:0(0)    sid:284 accum[80:80],0,;	v114 = 0x0;
	v_mov_b32 v115,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[81:81]'v115    s:29(35) v:116(115) a:0(0)    sid:285 accum[81:81],0,;	v115 = 0x0;
	v_mov_b32 v116,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[82:82]'v116    s:29(35) v:117(116) a:0(0)    sid:286 accum[82:82],0,;	v116 = 0x0;
	v_mov_b32 v117,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[83:83]'v117    s:29(35) v:118(117) a:0(0)    sid:287 accum[83:83],0,;	v117 = 0x0;
	v_mov_b32 v118,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[84:84]'v118    s:29(35) v:119(118) a:0(0)    sid:288 accum[84:84],0,;	v118 = 0x0;
	v_mov_b32 v119,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[85:85]'v119    s:29(35) v:120(119) a:0(0)    sid:289 accum[85:85],0,;	v119 = 0x0;
	v_mov_b32 v120,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[86:86]'v120    s:29(35) v:121(120) a:0(0)    sid:290 accum[86:86],0,;	v120 = 0x0;
	v_mov_b32 v121,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[87:87]'v121    s:29(35) v:122(121) a:0(0)    sid:291 accum[87:87],0,;	v121 = 0x0;
	v_mov_b32 v122,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[88:88]'v122    s:29(35) v:123(122) a:0(0)    sid:292 accum[88:88],0,;	v122 = 0x0;
	v_mov_b32 v123,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[89:89]'v123    s:29(35) v:124(123) a:0(0)    sid:293 accum[89:89],0,;	v123 = 0x0;
	v_mov_b32 v124,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[90:90]'v124    s:29(35) v:125(124) a:0(0)    sid:294 accum[90:90],0,;	v124 = 0x0;
	v_mov_b32 v125,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[91:91]'v125    s:29(35) v:126(125) a:0(0)    sid:295 accum[91:91],0,;	v125 = 0x0;
	v_mov_b32 v126,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[92:92]'v126    s:29(35) v:127(126) a:0(0)    sid:296 accum[92:92],0,;	v126 = 0x0;
	v_mov_b32 v127,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[93:93]'v127    s:29(35) v:128(127) a:0(0)    sid:297 accum[93:93],0,;	v127 = 0x0;
	v_mov_b32 v128,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[94:94]'v128    s:29(35) v:129(128) a:0(0)    sid:298 accum[94:94],0,;	v128 = 0x0;
	v_mov_b32 v129,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[95:95]'v129    s:29(35) v:130(129) a:0(0)    sid:299 accum[95:95],0,;	v129 = 0x0;
	v_mov_b32 v130,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[96:96]'v130    s:29(35) v:131(130) a:0(0)    sid:300 accum[96:96],0,;	v130 = 0x0;
	v_mov_b32 v131,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[97:97]'v131    s:29(35) v:132(131) a:0(0)    sid:301 accum[97:97],0,;	v131 = 0x0;
	v_mov_b32 v132,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[98:98]'v132    s:29(35) v:133(132) a:0(0)    sid:302 accum[98:98],0,;	v132 = 0x0;
	v_mov_b32 v133,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[99:99]'v133    s:29(35) v:134(133) a:0(0)    sid:303 accum[99:99],0,;	v133 = 0x0;
	v_mov_b32 v134,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[100:100]'v134    s:29(35) v:135(134) a:0(0)    sid:304 accum[100:100],0,;	v134 = 0x0;
	v_mov_b32 v135,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[101:101]'v135    s:29(35) v:136(135) a:0(0)    sid:305 accum[101:101],0,;	v135 = 0x0;
	v_mov_b32 v136,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[102:102]'v136    s:29(35) v:137(136) a:0(0)    sid:306 accum[102:102],0,;	v136 = 0x0;
	v_mov_b32 v137,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[103:103]'v137    s:29(35) v:138(137) a:0(0)    sid:307 accum[103:103],0,;	v137 = 0x0;
	v_mov_b32 v138,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[104:104]'v138    s:29(35) v:139(138) a:0(0)    sid:308 accum[104:104],0,;	v138 = 0x0;
	v_mov_b32 v139,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[105:105]'v139    s:29(35) v:140(139) a:0(0)    sid:309 accum[105:105],0,;	v139 = 0x0;
	v_mov_b32 v140,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[106:106]'v140    s:29(35) v:141(140) a:0(0)    sid:310 accum[106:106],0,;	v140 = 0x0;
	v_mov_b32 v141,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[107:107]'v141    s:29(35) v:142(141) a:0(0)    sid:311 accum[107:107],0,;	v141 = 0x0;
	v_mov_b32 v142,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[108:108]'v142    s:29(35) v:143(142) a:0(0)    sid:312 accum[108:108],0,;	v142 = 0x0;
	v_mov_b32 v143,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[109:109]'v143    s:29(35) v:144(143) a:0(0)    sid:313 accum[109:109],0,;	v143 = 0x0;
	v_mov_b32 v144,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[110:110]'v144    s:29(35) v:145(144) a:0(0)    sid:314 accum[110:110],0,;	v144 = 0x0;
	v_mov_b32 v145,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[111:111]'v145    s:29(35) v:146(145) a:0(0)    sid:315 accum[111:111],0,;	v145 = 0x0;
	v_mov_b32 v146,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[112:112]'v146    s:29(35) v:147(146) a:0(0)    sid:316 accum[112:112],0,;	v146 = 0x0;
	v_mov_b32 v147,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[113:113]'v147    s:29(35) v:148(147) a:0(0)    sid:317 accum[113:113],0,;	v147 = 0x0;
	v_mov_b32 v148,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[114:114]'v148    s:29(35) v:149(148) a:0(0)    sid:318 accum[114:114],0,;	v148 = 0x0;
	v_mov_b32 v149,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[115:115]'v149    s:29(35) v:150(149) a:0(0)    sid:319 accum[115:115],0,;	v149 = 0x0;
	v_mov_b32 v150,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[116:116]'v150    s:29(35) v:151(150) a:0(0)    sid:320 accum[116:116],0,;	v150 = 0x0;
	v_mov_b32 v151,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[117:117]'v151    s:29(35) v:152(151) a:0(0)    sid:321 accum[117:117],0,;	v151 = 0x0;
	v_mov_b32 v152,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[118:118]'v152    s:29(35) v:153(152) a:0(0)    sid:322 accum[118:118],0,;	v152 = 0x0;
	v_mov_b32 v153,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[119:119]'v153    s:29(35) v:154(153) a:0(0)    sid:323 accum[119:119],0,;	v153 = 0x0;
	v_mov_b32 v154,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[120:120]'v154    s:29(35) v:155(154) a:0(0)    sid:324 accum[120:120],0,;	v154 = 0x0;
	v_mov_b32 v155,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[121:121]'v155    s:29(35) v:156(155) a:0(0)    sid:325 accum[121:121],0,;	v155 = 0x0;
	v_mov_b32 v156,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[122:122]'v156    s:29(35) v:157(156) a:0(0)    sid:326 accum[122:122],0,;	v156 = 0x0;
	v_mov_b32 v157,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[123:123]'v157    s:29(35) v:158(157) a:0(0)    sid:327 accum[123:123],0,;	v157 = 0x0;
	v_mov_b32 v158,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[124:124]'v158    s:29(35) v:159(158) a:0(0)    sid:328 accum[124:124],0,;	v158 = 0x0;
	v_mov_b32 v159,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[125:125]'v159    s:29(35) v:160(159) a:0(0)    sid:329 accum[125:125],0,;	v159 = 0x0;
	v_mov_b32 v160,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[126:126]'v160    s:29(35) v:161(160) a:0(0)    sid:330 accum[126:126],0,;	v160 = 0x0;
	v_mov_b32 v161,0x0  ; # gemm_fp8_gfx942.py:96 alloc 'accum[127:127]'v161    s:29(35) v:162(161) a:0(0)    sid:331 accum[127:127],0,;	v161 = 0x0;
	s_mov_b32 s12,0x0  ; # asmjit.py:1627 gemm_fp8_gfx942.py:97 alloc 'k_offset's12    s:30(35) v:162(161) a:0(0)    sid:332 k_offset,0,;	s12 = 0x0
	s_mov_b32 s13,0x0  ; # asmjit.py:1627 gemm_fp8_gfx942.py:98 alloc 'scale_offset's13    s:31(35) v:162(161) a:0(0)    sid:333 scale_offset,0,;	s13 = 0x0
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'idst's17    s:32(35) v:162(161) a:0(0)    sid:334 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v4,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17 alloc 'staging_b[0:3]'v[164:167]    s:31(35) v:166(167) a:0(0)    sid:335 staging_b[0:3],load_b[0:0],self.desc,idst,
	buffer_load_dwordx4 v[168:171],v15,s[24:27],s12 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'operands_a[0:3]'v[168:171]    s:31(35) v:170(171) a:0(0)    sid:336 operands_a[0:3],load_a[0:0],self.desc,k_offset,
	buffer_load_dwordx4 v[172:175],v12,s[24:27],s12 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'operands_a[4:7]'v[172:175]    s:31(35) v:174(175) a:0(0)    sid:337 operands_a[4:7],load_a[1:1],self.desc,k_offset,
	buffer_load_dword v162,v11,s[8:11],s13 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:104 alloc 'scale_a[0:0]'v162    s:31(35) v:175(175) a:0(0)    sid:338 scale_a[0:0],load_scale_a[0:0],self.desc,scale_offset,
	buffer_load_dwordx4 v[176:179],v14,s[24:27],s12 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'operands_a[8:11]'v[176:179]    s:31(35) v:179(179) a:0(0)    sid:339 operands_a[8:11],load_a[2:2],self.desc,k_offset,
	buffer_load_dwordx4 v[180:183],v16,s[24:27],s12 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'operands_a[12:15]'v[180:183]    s:31(35) v:183(183) a:0(0)    sid:340 operands_a[12:15],load_a[3:3],self.desc,k_offset,
	buffer_load_dword v163,v10,s[8:11],s13 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:104 alloc 'scale_a[1:1]'v163    s:31(35) v:184(183) a:0(0)    sid:341 scale_a[1:1],load_scale_a[1:1],self.desc,scale_offset,
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:115 alloc 'src1_gprs's17    s:32(35) v:184(183) a:0(0)    sid:342 src1_gprs,k_offset,5,
	s_add_u32 s17,s6,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'idst's17    s:32(35) v:184(183) a:0(0)    sid:343 idst,scale_offset_b,src1_gprs,;	s17.u32 = s6 + s17; scc=overflow_or_carry
	s_load_dword s20,s[14:15],s17  ; # gemm_fp8_gfx942.py:115 free 'idst's17 alloc 'scale_b's[20:23]    s:35(35) v:184(183) a:0(0)    sid:344 scale_b,pScaleB,idst,;	s20 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:115 alloc 'src1_gprs's17    s:36(35) v:184(183) a:0(0)    sid:345 src1_gprs,k_offset,5,
	s_add_u32 s17,s7,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:184(183) a:0(0)    sid:346 idst,scale_offset_b,src1_gprs,;	s17.u32 = s7 + s17; scc=overflow_or_carry
	s_load_dword s21,s[14:15],s17  ; # gemm_fp8_gfx942.py:115 free 'idst's17   sid:347 scale_b,pScaleB,idst,;	s21 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_waitcnt  vmcnt(6) ; # gemm_fp8_gfx942.py:212   sid:348 
	ds_write_b128 v2,v[164:167] offset:0 ; # gemm_fp8_gfx942.py:213   sid:349 write_b,staging_b[0:3],;	LDS_MEM[v2 + 0].b128 = v[164:167].b128
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'idst's17    s:36(35) v:184(183) a:0(0)    sid:350 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v7,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:351 staging_b[0:3],load_b[1:1],self.desc,idst,
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'idst's17    s:36(35) v:184(183) a:0(0)    sid:352 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v8,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17 alloc 'staging_b[4:7]'v[184:187]    s:35(35) v:188(187) a:0(0)    sid:353 staging_b[4:7],load_b[2:2],self.desc,idst,
	s_waitcnt  vmcnt(2) lgkmcnt(0) ; # gemm_fp8_gfx942.py:216   sid:354 
	s_barrier   ; # gemm_fp8_gfx942.py:217   sid:355 
	s_cmp_eq_u32 s16,0x1  ; # asmjit.py:1421 contextlib.py:137   sid:356 group,1,;	scc = (s16.u32 == 0x1.u32)
	s_cbranch_scc0  _if_else_218_1 ; # asmjit.py:1367 asmjit.py:1421 contextlib.py:137   sid:357;	jump if scc is 0 (scc == 0)
_bb_no_name_3:	 ;BB#3 predecessors:[_if_else_28_0] successors:[_if_else_218_1]
	s_barrier   ; # gemm_fp8_gfx942.py:219   sid:358 
_if_else_218_1:	 ;BB#4 predecessors:[_bb_no_name_3,_if_else_28_0] successors:[_while_begin_225_2]
	s_waitcnt  vmcnt(1) ; # gemm_fp8_gfx942.py:154   sid:359 
	ds_write_b128 v2,v[164:167] offset:8192 ; # gemm_fp8_gfx942.py:155   sid:360 write_b,staging_b[0:3],;	LDS_MEM[v2 + 8192].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:188(187) a:0(0)    sid:361 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[188:191],v15,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17 alloc 'operands_a[16:19]'v[188:191]    s:35(35) v:192(191) a:0(0)    sid:362 operands_a[16:19],load_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 alloc 'src1_gprs's17    s:36(35) v:192(191) a:0(0)    sid:363 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:192(191) a:0(0)    sid:364 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v192,v11,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'idst's17 alloc 'scale_a[2:2]'v192    s:35(35) v:193(192) a:0(0)    sid:365 scale_a[2:2],load_scale_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'idst's17    s:36(35) v:193(192) a:0(0)    sid:366 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v3,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:367 staging_b[0:3],load_b[3:3],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:0 ; # gemm_fp8_gfx942.py:166 alloc 'operands_b[0:3]'v[196:199]    s:35(35) v:197(199) a:0(0)    sid:368 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:0 ; # gemm_fp8_gfx942.py:166 alloc 'operands_b[4:7]'v[200:203]    s:35(35) v:201(203) a:0(0)    sid:369 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:2048 ; # gemm_fp8_gfx942.py:166 alloc 'operands_b[8:11]'v[204:207]    s:35(35) v:205(207) a:0(0)    sid:370 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:2048 ; # gemm_fp8_gfx942.py:166 alloc 'operands_b[12:15]'v[208:211]    s:35(35) v:209(211) a:0(0)    sid:371 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:4096 ; # gemm_fp8_gfx942.py:166 alloc 'operands_b[16:19]'v[212:215]    s:35(35) v:213(215) a:0(0)    sid:372 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:4096 ; # gemm_fp8_gfx942.py:166 alloc 'operands_b[20:23]'v[216:219]    s:35(35) v:217(219) a:0(0)    sid:373 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:6144 ; # gemm_fp8_gfx942.py:166 alloc 'operands_b[24:27]'v[220:223]    s:35(35) v:221(223) a:0(0)    sid:374 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 6144].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:6144 ; # gemm_fp8_gfx942.py:166 alloc 'operands_b[28:31]'v[224:227]    s:35(35) v:225(227) a:0(0)    sid:375 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 6144].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:376 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:377 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:378 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:379 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:380 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s20,v162  ; # gemm_fp8_gfx942.py:190   sid:381 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v154,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:382 accum[120:120],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:383 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v155,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:384 accum[121:121],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:385 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v156,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:386 accum[122:122],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:387 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v157,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:388 accum[123:123],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:389 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v158,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:390 accum[124:124],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:391 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v159,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:392 accum[125:125],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:393 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v160,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:394 accum[126:126],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:395 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v161,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:396 accum[127:127],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:397 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v18,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:398 accum[0:0],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:399 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v19,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:400 accum[1:1],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:401 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v36,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:402 accum[2:2],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:403 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v37,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:404 accum[3:3],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:405 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v38,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:406 accum[4:4],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:407 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v39,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:408 accum[5:5],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:409 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v40,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:410 accum[6:6],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:411 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v41,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:412 accum[7:7],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:413 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s20,v163  ; # gemm_fp8_gfx942.py:190   sid:414 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v42,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:415 accum[8:8],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:416 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v43,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:417 accum[9:9],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:418 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v44,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:419 accum[10:10],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:420 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v45,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:421 accum[11:11],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:422 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v46,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:423 accum[12:12],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:424 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v47,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:425 accum[13:13],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:426 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v48,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:427 accum[14:14],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:428 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v49,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:429 accum[15:15],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:430 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v98,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:431 accum[64:64],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:432 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v99,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:433 accum[65:65],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:434 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v100,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:435 accum[66:66],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:436 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v101,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:437 accum[67:67],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:438 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v102,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:439 accum[68:68],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:440 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v103,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:441 accum[69:69],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:442 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v104,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:443 accum[70:70],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:444 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:445 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v105,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:446 accum[71:71],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:447 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:154   sid:448 
	ds_write_b128 v2,v[184:187] offset:16384 ; # gemm_fp8_gfx942.py:155   sid:449 write_b,staging_b[4:7],;	LDS_MEM[v2 + 16384].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:225(227) a:0(0)    sid:450 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[228:231],v14,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17 alloc 'operands_a[24:27]'v[228:231]    s:35(35) v:229(231) a:0(0)    sid:451 operands_a[24:27],load_a[2:2],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 alloc 'src1_gprs's17    s:36(35) v:229(231) a:0(0)    sid:452 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:229(231) a:0(0)    sid:453 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v193,v10,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'idst's17 alloc 'scale_a[3:3]'v193    s:35(35) v:230(231) a:0(0)    sid:454 scale_a[3:3],load_scale_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'src0_gprs's17    s:36(35) v:230(231) a:0(0)    sid:455 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'src0_gprs's17 alloc 'idst's17    s:36(35) v:230(231) a:0(0)    sid:456 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v4,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:457 staging_b[4:7],load_b[0:0],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:8192 ; # gemm_fp8_gfx942.py:166   sid:458 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:8192 ; # gemm_fp8_gfx942.py:166   sid:459 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:10240 ; # gemm_fp8_gfx942.py:166   sid:460 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:10240 ; # gemm_fp8_gfx942.py:166   sid:461 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:12288 ; # gemm_fp8_gfx942.py:166   sid:462 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:12288 ; # gemm_fp8_gfx942.py:166   sid:463 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:14336 ; # gemm_fp8_gfx942.py:166   sid:464 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 14336].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:14336 ; # gemm_fp8_gfx942.py:166   sid:465 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 14336].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:466 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:467 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:468 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:469 
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:115 alloc 'src1_gprs's17    s:36(35) v:230(231) a:0(0)    sid:470 src1_gprs,k_offset,5,
	s_add_u32 s17,s6,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'src1_gprs's17    s:36(35) v:230(231) a:0(0)    sid:471 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s6 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:230(231) a:0(0)    sid:472 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s22,s[14:15],s17  ; # gemm_fp8_gfx942.py:115 free 'idst's17   sid:473 scale_b,pScaleB,idst,;	s22 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:115 alloc 'src1_gprs's17    s:36(35) v:230(231) a:0(0)    sid:474 src1_gprs,k_offset,5,
	s_add_u32 s17,s7,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'src1_gprs's17    s:36(35) v:230(231) a:0(0)    sid:475 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s7 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:230(231) a:0(0)    sid:476 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s23,s[14:15],s17  ; # gemm_fp8_gfx942.py:115 free 'idst's17   sid:477 scale_b,pScaleB,idst,;	s23 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:478 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s20,v162  ; # gemm_fp8_gfx942.py:190   sid:479 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v106,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:480 accum[72:72],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:481 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v107,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:482 accum[73:73],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:483 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v108,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:484 accum[74:74],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:485 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v109,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:486 accum[75:75],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:487 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v110,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:488 accum[76:76],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:489 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v111,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:490 accum[77:77],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:491 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v112,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:492 accum[78:78],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:493 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v113,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:494 accum[79:79],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:495 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v50,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:496 accum[16:16],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:497 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v51,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:498 accum[17:17],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:499 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v52,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:500 accum[18:18],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:501 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v53,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:502 accum[19:19],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:503 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v54,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:504 accum[20:20],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:505 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v55,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:506 accum[21:21],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:507 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v56,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:508 accum[22:22],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:509 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v57,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:510 accum[23:23],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:511 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s20,v163  ; # gemm_fp8_gfx942.py:190   sid:512 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v58,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:513 accum[24:24],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:514 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v59,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:515 accum[25:25],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:516 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v60,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:517 accum[26:26],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:518 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v61,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:519 accum[27:27],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:520 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v62,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:521 accum[28:28],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:522 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v63,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:523 accum[29:29],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:524 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v64,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:525 accum[30:30],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:526 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v65,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:527 accum[31:31],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:528 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v114,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:529 accum[80:80],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:530 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v115,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:531 accum[81:81],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:532 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v116,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:533 accum[82:82],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:534 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v117,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:535 accum[83:83],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:536 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v118,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:537 accum[84:84],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:538 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v119,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:539 accum[85:85],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:540 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v120,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:541 accum[86:86],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:542 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:543 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v121,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:544 accum[87:87],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:545 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:154   sid:546 
	ds_write_b128 v2,v[164:167] offset:24576 ; # gemm_fp8_gfx942.py:155   sid:547 write_b,staging_b[0:3],;	LDS_MEM[v2 + 24576].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:230(231) a:0(0)    sid:548 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[232:235],v12,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17 alloc 'operands_a[20:23]'v[232:235]    s:35(35) v:234(235) a:0(0)    sid:549 operands_a[20:23],load_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'src0_gprs's17    s:36(35) v:234(235) a:0(0)    sid:550 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'src0_gprs's17 alloc 'idst's17    s:36(35) v:234(235) a:0(0)    sid:551 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v7,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:552 staging_b[0:3],load_b[1:1],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:16384 ; # gemm_fp8_gfx942.py:166   sid:553 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:16384 ; # gemm_fp8_gfx942.py:166   sid:554 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:18432 ; # gemm_fp8_gfx942.py:166   sid:555 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:18432 ; # gemm_fp8_gfx942.py:166   sid:556 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:20480 ; # gemm_fp8_gfx942.py:166   sid:557 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:20480 ; # gemm_fp8_gfx942.py:166   sid:558 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:22528 ; # gemm_fp8_gfx942.py:166   sid:559 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 22528].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:22528 ; # gemm_fp8_gfx942.py:166   sid:560 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 22528].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:561 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:562 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:563 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:564 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:565 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s21,v162  ; # gemm_fp8_gfx942.py:190   sid:566 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v122,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:567 accum[88:88],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:568 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v123,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:569 accum[89:89],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:570 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v124,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:571 accum[90:90],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:572 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v125,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:573 accum[91:91],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:574 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v126,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:575 accum[92:92],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:576 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v127,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:577 accum[93:93],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:578 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v128,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:579 accum[94:94],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:580 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v129,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:581 accum[95:95],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:582 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v66,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:583 accum[32:32],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:584 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v67,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:585 accum[33:33],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:586 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v68,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:587 accum[34:34],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:588 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v69,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:589 accum[35:35],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:590 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v70,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:591 accum[36:36],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:592 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v71,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:593 accum[37:37],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:594 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v72,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:595 accum[38:38],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:596 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v73,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:597 accum[39:39],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:598 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s21,v163  ; # gemm_fp8_gfx942.py:190   sid:599 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v74,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:600 accum[40:40],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:601 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v75,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:602 accum[41:41],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:603 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v76,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:604 accum[42:42],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:605 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v77,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:606 accum[43:43],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:607 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v78,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:608 accum[44:44],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:609 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v79,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:610 accum[45:45],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:611 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v80,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:612 accum[46:46],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:613 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v81,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:614 accum[47:47],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:615 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v130,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:616 accum[96:96],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:617 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v131,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:618 accum[97:97],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:619 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v132,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:620 accum[98:98],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:621 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v133,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:622 accum[99:99],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:623 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v134,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:624 accum[100:100],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:625 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v135,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:626 accum[101:101],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:627 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v136,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:628 accum[102:102],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:629 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:630 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v137,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:631 accum[103:103],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:632 0,
	s_waitcnt  vmcnt(2) ; # gemm_fp8_gfx942.py:154   sid:633 
	ds_write_b128 v2,v[184:187] offset:0 ; # gemm_fp8_gfx942.py:155   sid:634 write_b,staging_b[4:7],;	LDS_MEM[v2 + 0].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:234(235) a:0(0)    sid:635 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[236:239],v16,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17 alloc 'operands_a[28:31]'v[236:239]    s:35(35) v:238(239) a:0(0)    sid:636 operands_a[28:31],load_a[3:3],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'src0_gprs's17    s:36(35) v:238(239) a:0(0)    sid:637 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'src0_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:638 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v8,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:639 staging_b[4:7],load_b[2:2],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:24576 ; # gemm_fp8_gfx942.py:166   sid:640 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:24576 ; # gemm_fp8_gfx942.py:166   sid:641 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:26624 ; # gemm_fp8_gfx942.py:166   sid:642 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:26624 ; # gemm_fp8_gfx942.py:166   sid:643 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:28672 ; # gemm_fp8_gfx942.py:166   sid:644 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:28672 ; # gemm_fp8_gfx942.py:166   sid:645 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:30720 ; # gemm_fp8_gfx942.py:166   sid:646 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 30720].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:30720 ; # gemm_fp8_gfx942.py:166   sid:647 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 30720].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:648 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:649 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:650 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:651 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:652 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s21,v162  ; # gemm_fp8_gfx942.py:190   sid:653 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v138,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:654 accum[104:104],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:655 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v139,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:656 accum[105:105],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:657 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v140,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:658 accum[106:106],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:659 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v141,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:660 accum[107:107],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:661 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v142,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:662 accum[108:108],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:663 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v143,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:664 accum[109:109],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:665 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v144,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:666 accum[110:110],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:667 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v145,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:668 accum[111:111],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:669 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v82,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:670 accum[48:48],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:671 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v83,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:672 accum[49:49],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:673 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v84,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:674 accum[50:50],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:675 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v85,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:676 accum[51:51],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:677 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v86,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:678 accum[52:52],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:679 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v87,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:680 accum[53:53],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:681 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v88,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:682 accum[54:54],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:683 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v89,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:684 accum[55:55],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:685 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s21,v163  ; # gemm_fp8_gfx942.py:190   sid:686 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v90,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:687 accum[56:56],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:688 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v91,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:689 accum[57:57],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:690 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v92,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:691 accum[58:58],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:692 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v93,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:693 accum[59:59],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:694 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v94,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:695 accum[60:60],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:696 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v95,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:697 accum[61:61],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:698 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v96,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:699 accum[62:62],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:700 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v97,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:701 accum[63:63],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:702 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v146,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:703 accum[112:112],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:704 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v147,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:705 accum[113:113],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:706 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v148,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:707 accum[114:114],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:708 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v149,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:709 accum[115:115],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:710 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v150,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:711 accum[116:116],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:712 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v151,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:713 accum[117:117],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:714 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v152,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:715 accum[118:118],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:716 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:717 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v153,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:718 accum[119:119],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:719 0,
	s_add_u32 s12,0x80,s12  ; # gemm_fp8_gfx942.py:205   sid:720 k_offset,128,k_offset,;	s12.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s5,0x2  ; # gemm_fp8_gfx942.py:206 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:721 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s13,s13,s17  ; # gemm_fp8_gfx942.py:206 free 'src1_gprs's17   sid:722 scale_offset,scale_offset,src1_gprs,;	s13.u32 = s13 + s17; scc=overflow_or_carry
_while_begin_225_2:	 ;BB#5 predecessors:[_if_else_218_1,_bb_no_name_6] successors:[_bb_no_name_6,_while_end_225_2]
	s_cmp_lt_u32 s12,0x3f80  ; # asmjit.py:1381 contextlib.py:137   sid:723 k_offset,16256,;	scc = (s12.u32 < 0x3f80.u32)
	s_cbranch_scc0  _while_end_225_2 ; # asmjit.py:1367 asmjit.py:1381 contextlib.py:137   sid:724;	jump if scc is 0 (scc == 0)
_bb_no_name_6:	 ;BB#6 predecessors:[_while_begin_225_2] successors:[_while_begin_225_2]
	s_waitcnt  vmcnt(1) ; # gemm_fp8_gfx942.py:154   sid:725 
	ds_write_b128 v2,v[164:167] offset:8192 ; # gemm_fp8_gfx942.py:155   sid:726 write_b,staging_b[0:3],;	LDS_MEM[v2 + 8192].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:727 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[168:171],v15,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17   sid:728 operands_a[0:3],load_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:729 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:730 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v162,v11,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'idst's17   sid:731 scale_a[0:0],load_scale_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:732 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v3,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:733 staging_b[0:3],load_b[3:3],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:0 ; # gemm_fp8_gfx942.py:166   sid:734 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:0 ; # gemm_fp8_gfx942.py:166   sid:735 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:2048 ; # gemm_fp8_gfx942.py:166   sid:736 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:2048 ; # gemm_fp8_gfx942.py:166   sid:737 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:4096 ; # gemm_fp8_gfx942.py:166   sid:738 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:4096 ; # gemm_fp8_gfx942.py:166   sid:739 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:6144 ; # gemm_fp8_gfx942.py:166   sid:740 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 6144].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:6144 ; # gemm_fp8_gfx942.py:166   sid:741 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 6144].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:742 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:743 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:744 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:745 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:746 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s22,v192  ; # gemm_fp8_gfx942.py:190   sid:747 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v154,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:748 accum[120:120],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:749 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v155,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:750 accum[121:121],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:751 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v156,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:752 accum[122:122],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:753 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v157,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:754 accum[123:123],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:755 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v158,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:756 accum[124:124],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:757 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v159,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:758 accum[125:125],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:759 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v160,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:760 accum[126:126],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:761 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v161,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:762 accum[127:127],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:763 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v18,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:764 accum[0:0],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:765 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v19,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:766 accum[1:1],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:767 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v36,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:768 accum[2:2],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:769 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v37,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:770 accum[3:3],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:771 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v38,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:772 accum[4:4],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:773 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v39,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:774 accum[5:5],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:775 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v40,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:776 accum[6:6],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:777 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v41,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:778 accum[7:7],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:779 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s22,v193  ; # gemm_fp8_gfx942.py:190   sid:780 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v42,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:781 accum[8:8],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:782 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v43,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:783 accum[9:9],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:784 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v44,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:785 accum[10:10],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:786 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v45,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:787 accum[11:11],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:788 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v46,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:789 accum[12:12],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:790 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v47,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:791 accum[13:13],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:792 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v48,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:793 accum[14:14],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:794 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v49,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:795 accum[15:15],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:796 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v98,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:797 accum[64:64],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:798 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v99,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:799 accum[65:65],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:800 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v100,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:801 accum[66:66],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:802 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v101,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:803 accum[67:67],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:804 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v102,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:805 accum[68:68],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:806 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v103,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:807 accum[69:69],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:808 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v104,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:809 accum[70:70],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:810 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:811 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v105,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:812 accum[71:71],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:813 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:154   sid:814 
	ds_write_b128 v2,v[184:187] offset:16384 ; # gemm_fp8_gfx942.py:155   sid:815 write_b,staging_b[4:7],;	LDS_MEM[v2 + 16384].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:816 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[176:179],v14,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17   sid:817 operands_a[8:11],load_a[2:2],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:818 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:819 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v163,v10,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'idst's17   sid:820 scale_a[1:1],load_scale_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'src0_gprs's17    s:36(35) v:238(239) a:0(0)    sid:821 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'src0_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:822 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v4,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:823 staging_b[4:7],load_b[0:0],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:8192 ; # gemm_fp8_gfx942.py:166   sid:824 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:8192 ; # gemm_fp8_gfx942.py:166   sid:825 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:10240 ; # gemm_fp8_gfx942.py:166   sid:826 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:10240 ; # gemm_fp8_gfx942.py:166   sid:827 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:12288 ; # gemm_fp8_gfx942.py:166   sid:828 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:12288 ; # gemm_fp8_gfx942.py:166   sid:829 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:14336 ; # gemm_fp8_gfx942.py:166   sid:830 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 14336].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:14336 ; # gemm_fp8_gfx942.py:166   sid:831 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 14336].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:832 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:833 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:834 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:835 
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:115 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:836 src1_gprs,k_offset,5,
	s_add_u32 s17,s6,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:837 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s6 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:838 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s20,s[14:15],s17  ; # gemm_fp8_gfx942.py:115 free 'idst's17   sid:839 scale_b,pScaleB,idst,;	s20 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:115 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:840 src1_gprs,k_offset,5,
	s_add_u32 s17,s7,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:841 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s7 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:842 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s21,s[14:15],s17  ; # gemm_fp8_gfx942.py:115 free 'idst's17   sid:843 scale_b,pScaleB,idst,;	s21 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:844 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s22,v192  ; # gemm_fp8_gfx942.py:190   sid:845 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v106,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:846 accum[72:72],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:847 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v107,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:848 accum[73:73],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:849 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v108,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:850 accum[74:74],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:851 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v109,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:852 accum[75:75],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:853 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v110,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:854 accum[76:76],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:855 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v111,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:856 accum[77:77],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:857 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v112,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:858 accum[78:78],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:859 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v113,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:860 accum[79:79],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:861 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v50,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:862 accum[16:16],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:863 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v51,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:864 accum[17:17],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:865 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v52,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:866 accum[18:18],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:867 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v53,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:868 accum[19:19],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:869 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v54,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:870 accum[20:20],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:871 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v55,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:872 accum[21:21],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:873 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v56,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:874 accum[22:22],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:875 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v57,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:876 accum[23:23],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:877 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s22,v193  ; # gemm_fp8_gfx942.py:190   sid:878 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v58,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:879 accum[24:24],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:880 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v59,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:881 accum[25:25],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:882 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v60,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:883 accum[26:26],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:884 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v61,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:885 accum[27:27],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:886 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v62,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:887 accum[28:28],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:888 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v63,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:889 accum[29:29],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:890 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v64,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:891 accum[30:30],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:892 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v65,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:893 accum[31:31],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:894 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v114,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:895 accum[80:80],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:896 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v115,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:897 accum[81:81],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:898 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v116,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:899 accum[82:82],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:900 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v117,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:901 accum[83:83],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:902 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v118,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:903 accum[84:84],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:904 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v119,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:905 accum[85:85],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:906 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v120,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:907 accum[86:86],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:908 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:909 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v121,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:910 accum[87:87],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:911 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:154   sid:912 
	ds_write_b128 v2,v[164:167] offset:24576 ; # gemm_fp8_gfx942.py:155   sid:913 write_b,staging_b[0:3],;	LDS_MEM[v2 + 24576].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:914 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[172:175],v12,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17   sid:915 operands_a[4:7],load_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'src0_gprs's17    s:36(35) v:238(239) a:0(0)    sid:916 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'src0_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:917 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v7,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:918 staging_b[0:3],load_b[1:1],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:16384 ; # gemm_fp8_gfx942.py:166   sid:919 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:16384 ; # gemm_fp8_gfx942.py:166   sid:920 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:18432 ; # gemm_fp8_gfx942.py:166   sid:921 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:18432 ; # gemm_fp8_gfx942.py:166   sid:922 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:20480 ; # gemm_fp8_gfx942.py:166   sid:923 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:20480 ; # gemm_fp8_gfx942.py:166   sid:924 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:22528 ; # gemm_fp8_gfx942.py:166   sid:925 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 22528].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:22528 ; # gemm_fp8_gfx942.py:166   sid:926 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 22528].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:927 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:928 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:929 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:930 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:931 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s23,v192  ; # gemm_fp8_gfx942.py:190   sid:932 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v122,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:933 accum[88:88],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:934 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v123,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:935 accum[89:89],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:936 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v124,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:937 accum[90:90],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:938 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v125,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:939 accum[91:91],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:940 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v126,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:941 accum[92:92],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:942 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v127,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:943 accum[93:93],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:944 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v128,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:945 accum[94:94],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:946 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v129,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:947 accum[95:95],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:948 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v66,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:949 accum[32:32],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:950 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v67,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:951 accum[33:33],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:952 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v68,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:953 accum[34:34],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:954 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v69,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:955 accum[35:35],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:956 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v70,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:957 accum[36:36],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:958 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v71,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:959 accum[37:37],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:960 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v72,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:961 accum[38:38],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:962 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v73,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:963 accum[39:39],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:964 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s23,v193  ; # gemm_fp8_gfx942.py:190   sid:965 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v74,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:966 accum[40:40],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:967 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v75,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:968 accum[41:41],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:969 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v76,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:970 accum[42:42],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:971 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v77,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:972 accum[43:43],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:973 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v78,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:974 accum[44:44],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:975 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v79,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:976 accum[45:45],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:977 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v80,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:978 accum[46:46],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:979 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v81,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:980 accum[47:47],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:981 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v130,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:982 accum[96:96],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:983 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v131,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:984 accum[97:97],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:985 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v132,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:986 accum[98:98],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:987 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v133,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:988 accum[99:99],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:989 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v134,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:990 accum[100:100],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:991 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v135,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:992 accum[101:101],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:993 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v136,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:994 accum[102:102],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:995 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:996 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v137,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:997 accum[103:103],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:998 0,
	s_waitcnt  vmcnt(2) ; # gemm_fp8_gfx942.py:154   sid:999 
	ds_write_b128 v2,v[184:187] offset:0 ; # gemm_fp8_gfx942.py:155   sid:1000 write_b,staging_b[4:7],;	LDS_MEM[v2 + 0].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1001 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[180:183],v16,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17   sid:1002 operands_a[12:15],load_a[3:3],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'src0_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1003 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'src0_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1004 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v8,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:1005 staging_b[4:7],load_b[2:2],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:24576 ; # gemm_fp8_gfx942.py:166   sid:1006 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:24576 ; # gemm_fp8_gfx942.py:166   sid:1007 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:26624 ; # gemm_fp8_gfx942.py:166   sid:1008 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:26624 ; # gemm_fp8_gfx942.py:166   sid:1009 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:28672 ; # gemm_fp8_gfx942.py:166   sid:1010 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:28672 ; # gemm_fp8_gfx942.py:166   sid:1011 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:30720 ; # gemm_fp8_gfx942.py:166   sid:1012 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 30720].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:30720 ; # gemm_fp8_gfx942.py:166   sid:1013 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 30720].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:1014 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:1015 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:1016 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:1017 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1018 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s23,v192  ; # gemm_fp8_gfx942.py:190   sid:1019 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v138,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:1020 accum[104:104],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1021 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v139,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:1022 accum[105:105],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1023 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v140,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:1024 accum[106:106],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1025 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v141,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:1026 accum[107:107],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1027 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v142,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:1028 accum[108:108],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1029 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v143,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:1030 accum[109:109],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1031 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v144,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:1032 accum[110:110],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1033 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v145,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:1034 accum[111:111],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1035 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v82,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:1036 accum[48:48],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1037 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v83,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:1038 accum[49:49],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1039 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v84,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:1040 accum[50:50],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1041 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v85,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:1042 accum[51:51],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1043 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v86,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:1044 accum[52:52],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1045 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v87,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:1046 accum[53:53],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1047 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v88,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:1048 accum[54:54],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1049 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v89,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:1050 accum[55:55],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1051 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s23,v193  ; # gemm_fp8_gfx942.py:190   sid:1052 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v90,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:1053 accum[56:56],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1054 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v91,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:1055 accum[57:57],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1056 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v92,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:1057 accum[58:58],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1058 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v93,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:1059 accum[59:59],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1060 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v94,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:1061 accum[60:60],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1062 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v95,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:1063 accum[61:61],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1064 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v96,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:1065 accum[62:62],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1066 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v97,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:1067 accum[63:63],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1068 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v146,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:1069 accum[112:112],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1070 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v147,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:1071 accum[113:113],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1072 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v148,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:1073 accum[114:114],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1074 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v149,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:1075 accum[115:115],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1076 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v150,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:1077 accum[116:116],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1078 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v151,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:1079 accum[117:117],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1080 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v152,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:1081 accum[118:118],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:1082 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1083 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v153,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:1084 accum[119:119],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:1085 0,
	s_add_u32 s12,0x80,s12  ; # gemm_fp8_gfx942.py:205   sid:1086 k_offset,128,k_offset,;	s12.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s5,0x2  ; # gemm_fp8_gfx942.py:206 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1087 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s13,s13,s17  ; # gemm_fp8_gfx942.py:206 free 'src1_gprs's17   sid:1088 scale_offset,scale_offset,src1_gprs,;	s13.u32 = s13 + s17; scc=overflow_or_carry
	s_waitcnt  vmcnt(1) ; # gemm_fp8_gfx942.py:154   sid:1089 
	ds_write_b128 v2,v[164:167] offset:8192 ; # gemm_fp8_gfx942.py:155   sid:1090 write_b,staging_b[0:3],;	LDS_MEM[v2 + 8192].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1091 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[188:191],v15,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17   sid:1092 operands_a[16:19],load_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1093 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1094 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v192,v11,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'idst's17   sid:1095 scale_a[2:2],load_scale_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1096 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v3,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:1097 staging_b[0:3],load_b[3:3],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:0 ; # gemm_fp8_gfx942.py:166   sid:1098 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:0 ; # gemm_fp8_gfx942.py:166   sid:1099 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:2048 ; # gemm_fp8_gfx942.py:166   sid:1100 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:2048 ; # gemm_fp8_gfx942.py:166   sid:1101 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:4096 ; # gemm_fp8_gfx942.py:166   sid:1102 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:4096 ; # gemm_fp8_gfx942.py:166   sid:1103 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:6144 ; # gemm_fp8_gfx942.py:166   sid:1104 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 6144].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:6144 ; # gemm_fp8_gfx942.py:166   sid:1105 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 6144].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:1106 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:1107 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:1108 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:1109 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1110 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s20,v162  ; # gemm_fp8_gfx942.py:190   sid:1111 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v154,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:1112 accum[120:120],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1113 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v155,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:1114 accum[121:121],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1115 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v156,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:1116 accum[122:122],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1117 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v157,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:1118 accum[123:123],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1119 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v158,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:1120 accum[124:124],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1121 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v159,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:1122 accum[125:125],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1123 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v160,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:1124 accum[126:126],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1125 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v161,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:1126 accum[127:127],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1127 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v18,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:1128 accum[0:0],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1129 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v19,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:1130 accum[1:1],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1131 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v36,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:1132 accum[2:2],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1133 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v37,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:1134 accum[3:3],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1135 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v38,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:1136 accum[4:4],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1137 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v39,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:1138 accum[5:5],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1139 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v40,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:1140 accum[6:6],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1141 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v41,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:1142 accum[7:7],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1143 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s20,v163  ; # gemm_fp8_gfx942.py:190   sid:1144 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v42,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:1145 accum[8:8],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1146 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v43,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:1147 accum[9:9],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1148 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v44,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:1149 accum[10:10],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1150 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v45,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:1151 accum[11:11],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1152 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v46,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:1153 accum[12:12],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1154 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v47,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:1155 accum[13:13],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1156 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v48,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:1157 accum[14:14],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1158 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v49,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:1159 accum[15:15],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1160 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v98,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:1161 accum[64:64],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1162 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v99,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:1163 accum[65:65],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1164 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v100,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:1165 accum[66:66],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1166 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v101,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:1167 accum[67:67],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1168 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v102,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:1169 accum[68:68],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1170 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v103,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:1171 accum[69:69],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1172 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v104,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:1173 accum[70:70],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:1174 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1175 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v105,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:1176 accum[71:71],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:1177 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:154   sid:1178 
	ds_write_b128 v2,v[184:187] offset:16384 ; # gemm_fp8_gfx942.py:155   sid:1179 write_b,staging_b[4:7],;	LDS_MEM[v2 + 16384].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1180 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[228:231],v14,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17   sid:1181 operands_a[24:27],load_a[2:2],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1182 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1183 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v193,v10,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:104 free 'idst's17   sid:1184 scale_a[3:3],load_scale_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'src0_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1185 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'src0_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1186 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v4,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:1187 staging_b[4:7],load_b[0:0],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:8192 ; # gemm_fp8_gfx942.py:166   sid:1188 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:8192 ; # gemm_fp8_gfx942.py:166   sid:1189 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:10240 ; # gemm_fp8_gfx942.py:166   sid:1190 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:10240 ; # gemm_fp8_gfx942.py:166   sid:1191 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:12288 ; # gemm_fp8_gfx942.py:166   sid:1192 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:12288 ; # gemm_fp8_gfx942.py:166   sid:1193 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:14336 ; # gemm_fp8_gfx942.py:166   sid:1194 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 14336].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:14336 ; # gemm_fp8_gfx942.py:166   sid:1195 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 14336].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:1196 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:1197 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:1198 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:1199 
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:115 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1200 src1_gprs,k_offset,5,
	s_add_u32 s17,s6,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1201 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s6 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1202 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s22,s[14:15],s17  ; # gemm_fp8_gfx942.py:115 free 'idst's17   sid:1203 scale_b,pScaleB,idst,;	s22 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:115 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1204 src1_gprs,k_offset,5,
	s_add_u32 s17,s7,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1205 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s7 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:115 free 'src1_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1206 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s23,s[14:15],s17  ; # gemm_fp8_gfx942.py:115 free 'idst's17   sid:1207 scale_b,pScaleB,idst,;	s23 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1208 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s20,v162  ; # gemm_fp8_gfx942.py:190   sid:1209 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v106,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:1210 accum[72:72],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1211 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v107,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:1212 accum[73:73],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1213 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v108,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:1214 accum[74:74],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1215 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v109,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:1216 accum[75:75],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1217 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v110,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:1218 accum[76:76],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1219 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v111,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:1220 accum[77:77],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1221 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v112,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:1222 accum[78:78],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1223 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v113,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:1224 accum[79:79],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1225 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v50,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:1226 accum[16:16],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1227 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v51,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:1228 accum[17:17],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1229 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v52,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:1230 accum[18:18],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1231 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v53,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:1232 accum[19:19],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1233 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v54,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:1234 accum[20:20],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1235 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v55,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:1236 accum[21:21],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1237 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v56,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:1238 accum[22:22],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1239 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v57,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:1240 accum[23:23],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1241 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s20,v163  ; # gemm_fp8_gfx942.py:190   sid:1242 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v58,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:1243 accum[24:24],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1244 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v59,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:1245 accum[25:25],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1246 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v60,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:1247 accum[26:26],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1248 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v61,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:1249 accum[27:27],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1250 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v62,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:1251 accum[28:28],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1252 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v63,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:1253 accum[29:29],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1254 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v64,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:1255 accum[30:30],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1256 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v65,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:1257 accum[31:31],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1258 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v114,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:1259 accum[80:80],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1260 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v115,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:1261 accum[81:81],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1262 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v116,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:1263 accum[82:82],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1264 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v117,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:1265 accum[83:83],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1266 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v118,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:1267 accum[84:84],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1268 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v119,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:1269 accum[85:85],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1270 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v120,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:1271 accum[86:86],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:1272 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1273 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v121,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:1274 accum[87:87],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:1275 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:154   sid:1276 
	ds_write_b128 v2,v[164:167] offset:24576 ; # gemm_fp8_gfx942.py:155   sid:1277 write_b,staging_b[0:3],;	LDS_MEM[v2 + 24576].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1278 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[232:235],v12,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17   sid:1279 operands_a[20:23],load_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'src0_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1280 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'src0_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1281 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v7,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:1282 staging_b[0:3],load_b[1:1],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:16384 ; # gemm_fp8_gfx942.py:166   sid:1283 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:16384 ; # gemm_fp8_gfx942.py:166   sid:1284 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:18432 ; # gemm_fp8_gfx942.py:166   sid:1285 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:18432 ; # gemm_fp8_gfx942.py:166   sid:1286 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:20480 ; # gemm_fp8_gfx942.py:166   sid:1287 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:20480 ; # gemm_fp8_gfx942.py:166   sid:1288 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:22528 ; # gemm_fp8_gfx942.py:166   sid:1289 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 22528].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:22528 ; # gemm_fp8_gfx942.py:166   sid:1290 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 22528].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:1291 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:1292 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:1293 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:1294 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1295 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s21,v162  ; # gemm_fp8_gfx942.py:190   sid:1296 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v122,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:1297 accum[88:88],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1298 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v123,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:1299 accum[89:89],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1300 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v124,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:1301 accum[90:90],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1302 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v125,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:1303 accum[91:91],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1304 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v126,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:1305 accum[92:92],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1306 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v127,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:1307 accum[93:93],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1308 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v128,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:1309 accum[94:94],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1310 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v129,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:1311 accum[95:95],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1312 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v66,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:1313 accum[32:32],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1314 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v67,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:1315 accum[33:33],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1316 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v68,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:1317 accum[34:34],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1318 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v69,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:1319 accum[35:35],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1320 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v70,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:1321 accum[36:36],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1322 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v71,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:1323 accum[37:37],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1324 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v72,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:1325 accum[38:38],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1326 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v73,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:1327 accum[39:39],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1328 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s21,v163  ; # gemm_fp8_gfx942.py:190   sid:1329 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v74,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:1330 accum[40:40],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1331 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v75,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:1332 accum[41:41],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1333 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v76,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:1334 accum[42:42],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1335 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v77,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:1336 accum[43:43],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1337 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v78,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:1338 accum[44:44],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1339 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v79,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:1340 accum[45:45],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1341 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v80,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:1342 accum[46:46],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1343 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v81,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:1344 accum[47:47],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1345 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v130,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:1346 accum[96:96],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1347 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v131,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:1348 accum[97:97],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1349 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v132,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:1350 accum[98:98],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1351 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v133,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:1352 accum[99:99],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1353 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v134,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:1354 accum[100:100],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1355 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v135,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:1356 accum[101:101],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1357 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v136,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:1358 accum[102:102],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:1359 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1360 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v137,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:1361 accum[103:103],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:1362 0,
	s_waitcnt  vmcnt(2) ; # gemm_fp8_gfx942.py:154   sid:1363 
	ds_write_b128 v2,v[184:187] offset:0 ; # gemm_fp8_gfx942.py:155   sid:1364 write_b,staging_b[4:7],;	LDS_MEM[v2 + 0].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:108 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1365 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[236:239],v16,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:108 free 'idst's17   sid:1366 operands_a[28:31],load_a[3:3],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'src0_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1367 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'src0_gprs's17 alloc 'idst's17    s:36(35) v:238(239) a:0(0)    sid:1368 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v8,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's17   sid:1369 staging_b[4:7],load_b[2:2],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:24576 ; # gemm_fp8_gfx942.py:166   sid:1370 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:24576 ; # gemm_fp8_gfx942.py:166   sid:1371 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:26624 ; # gemm_fp8_gfx942.py:166   sid:1372 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:26624 ; # gemm_fp8_gfx942.py:166   sid:1373 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:28672 ; # gemm_fp8_gfx942.py:166   sid:1374 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:28672 ; # gemm_fp8_gfx942.py:166   sid:1375 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:30720 ; # gemm_fp8_gfx942.py:166   sid:1376 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 30720].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:30720 ; # gemm_fp8_gfx942.py:166   sid:1377 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 30720].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:1378 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:1379 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:1380 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:1381 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1382 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s21,v162  ; # gemm_fp8_gfx942.py:190   sid:1383 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v138,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:1384 accum[104:104],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1385 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v139,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:1386 accum[105:105],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1387 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v140,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:1388 accum[106:106],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1389 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v141,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:1390 accum[107:107],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1391 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v142,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:1392 accum[108:108],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1393 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v143,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:1394 accum[109:109],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1395 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v144,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:1396 accum[110:110],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1397 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v145,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:1398 accum[111:111],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1399 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v82,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:1400 accum[48:48],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:183   sid:1401 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v83,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:1402 accum[49:49],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1403 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v84,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:1404 accum[50:50],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1405 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v85,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:1406 accum[51:51],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1407 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v86,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:1408 accum[52:52],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1409 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v87,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:1410 accum[53:53],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1411 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v88,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:1412 accum[54:54],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1413 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v89,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:1414 accum[55:55],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1415 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s21,v163  ; # gemm_fp8_gfx942.py:190   sid:1416 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v90,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:1417 accum[56:56],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1418 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v91,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:1419 accum[57:57],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1420 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v92,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:1421 accum[58:58],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1422 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v93,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:1423 accum[59:59],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1424 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v94,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:1425 accum[60:60],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1426 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v95,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:1427 accum[61:61],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1428 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v96,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:1429 accum[62:62],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1430 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v97,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:1431 accum[63:63],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1432 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v146,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:1433 accum[112:112],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:183   sid:1434 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v147,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:1435 accum[113:113],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1436 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v148,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:1437 accum[114:114],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1438 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v149,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:1439 accum[115:115],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1440 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v150,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:1441 accum[116:116],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1442 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v151,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:1443 accum[117:117],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1444 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v152,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:1445 accum[118:118],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:1446 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1447 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v153,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:1448 accum[119:119],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:1449 0,
	s_add_u32 s12,0x80,s12  ; # gemm_fp8_gfx942.py:205   sid:1450 k_offset,128,k_offset,;	s12.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s5,0x2  ; # gemm_fp8_gfx942.py:206 alloc 'src1_gprs's17    s:36(35) v:238(239) a:0(0)    sid:1451 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s13,s13,s17  ; # gemm_fp8_gfx942.py:206 free 'src1_gprs's17   sid:1452 scale_offset,scale_offset,src1_gprs,;	s13.u32 = s13 + s17; scc=overflow_or_carry
	s_branch  _while_begin_225_2 ; # asmjit.py:1341 asmjit.py:1386 contextlib.py:144 free 'scale_offset_b's[6:7] free 'pScaleB's[14:15] free 'self.desc's[24:27] free 'self.desc's[8:11] free 'load_b[0:0]'v4 free 'load_b[1:1]'v7 free 'load_b[2:2]'v8 free 'load_scale_a[0:0]'v11 free 'load_scale_a[1:1]'v10 free 'load_a[0:0]'v15 free 'load_a[2:2]'v14 free 'load_a[1:1]'v12 free 'load_a[3:3]'v16 free 'scale_a[0:0]'v162 free 'scale_a[1:1]'v163 free 'operands_a[0:3]'v[168:171] free 'operands_a[4:7]'v[172:175] free 'operands_a[8:11]'v[176:179] free 'operands_a[12:15]'v[180:183]   sid:1453 
_while_end_225_2:	 ;BB#8 predecessors:[_while_begin_225_2] successors:[_bb_no_name_9,_if_else_239_3]
	s_waitcnt  vmcnt(1) ; # gemm_fp8_gfx942.py:154   sid:1454 
	ds_write_b128 v2,v[164:167] offset:8192 ; # gemm_fp8_gfx942.py:155   sid:1455 write_b,staging_b[0:3],;	LDS_MEM[v2 + 8192].b128 = v[164:167].b128
	s_lshl_b32 s6,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:121 alloc 'idst's6    s:24(35) v:211(239) a:0(0)    sid:1456 idst,k_offset,4,;	s6 = s12 << 0x4[4:0]; scc=(s6!=0);
	buffer_load_dwordx4 v[164:167],v3,s[28:31],s6 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:121 free 'idst's6 free 'self.desc's[28:31] free 'load_b[3:3]'v3   sid:1457 staging_b[0:3],load_b[3:3],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:0 ; # gemm_fp8_gfx942.py:166   sid:1458 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:0 ; # gemm_fp8_gfx942.py:166   sid:1459 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:2048 ; # gemm_fp8_gfx942.py:166   sid:1460 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:2048 ; # gemm_fp8_gfx942.py:166   sid:1461 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:4096 ; # gemm_fp8_gfx942.py:166   sid:1462 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:4096 ; # gemm_fp8_gfx942.py:166   sid:1463 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:6144 ; # gemm_fp8_gfx942.py:166   sid:1464 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 6144].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:6144 ; # gemm_fp8_gfx942.py:166   sid:1465 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 6144].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:1466 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:1467 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:1468 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:1469 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1470 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s22,v192  ; # gemm_fp8_gfx942.py:190   sid:1471 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v154,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:1472 accum[120:120],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1473 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v155,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:1474 accum[121:121],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1475 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v156,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:1476 accum[122:122],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1477 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v157,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:1478 accum[123:123],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1479 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v158,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:1480 accum[124:124],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1481 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v159,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:1482 accum[125:125],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1483 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v160,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:1484 accum[126:126],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1485 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v161,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:1486 accum[127:127],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1487 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v18,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:1488 accum[0:0],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1489 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v19,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:1490 accum[1:1],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1491 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v36,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:1492 accum[2:2],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1493 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v37,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:1494 accum[3:3],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1495 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v38,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:1496 accum[4:4],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1497 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v39,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:1498 accum[5:5],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1499 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v40,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:1500 accum[6:6],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1501 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v41,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:1502 accum[7:7],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1503 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s22,v193  ; # gemm_fp8_gfx942.py:190   sid:1504 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v42,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:1505 accum[8:8],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1506 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v43,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:1507 accum[9:9],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1508 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v44,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:1509 accum[10:10],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1510 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v45,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:1511 accum[11:11],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1512 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v46,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:1513 accum[12:12],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1514 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v47,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:1515 accum[13:13],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1516 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v48,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:1517 accum[14:14],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1518 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v49,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:1519 accum[15:15],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1520 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v98,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:1521 accum[64:64],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1522 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v99,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:1523 accum[65:65],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1524 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v100,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:1525 accum[66:66],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1526 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v101,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:1527 accum[67:67],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1528 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v102,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:1529 accum[68:68],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1530 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v103,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:1531 accum[69:69],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1532 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v104,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:1533 accum[70:70],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:1534 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1535 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v105,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:1536 accum[71:71],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:1537 0,
	s_waitcnt  vmcnt(1) ; # gemm_fp8_gfx942.py:154   sid:1538 
	ds_write_b128 v2,v[184:187] offset:16384 ; # gemm_fp8_gfx942.py:155 free 'staging_b[4:7]'v[184:187]   sid:1539 write_b,staging_b[4:7],;	LDS_MEM[v2 + 16384].b128 = v[184:187].b128
	ds_read_b128 v[196:199],v13 offset:8192 ; # gemm_fp8_gfx942.py:166   sid:1540 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:8192 ; # gemm_fp8_gfx942.py:166   sid:1541 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:10240 ; # gemm_fp8_gfx942.py:166   sid:1542 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:10240 ; # gemm_fp8_gfx942.py:166   sid:1543 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:12288 ; # gemm_fp8_gfx942.py:166   sid:1544 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:12288 ; # gemm_fp8_gfx942.py:166   sid:1545 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:14336 ; # gemm_fp8_gfx942.py:166   sid:1546 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 14336].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:14336 ; # gemm_fp8_gfx942.py:166   sid:1547 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 14336].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:1548 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:1549 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:1550 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:1551 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1552 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s22,v192  ; # gemm_fp8_gfx942.py:190   sid:1553 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v106,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:1554 accum[72:72],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1555 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v107,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:1556 accum[73:73],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1557 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v108,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:1558 accum[74:74],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1559 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v109,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:1560 accum[75:75],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1561 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v110,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:1562 accum[76:76],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1563 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v111,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:1564 accum[77:77],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1565 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v112,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:1566 accum[78:78],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1567 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v113,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:1568 accum[79:79],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1569 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v50,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:1570 accum[16:16],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1571 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v51,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:1572 accum[17:17],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1573 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v52,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:1574 accum[18:18],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1575 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v53,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:1576 accum[19:19],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1577 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v54,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:1578 accum[20:20],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1579 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v55,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:1580 accum[21:21],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1581 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v56,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:1582 accum[22:22],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1583 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v57,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:1584 accum[23:23],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1585 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s22,v193  ; # gemm_fp8_gfx942.py:190   sid:1586 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v58,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:1587 accum[24:24],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1588 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v59,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:1589 accum[25:25],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1590 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v60,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:1591 accum[26:26],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1592 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v61,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:1593 accum[27:27],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1594 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v62,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:1595 accum[28:28],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1596 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v63,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:1597 accum[29:29],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1598 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v64,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:1599 accum[30:30],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1600 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v65,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:1601 accum[31:31],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1602 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v114,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:1603 accum[80:80],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1604 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v115,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:1605 accum[81:81],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1606 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v116,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:1607 accum[82:82],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1608 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v117,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:1609 accum[83:83],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1610 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v118,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:1611 accum[84:84],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1612 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v119,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:1613 accum[85:85],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1614 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v120,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:1615 accum[86:86],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:1616 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1617 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v121,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:1618 accum[87:87],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:1619 0,
	s_waitcnt  vmcnt(0) ; # gemm_fp8_gfx942.py:154   sid:1620 
	ds_write_b128 v2,v[164:167] offset:24576 ; # gemm_fp8_gfx942.py:155 free 'write_b'v2 free 'staging_b[0:3]'v[164:167]   sid:1621 write_b,staging_b[0:3],;	LDS_MEM[v2 + 24576].b128 = v[164:167].b128
	ds_read_b128 v[196:199],v13 offset:16384 ; # gemm_fp8_gfx942.py:166   sid:1622 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:16384 ; # gemm_fp8_gfx942.py:166   sid:1623 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:18432 ; # gemm_fp8_gfx942.py:166   sid:1624 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:18432 ; # gemm_fp8_gfx942.py:166   sid:1625 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:20480 ; # gemm_fp8_gfx942.py:166   sid:1626 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:20480 ; # gemm_fp8_gfx942.py:166   sid:1627 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:22528 ; # gemm_fp8_gfx942.py:166   sid:1628 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 22528].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:22528 ; # gemm_fp8_gfx942.py:166   sid:1629 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 22528].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:1630 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:1631 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:1632 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:1633 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1634 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s23,v192  ; # gemm_fp8_gfx942.py:190   sid:1635 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v122,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:1636 accum[88:88],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1637 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v123,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:1638 accum[89:89],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1639 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v124,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:1640 accum[90:90],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1641 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v125,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:1642 accum[91:91],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1643 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v126,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:1644 accum[92:92],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1645 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v127,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:1646 accum[93:93],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1647 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v128,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:1648 accum[94:94],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1649 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v129,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:1650 accum[95:95],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1651 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v66,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:1652 accum[32:32],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1653 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v67,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:1654 accum[33:33],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1655 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v68,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:1656 accum[34:34],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1657 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v69,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:1658 accum[35:35],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1659 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v70,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:1660 accum[36:36],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1661 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v71,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:1662 accum[37:37],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1663 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v72,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:1664 accum[38:38],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1665 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v73,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:1666 accum[39:39],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1667 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s23,v193  ; # gemm_fp8_gfx942.py:190   sid:1668 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v74,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:1669 accum[40:40],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1670 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v75,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:1671 accum[41:41],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1672 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v76,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:1673 accum[42:42],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1674 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v77,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:1675 accum[43:43],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1676 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v78,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:1677 accum[44:44],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1678 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v79,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:1679 accum[45:45],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1680 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v80,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:1681 accum[46:46],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1682 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v81,v35,v6  ; # gemm_fp8_gfx942.py:198   sid:1683 accum[47:47],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1684 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v130,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:1685 accum[96:96],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1686 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v131,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:1687 accum[97:97],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1688 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v132,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:1689 accum[98:98],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1690 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v133,v23,v17  ; # gemm_fp8_gfx942.py:198   sid:1691 accum[99:99],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1692 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v134,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:1693 accum[100:100],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1694 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v135,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:1695 accum[101:101],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1696 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v136,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:1697 accum[102:102],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:1698 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1699 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v137,v27,v17  ; # gemm_fp8_gfx942.py:198   sid:1700 accum[103:103],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:1701 0,
	ds_read_b128 v[196:199],v13 offset:24576 ; # gemm_fp8_gfx942.py:166   sid:1702 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:24576 ; # gemm_fp8_gfx942.py:166   sid:1703 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:26624 ; # gemm_fp8_gfx942.py:166   sid:1704 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:26624 ; # gemm_fp8_gfx942.py:166   sid:1705 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:28672 ; # gemm_fp8_gfx942.py:166   sid:1706 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:28672 ; # gemm_fp8_gfx942.py:166   sid:1707 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:30720 ; # gemm_fp8_gfx942.py:166 free 'read_b[0:0]'v13   sid:1708 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 30720].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:30720 ; # gemm_fp8_gfx942.py:166 free 'read_b[1:1]'v5   sid:1709 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 30720].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:170   sid:1710 
	s_barrier   ; # gemm_fp8_gfx942.py:171   sid:1711 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:172   sid:1712 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:173   sid:1713 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1714 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s23,v192  ; # gemm_fp8_gfx942.py:190 free 'scale_a[2:2]'v192   sid:1715 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v138,v28,v17  ; # gemm_fp8_gfx942.py:198   sid:1716 accum[104:104],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1717 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v139,v29,v17  ; # gemm_fp8_gfx942.py:198   sid:1718 accum[105:105],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1719 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v140,v30,v17  ; # gemm_fp8_gfx942.py:198   sid:1720 accum[106:106],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1721 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v141,v31,v17  ; # gemm_fp8_gfx942.py:198   sid:1722 accum[107:107],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1723 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v142,v32,v17  ; # gemm_fp8_gfx942.py:198   sid:1724 accum[108:108],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1725 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v143,v33,v17  ; # gemm_fp8_gfx942.py:198   sid:1726 accum[109:109],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1727 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v144,v34,v17  ; # gemm_fp8_gfx942.py:198   sid:1728 accum[110:110],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1729 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v145,v35,v17  ; # gemm_fp8_gfx942.py:198   sid:1730 accum[111:111],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1731 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v82,v20,v6  ; # gemm_fp8_gfx942.py:198   sid:1732 accum[48:48],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:183   sid:1733 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v83,v21,v6  ; # gemm_fp8_gfx942.py:198   sid:1734 accum[49:49],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1735 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v84,v22,v6  ; # gemm_fp8_gfx942.py:198   sid:1736 accum[50:50],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:183 free 'operands_a[16:19]'v[188:191]   sid:1737 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v85,v23,v6  ; # gemm_fp8_gfx942.py:198   sid:1738 accum[51:51],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1739 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v86,v24,v6  ; # gemm_fp8_gfx942.py:198   sid:1740 accum[52:52],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1741 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v87,v25,v6  ; # gemm_fp8_gfx942.py:198   sid:1742 accum[53:53],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1743 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v88,v26,v6  ; # gemm_fp8_gfx942.py:198   sid:1744 accum[54:54],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:183 free 'operands_a[20:23]'v[232:235]   sid:1745 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v89,v27,v6  ; # gemm_fp8_gfx942.py:198   sid:1746 accum[55:55],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1747 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s23,v193  ; # gemm_fp8_gfx942.py:190 free 'scale_b's[20:23] free 'scale_a[3:3]'v193   sid:1748 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v90,v28,v6  ; # gemm_fp8_gfx942.py:198   sid:1749 accum[56:56],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1750 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v91,v29,v6  ; # gemm_fp8_gfx942.py:198   sid:1751 accum[57:57],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:183 free 'operands_b[0:3]'v[196:199]   sid:1752 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v92,v30,v6  ; # gemm_fp8_gfx942.py:198   sid:1753 accum[58:58],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:183 free 'operands_b[8:11]'v[204:207]   sid:1754 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v93,v31,v6  ; # gemm_fp8_gfx942.py:198   sid:1755 accum[59:59],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:183   sid:1756 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v94,v32,v6  ; # gemm_fp8_gfx942.py:198   sid:1757 accum[60:60],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:183   sid:1758 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v95,v33,v6  ; # gemm_fp8_gfx942.py:198   sid:1759 accum[61:61],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:183 free 'operands_b[4:7]'v[200:203]   sid:1760 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v96,v34,v6  ; # gemm_fp8_gfx942.py:198   sid:1761 accum[62:62],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:183 free 'operands_b[12:15]'v[208:211]   sid:1762 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v97,v35,v6  ; # gemm_fp8_gfx942.py:198 free 'partial_scale[0:0]'v6   sid:1763 accum[63:63],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1764 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v146,v20,v17  ; # gemm_fp8_gfx942.py:198   sid:1765 accum[112:112],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:183   sid:1766 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v147,v21,v17  ; # gemm_fp8_gfx942.py:198   sid:1767 accum[113:113],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:183 free 'operands_b[16:19]'v[212:215]   sid:1768 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v148,v22,v17  ; # gemm_fp8_gfx942.py:198   sid:1769 accum[114:114],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:183 free 'operands_a[24:27]'v[228:231] free 'operands_b[24:27]'v[220:223]   sid:1770 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v149,v23,v17  ; # gemm_fp8_gfx942.py:198 free 'partial[0:3]'v[20:23]   sid:1771 accum[115:115],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:183   sid:1772 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v150,v24,v17  ; # gemm_fp8_gfx942.py:198   sid:1773 accum[116:116],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:183   sid:1774 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v151,v25,v17  ; # gemm_fp8_gfx942.py:198   sid:1775 accum[117:117],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:183 free 'operands_b[20:23]'v[216:219]   sid:1776 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v152,v26,v17  ; # gemm_fp8_gfx942.py:198   sid:1777 accum[118:118],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:181   sid:1778 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:183 free 'operands_a[28:31]'v[236:239] free 'operands_b[28:31]'v[224:227]   sid:1779 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v153,v27,v17  ; # gemm_fp8_gfx942.py:198 free 'partial[4:7]'v[24:27]   sid:1780 accum[119:119],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:202   sid:1781 0,
	s_add_u32 s12,0x80,s12  ; # gemm_fp8_gfx942.py:205 free 'k_offset's12   sid:1782 k_offset,128,k_offset,;	s12.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s5,s5,0x2  ; # gemm_fp8_gfx942.py:206 free 'M's5 alloc 'src1_gprs's5    s:14(35) v:140(161) a:0(0)    sid:1783 src1_gprs,M,2,;	s5 = s5 << 0x2[4:0]; scc=(s5!=0);
	s_add_u32 s13,s13,s5  ; # gemm_fp8_gfx942.py:206 free 'scale_offset's13 free 'src1_gprs's5   sid:1784 scale_offset,scale_offset,src1_gprs,;	s13.u32 = s13 + s5; scc=overflow_or_carry
	s_nop 0xf  ; # gemm_fp8_gfx942.py:233   sid:1785 15,;	s_nop  wait 16 cycles
	v_fmac_f32 v154,v28,v17  ; # gemm_fp8_gfx942.py:236   sid:1786 accum[120:120],partial[8:11],partial_scale[1:1],
	v_fmac_f32 v155,v29,v17  ; # gemm_fp8_gfx942.py:236   sid:1787 accum[121:121],partial[8:11],partial_scale[1:1],
	v_fmac_f32 v156,v30,v17  ; # gemm_fp8_gfx942.py:236   sid:1788 accum[122:122],partial[8:11],partial_scale[1:1],
	v_fmac_f32 v157,v31,v17  ; # gemm_fp8_gfx942.py:236 free 'partial[8:11]'v[28:31]   sid:1789 accum[123:123],partial[8:11],partial_scale[1:1],
	v_fmac_f32 v158,v32,v17  ; # gemm_fp8_gfx942.py:236   sid:1790 accum[124:124],partial[12:15],partial_scale[1:1],
	v_fmac_f32 v159,v33,v17  ; # gemm_fp8_gfx942.py:236   sid:1791 accum[125:125],partial[12:15],partial_scale[1:1],
	v_fmac_f32 v160,v34,v17  ; # gemm_fp8_gfx942.py:236   sid:1792 accum[126:126],partial[12:15],partial_scale[1:1],
	v_fmac_f32 v161,v35,v17  ; # gemm_fp8_gfx942.py:236 free 'partial_scale[1:1]'v17 free 'partial[12:15]'v[32:35]   sid:1793 accum[127:127],partial[12:15],partial_scale[1:1],
	s_cmp_eq_u32 s16,0x0  ; # asmjit.py:1421 contextlib.py:137 free 'group's16   sid:1794 group,0,;	scc = (s16.u32 == 0x0.u32)
	s_cbranch_scc0  _if_else_239_3 ; # asmjit.py:1367 asmjit.py:1421 contextlib.py:137   sid:1795;	jump if scc is 0 (scc == 0)
_bb_no_name_9:	 ;BB#9 predecessors:[_while_end_225_2] successors:[_if_else_239_3]
	s_barrier   ; # gemm_fp8_gfx942.py:240   sid:1796 
_if_else_239_3:	 ;BB#10 predecessors:[_bb_no_name_9,_while_end_225_2] successors:[_bb_no_name_11,_execmask_end_263_4]
	v_lshrrev_b32 v2,0x4,v1  ; # gemm_fp8_gfx942.py:244 alloc 'lane_group'v2    s:11(35) v:132(161) a:0(0)    sid:1797 lane_group,4,_lane_id,;	v2.b32 = v1 >> 0x4[4:0];
	v_and_b32 v3,0x1,v2  ; # gemm_fp8_gfx942.py:245 alloc 'odd_group'v3    s:11(35) v:133(161) a:0(0)    sid:1798 odd_group,1,lane_group,;	v3.u32 = (0x1 & v2.u32)
	v_xor_b32 v1,0x10,v1  ; # gemm_fp8_gfx942.py:246 free '_lane_id'v1 alloc 'src0_gprs'v1    s:11(35) v:133(161) a:0(0)    sid:1799 src0_gprs,16,_lane_id,;	v1.u32 = (0x10 ^ v1.u32)
	v_lshlrev_b32 v1,0x2,v1  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v1 alloc 'exchange_lane'v1    s:11(35) v:133(161) a:0(0)    sid:1800 exchange_lane,2,src0_gprs,;	v1.b32 = v1 << 0x2[4:0];
	v_lshlrev_b32 v4,0x1,v3  ; # gemm_fp8_gfx942.py:247 alloc 'src0_gprs'v4    s:11(35) v:134(161) a:0(0)    sid:1801 src0_gprs,1,odd_group,;	v4.b32 = v3 << 0x1[4:0];
	v_lshrrev_b32 v2,0x1,v2  ; # gemm_fp8_gfx942.py:247 free 'lane_group'v2 alloc 'src1_gprs'v2    s:11(35) v:134(161) a:0(0)    sid:1802 src1_gprs,1,lane_group,;	v2.b32 = v2 >> 0x1[4:0];
	v_add_u32_e32 v2,v4,v2  ; # gemm_fp8_gfx942.py:247 free 'src0_gprs'v4 free 'src1_gprs'v2 alloc 'src0_gprs'v2    s:11(35) v:133(161) a:0(0)    sid:1803 src0_gprs,src0_gprs,src1_gprs,;	v2 = v4 + v2
	v_lshlrev_b32 v2,0x3,v2  ; # gemm_fp8_gfx942.py:247 free 'src0_gprs'v2 alloc 'src1_gprs'v2    s:11(35) v:133(161) a:0(0)    sid:1804 src1_gprs,3,src0_gprs,;	v2.b32 = v2 << 0x3[4:0];
	v_add_u32_e32 v2,s19,v2  ; # gemm_fp8_gfx942.py:247 free 'col_base's19 free 'src1_gprs'v2 alloc 'output_col'v2    s:10(35) v:133(161) a:0(0)    sid:1805 output_col,col_base,src1_gprs,;	v2 = s19 + v2
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:10(35) v:134(161) a:0(0)    sid:1806 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0x0,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:10(35) v:134(161) a:0(0)    sid:1807 src0_gprs,0,src1_gprs,;	v4.u32 = (0x0 ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:10(35) v:134(161) a:0(0)    sid:1808 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:10(35) v:134(161) a:0(0)    sid:1809 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:10(35) v:135(161) a:0(0)    sid:1810 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:10(35) v:135(161) a:0(0)    sid:1811 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v6,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v6    s:10(35) v:136(161) a:0(0)    sid:1812 src1_gprs,1,column,;	v6.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v6  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v6 alloc 'offset'v5    s:10(35) v:135(161) a:0(0)    sid:1813 offset,src0_gprs,src1_gprs,;	v5 = v5 + v6
	s_mov_b32 s5,0x8000  ; # asmjit.py:3745 asmjit.py:3957 gemm_fp8_gfx942.py:252 alloc 'sgpr_const_32768's5    s:11(35) v:135(161) a:0(0)    sid:1814 sgpr_const_32768,32768,;	s5 = 0x8000
	s_mov_b32 s6,0x3020706  ; # asmjit.py:3745 asmjit.py:3962 gemm_fp8_gfx942.py:252 alloc 'sgpr_const_50464518's6    s:12(35) v:135(161) a:0(0)    sid:1815 sgpr_const_50464518,50464518,;	s6 = 0x3020706
	v_add_f32 v6,s5,v18  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[0:0]'v18 alloc 'idst'v6    s:12(35) v:135(161) a:0(0)    sid:1816 idst,sgpr_const_32768,accum[0:0],;	v6 = s5 + v18
	v_add_f32 v7,s5,v19  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[1:1]'v19 alloc 'idst'v7    s:12(35) v:135(161) a:0(0)    sid:1817 idst,sgpr_const_32768,accum[1:1],;	v7 = s5 + v19
	v_perm_b32 v12,v6,v7,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v6 free 'idst'v7 alloc 'packed'v[12:15]    s:12(35) v:137(161) a:0(0)    sid:1818 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v6,s5,v36  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[2:2]'v36 alloc 'idst'v6    s:12(35) v:137(161) a:0(0)    sid:1819 idst,sgpr_const_32768,accum[2:2],;	v6 = s5 + v36
	v_add_f32 v7,s5,v37  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[3:3]'v37 alloc 'idst'v7    s:12(35) v:137(161) a:0(0)    sid:1820 idst,sgpr_const_32768,accum[3:3],;	v7 = s5 + v37
	v_perm_b32 v13,v6,v7,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v6 free 'idst'v7   sid:1821 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v6,s5,v38  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[4:4]'v38 alloc 'idst'v6    s:12(35) v:135(161) a:0(0)    sid:1822 idst,sgpr_const_32768,accum[4:4],;	v6 = s5 + v38
	v_add_f32 v7,s5,v39  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[5:5]'v39 alloc 'idst'v7    s:12(35) v:135(161) a:0(0)    sid:1823 idst,sgpr_const_32768,accum[5:5],;	v7 = s5 + v39
	v_perm_b32 v14,v6,v7,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v6 free 'idst'v7   sid:1824 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v6,s5,v40  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[6:6]'v40 alloc 'idst'v6    s:12(35) v:133(161) a:0(0)    sid:1825 idst,sgpr_const_32768,accum[6:6],;	v6 = s5 + v40
	v_add_f32 v7,s5,v41  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[7:7]'v41 alloc 'idst'v7    s:12(35) v:133(161) a:0(0)    sid:1826 idst,sgpr_const_32768,accum[7:7],;	v7 = s5 + v41
	v_perm_b32 v15,v6,v7,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v6 free 'idst'v7   sid:1827 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257 alloc 'exchanged[0:0]'v6    s:12(35) v:132(161) a:0(0)    sid:1828 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257 alloc 'exchanged[1:1]'v7    s:12(35) v:133(161) a:0(0)    sid:1829 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257 alloc 'exchanged[2:2]'v8    s:12(35) v:134(161) a:0(0)    sid:1830 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257 alloc 'exchanged[3:3]'v10    s:12(35) v:135(161) a:0(0)    sid:1831 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:1832 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:1833 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:1834 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:1835 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:1836 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:1837 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1838 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:134(161) a:0(0)    sid:1839 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_4 ; # asmjit.py:1526 contextlib.py:137   sid:1840;	jump if execz is 1 (exec mask == 0)
_bb_no_name_11:	 ;BB#11 predecessors:[_if_else_239_3] successors:[_execmask_end_263_4]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:1841 packed,offset,self.desc,0,
_execmask_end_263_4:	 ;BB#12 predecessors:[_bb_no_name_11,_if_else_239_3] successors:[_bb_no_name_13,_execmask_end_263_5]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1842 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:134(161) a:0(0)    sid:1843 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0x2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:134(161) a:0(0)    sid:1844 src0_gprs,2,src1_gprs,;	v4.u32 = (0x2 ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:134(161) a:0(0)    sid:1845 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:134(161) a:0(0)    sid:1846 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:135(161) a:0(0)    sid:1847 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:135(161) a:0(0)    sid:1848 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:136(161) a:0(0)    sid:1849 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:135(161) a:0(0)    sid:1850 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v42  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[8:8]'v42 alloc 'idst'v11    s:12(35) v:135(161) a:0(0)    sid:1851 idst,sgpr_const_32768,accum[8:8],;	v11 = s5 + v42
	v_add_f32 v16,s5,v43  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[9:9]'v43 alloc 'idst'v16    s:12(35) v:135(161) a:0(0)    sid:1852 idst,sgpr_const_32768,accum[9:9],;	v16 = s5 + v43
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:1853 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v44  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[10:10]'v44 alloc 'idst'v11    s:12(35) v:133(161) a:0(0)    sid:1854 idst,sgpr_const_32768,accum[10:10],;	v11 = s5 + v44
	v_add_f32 v16,s5,v45  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[11:11]'v45 alloc 'idst'v16    s:12(35) v:133(161) a:0(0)    sid:1855 idst,sgpr_const_32768,accum[11:11],;	v16 = s5 + v45
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:1856 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v46  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[12:12]'v46 alloc 'idst'v11    s:12(35) v:131(161) a:0(0)    sid:1857 idst,sgpr_const_32768,accum[12:12],;	v11 = s5 + v46
	v_add_f32 v16,s5,v47  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[13:13]'v47 alloc 'idst'v16    s:12(35) v:131(161) a:0(0)    sid:1858 idst,sgpr_const_32768,accum[13:13],;	v16 = s5 + v47
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:1859 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v48  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[14:14]'v48 alloc 'idst'v11    s:12(35) v:129(161) a:0(0)    sid:1860 idst,sgpr_const_32768,accum[14:14],;	v11 = s5 + v48
	v_add_f32 v16,s5,v49  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[15:15]'v49 alloc 'idst'v16    s:12(35) v:129(161) a:0(0)    sid:1861 idst,sgpr_const_32768,accum[15:15],;	v16 = s5 + v49
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:1862 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:1863 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:1864 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:1865 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:1866 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:1867 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:1868 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:1869 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:1870 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:1871 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:1872 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1873 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:126(161) a:0(0)    sid:1874 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_5 ; # asmjit.py:1526 contextlib.py:137   sid:1875;	jump if execz is 1 (exec mask == 0)
_bb_no_name_13:	 ;BB#13 predecessors:[_execmask_end_263_4] successors:[_execmask_end_263_5]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:1876 packed,offset,self.desc,0,
_execmask_end_263_5:	 ;BB#14 predecessors:[_bb_no_name_13,_execmask_end_263_4] successors:[_bb_no_name_15,_execmask_end_263_6]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1877 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:126(161) a:0(0)    sid:1878 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:126(161) a:0(0)    sid:1879 src0_gprs,4,src1_gprs,;	v4.u32 = (0x4 ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:126(161) a:0(0)    sid:1880 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:126(161) a:0(0)    sid:1881 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:127(161) a:0(0)    sid:1882 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:127(161) a:0(0)    sid:1883 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:128(161) a:0(0)    sid:1884 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:127(161) a:0(0)    sid:1885 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v50  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[16:16]'v50 alloc 'idst'v11    s:12(35) v:127(161) a:0(0)    sid:1886 idst,sgpr_const_32768,accum[16:16],;	v11 = s5 + v50
	v_add_f32 v16,s5,v51  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[17:17]'v51 alloc 'idst'v16    s:12(35) v:127(161) a:0(0)    sid:1887 idst,sgpr_const_32768,accum[17:17],;	v16 = s5 + v51
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:1888 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v52  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[18:18]'v52 alloc 'idst'v11    s:12(35) v:125(161) a:0(0)    sid:1889 idst,sgpr_const_32768,accum[18:18],;	v11 = s5 + v52
	v_add_f32 v16,s5,v53  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[19:19]'v53 alloc 'idst'v16    s:12(35) v:125(161) a:0(0)    sid:1890 idst,sgpr_const_32768,accum[19:19],;	v16 = s5 + v53
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:1891 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v54  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[20:20]'v54 alloc 'idst'v11    s:12(35) v:123(161) a:0(0)    sid:1892 idst,sgpr_const_32768,accum[20:20],;	v11 = s5 + v54
	v_add_f32 v16,s5,v55  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[21:21]'v55 alloc 'idst'v16    s:12(35) v:123(161) a:0(0)    sid:1893 idst,sgpr_const_32768,accum[21:21],;	v16 = s5 + v55
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:1894 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v56  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[22:22]'v56 alloc 'idst'v11    s:12(35) v:121(161) a:0(0)    sid:1895 idst,sgpr_const_32768,accum[22:22],;	v11 = s5 + v56
	v_add_f32 v16,s5,v57  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[23:23]'v57 alloc 'idst'v16    s:12(35) v:121(161) a:0(0)    sid:1896 idst,sgpr_const_32768,accum[23:23],;	v16 = s5 + v57
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:1897 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:1898 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:1899 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:1900 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:1901 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:1902 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:1903 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:1904 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:1905 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:1906 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:1907 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1908 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:118(161) a:0(0)    sid:1909 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_6 ; # asmjit.py:1526 contextlib.py:137   sid:1910;	jump if execz is 1 (exec mask == 0)
_bb_no_name_15:	 ;BB#15 predecessors:[_execmask_end_263_5] successors:[_execmask_end_263_6]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:1911 packed,offset,self.desc,0,
_execmask_end_263_6:	 ;BB#16 predecessors:[_bb_no_name_15,_execmask_end_263_5] successors:[_bb_no_name_17,_execmask_end_263_7]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1912 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:118(161) a:0(0)    sid:1913 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0x6,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:118(161) a:0(0)    sid:1914 src0_gprs,6,src1_gprs,;	v4.u32 = (0x6 ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:118(161) a:0(0)    sid:1915 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:118(161) a:0(0)    sid:1916 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:119(161) a:0(0)    sid:1917 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:119(161) a:0(0)    sid:1918 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:120(161) a:0(0)    sid:1919 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:119(161) a:0(0)    sid:1920 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v58  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[24:24]'v58 alloc 'idst'v11    s:12(35) v:119(161) a:0(0)    sid:1921 idst,sgpr_const_32768,accum[24:24],;	v11 = s5 + v58
	v_add_f32 v16,s5,v59  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[25:25]'v59 alloc 'idst'v16    s:12(35) v:119(161) a:0(0)    sid:1922 idst,sgpr_const_32768,accum[25:25],;	v16 = s5 + v59
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:1923 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v60  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[26:26]'v60 alloc 'idst'v11    s:12(35) v:117(161) a:0(0)    sid:1924 idst,sgpr_const_32768,accum[26:26],;	v11 = s5 + v60
	v_add_f32 v16,s5,v61  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[27:27]'v61 alloc 'idst'v16    s:12(35) v:117(161) a:0(0)    sid:1925 idst,sgpr_const_32768,accum[27:27],;	v16 = s5 + v61
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:1926 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v62  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[28:28]'v62 alloc 'idst'v11    s:12(35) v:115(161) a:0(0)    sid:1927 idst,sgpr_const_32768,accum[28:28],;	v11 = s5 + v62
	v_add_f32 v16,s5,v63  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[29:29]'v63 alloc 'idst'v16    s:12(35) v:115(161) a:0(0)    sid:1928 idst,sgpr_const_32768,accum[29:29],;	v16 = s5 + v63
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:1929 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v64  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[30:30]'v64 alloc 'idst'v11    s:12(35) v:113(161) a:0(0)    sid:1930 idst,sgpr_const_32768,accum[30:30],;	v11 = s5 + v64
	v_add_f32 v16,s5,v65  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[31:31]'v65 alloc 'idst'v16    s:12(35) v:113(161) a:0(0)    sid:1931 idst,sgpr_const_32768,accum[31:31],;	v16 = s5 + v65
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:1932 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:1933 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:1934 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:1935 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:1936 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:1937 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:1938 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:1939 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:1940 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:1941 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:1942 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1943 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:110(161) a:0(0)    sid:1944 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_7 ; # asmjit.py:1526 contextlib.py:137   sid:1945;	jump if execz is 1 (exec mask == 0)
_bb_no_name_17:	 ;BB#17 predecessors:[_execmask_end_263_6] successors:[_execmask_end_263_7]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:1946 packed,offset,self.desc,0,
_execmask_end_263_7:	 ;BB#18 predecessors:[_bb_no_name_17,_execmask_end_263_6] successors:[_bb_no_name_19,_execmask_end_263_8]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1947 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:110(161) a:0(0)    sid:1948 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0x8,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:110(161) a:0(0)    sid:1949 src0_gprs,8,src1_gprs,;	v4.u32 = (0x8 ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:110(161) a:0(0)    sid:1950 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:110(161) a:0(0)    sid:1951 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:111(161) a:0(0)    sid:1952 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:111(161) a:0(0)    sid:1953 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:112(161) a:0(0)    sid:1954 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:111(161) a:0(0)    sid:1955 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v66  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[32:32]'v66 alloc 'idst'v11    s:12(35) v:111(161) a:0(0)    sid:1956 idst,sgpr_const_32768,accum[32:32],;	v11 = s5 + v66
	v_add_f32 v16,s5,v67  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[33:33]'v67 alloc 'idst'v16    s:12(35) v:111(161) a:0(0)    sid:1957 idst,sgpr_const_32768,accum[33:33],;	v16 = s5 + v67
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:1958 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v68  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[34:34]'v68 alloc 'idst'v11    s:12(35) v:109(161) a:0(0)    sid:1959 idst,sgpr_const_32768,accum[34:34],;	v11 = s5 + v68
	v_add_f32 v16,s5,v69  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[35:35]'v69 alloc 'idst'v16    s:12(35) v:109(161) a:0(0)    sid:1960 idst,sgpr_const_32768,accum[35:35],;	v16 = s5 + v69
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:1961 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v70  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[36:36]'v70 alloc 'idst'v11    s:12(35) v:107(161) a:0(0)    sid:1962 idst,sgpr_const_32768,accum[36:36],;	v11 = s5 + v70
	v_add_f32 v16,s5,v71  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[37:37]'v71 alloc 'idst'v16    s:12(35) v:107(161) a:0(0)    sid:1963 idst,sgpr_const_32768,accum[37:37],;	v16 = s5 + v71
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:1964 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v72  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[38:38]'v72 alloc 'idst'v11    s:12(35) v:105(161) a:0(0)    sid:1965 idst,sgpr_const_32768,accum[38:38],;	v11 = s5 + v72
	v_add_f32 v16,s5,v73  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[39:39]'v73 alloc 'idst'v16    s:12(35) v:105(161) a:0(0)    sid:1966 idst,sgpr_const_32768,accum[39:39],;	v16 = s5 + v73
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:1967 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:1968 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:1969 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:1970 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:1971 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:1972 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:1973 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:1974 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:1975 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:1976 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:1977 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1978 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:102(161) a:0(0)    sid:1979 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_8 ; # asmjit.py:1526 contextlib.py:137   sid:1980;	jump if execz is 1 (exec mask == 0)
_bb_no_name_19:	 ;BB#19 predecessors:[_execmask_end_263_7] successors:[_execmask_end_263_8]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:1981 packed,offset,self.desc,0,
_execmask_end_263_8:	 ;BB#20 predecessors:[_bb_no_name_19,_execmask_end_263_7] successors:[_bb_no_name_21,_execmask_end_263_9]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1982 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:102(161) a:0(0)    sid:1983 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0xa,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:102(161) a:0(0)    sid:1984 src0_gprs,10,src1_gprs,;	v4.u32 = (0xa ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:102(161) a:0(0)    sid:1985 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:102(161) a:0(0)    sid:1986 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:103(161) a:0(0)    sid:1987 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:103(161) a:0(0)    sid:1988 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:104(161) a:0(0)    sid:1989 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:103(161) a:0(0)    sid:1990 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v74  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[40:40]'v74 alloc 'idst'v11    s:12(35) v:103(161) a:0(0)    sid:1991 idst,sgpr_const_32768,accum[40:40],;	v11 = s5 + v74
	v_add_f32 v16,s5,v75  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[41:41]'v75 alloc 'idst'v16    s:12(35) v:103(161) a:0(0)    sid:1992 idst,sgpr_const_32768,accum[41:41],;	v16 = s5 + v75
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:1993 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v76  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[42:42]'v76 alloc 'idst'v11    s:12(35) v:101(161) a:0(0)    sid:1994 idst,sgpr_const_32768,accum[42:42],;	v11 = s5 + v76
	v_add_f32 v16,s5,v77  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[43:43]'v77 alloc 'idst'v16    s:12(35) v:101(161) a:0(0)    sid:1995 idst,sgpr_const_32768,accum[43:43],;	v16 = s5 + v77
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:1996 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v78  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[44:44]'v78 alloc 'idst'v11    s:12(35) v:99(161) a:0(0)    sid:1997 idst,sgpr_const_32768,accum[44:44],;	v11 = s5 + v78
	v_add_f32 v16,s5,v79  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[45:45]'v79 alloc 'idst'v16    s:12(35) v:99(161) a:0(0)    sid:1998 idst,sgpr_const_32768,accum[45:45],;	v16 = s5 + v79
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:1999 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v80  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[46:46]'v80 alloc 'idst'v11    s:12(35) v:97(161) a:0(0)    sid:2000 idst,sgpr_const_32768,accum[46:46],;	v11 = s5 + v80
	v_add_f32 v16,s5,v81  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[47:47]'v81 alloc 'idst'v16    s:12(35) v:97(161) a:0(0)    sid:2001 idst,sgpr_const_32768,accum[47:47],;	v16 = s5 + v81
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:2002 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2003 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2004 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2005 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:2006 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2007 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:2008 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:2009 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:2010 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:2011 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:2012 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2013 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:94(161) a:0(0)    sid:2014 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_9 ; # asmjit.py:1526 contextlib.py:137   sid:2015;	jump if execz is 1 (exec mask == 0)
_bb_no_name_21:	 ;BB#21 predecessors:[_execmask_end_263_8] successors:[_execmask_end_263_9]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:2016 packed,offset,self.desc,0,
_execmask_end_263_9:	 ;BB#22 predecessors:[_bb_no_name_21,_execmask_end_263_8] successors:[_bb_no_name_23,_execmask_end_263_10]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2017 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:94(161) a:0(0)    sid:2018 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0xc,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:94(161) a:0(0)    sid:2019 src0_gprs,12,src1_gprs,;	v4.u32 = (0xc ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:94(161) a:0(0)    sid:2020 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:94(161) a:0(0)    sid:2021 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:95(161) a:0(0)    sid:2022 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:95(161) a:0(0)    sid:2023 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:96(161) a:0(0)    sid:2024 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:95(161) a:0(0)    sid:2025 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v82  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[48:48]'v82 alloc 'idst'v11    s:12(35) v:95(161) a:0(0)    sid:2026 idst,sgpr_const_32768,accum[48:48],;	v11 = s5 + v82
	v_add_f32 v16,s5,v83  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[49:49]'v83 alloc 'idst'v16    s:12(35) v:95(161) a:0(0)    sid:2027 idst,sgpr_const_32768,accum[49:49],;	v16 = s5 + v83
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:2028 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v84  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[50:50]'v84 alloc 'idst'v11    s:12(35) v:93(161) a:0(0)    sid:2029 idst,sgpr_const_32768,accum[50:50],;	v11 = s5 + v84
	v_add_f32 v16,s5,v85  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[51:51]'v85 alloc 'idst'v16    s:12(35) v:93(161) a:0(0)    sid:2030 idst,sgpr_const_32768,accum[51:51],;	v16 = s5 + v85
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:2031 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v86  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[52:52]'v86 alloc 'idst'v11    s:12(35) v:91(161) a:0(0)    sid:2032 idst,sgpr_const_32768,accum[52:52],;	v11 = s5 + v86
	v_add_f32 v16,s5,v87  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[53:53]'v87 alloc 'idst'v16    s:12(35) v:91(161) a:0(0)    sid:2033 idst,sgpr_const_32768,accum[53:53],;	v16 = s5 + v87
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:2034 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v88  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[54:54]'v88 alloc 'idst'v11    s:12(35) v:89(161) a:0(0)    sid:2035 idst,sgpr_const_32768,accum[54:54],;	v11 = s5 + v88
	v_add_f32 v16,s5,v89  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[55:55]'v89 alloc 'idst'v16    s:12(35) v:89(161) a:0(0)    sid:2036 idst,sgpr_const_32768,accum[55:55],;	v16 = s5 + v89
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:2037 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2038 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2039 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2040 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:2041 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2042 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:2043 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:2044 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:2045 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:2046 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:2047 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2048 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:86(161) a:0(0)    sid:2049 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_10 ; # asmjit.py:1526 contextlib.py:137   sid:2050;	jump if execz is 1 (exec mask == 0)
_bb_no_name_23:	 ;BB#23 predecessors:[_execmask_end_263_9] successors:[_execmask_end_263_10]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:2051 packed,offset,self.desc,0,
_execmask_end_263_10:	 ;BB#24 predecessors:[_bb_no_name_23,_execmask_end_263_9] successors:[_bb_no_name_25,_execmask_end_263_11]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2052 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:86(161) a:0(0)    sid:2053 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0xe,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:86(161) a:0(0)    sid:2054 src0_gprs,14,src1_gprs,;	v4.u32 = (0xe ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:86(161) a:0(0)    sid:2055 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:86(161) a:0(0)    sid:2056 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:87(161) a:0(0)    sid:2057 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:87(161) a:0(0)    sid:2058 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:88(161) a:0(0)    sid:2059 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:87(161) a:0(0)    sid:2060 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v90  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[56:56]'v90 alloc 'idst'v11    s:12(35) v:87(161) a:0(0)    sid:2061 idst,sgpr_const_32768,accum[56:56],;	v11 = s5 + v90
	v_add_f32 v16,s5,v91  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[57:57]'v91 alloc 'idst'v16    s:12(35) v:87(161) a:0(0)    sid:2062 idst,sgpr_const_32768,accum[57:57],;	v16 = s5 + v91
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:2063 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v92  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[58:58]'v92 alloc 'idst'v11    s:12(35) v:85(161) a:0(0)    sid:2064 idst,sgpr_const_32768,accum[58:58],;	v11 = s5 + v92
	v_add_f32 v16,s5,v93  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[59:59]'v93 alloc 'idst'v16    s:12(35) v:85(161) a:0(0)    sid:2065 idst,sgpr_const_32768,accum[59:59],;	v16 = s5 + v93
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:2066 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v94  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[60:60]'v94 alloc 'idst'v11    s:12(35) v:83(161) a:0(0)    sid:2067 idst,sgpr_const_32768,accum[60:60],;	v11 = s5 + v94
	v_add_f32 v16,s5,v95  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[61:61]'v95 alloc 'idst'v16    s:12(35) v:83(161) a:0(0)    sid:2068 idst,sgpr_const_32768,accum[61:61],;	v16 = s5 + v95
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:2069 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v96  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[62:62]'v96 alloc 'idst'v11    s:12(35) v:81(161) a:0(0)    sid:2070 idst,sgpr_const_32768,accum[62:62],;	v11 = s5 + v96
	v_add_f32 v16,s5,v97  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[63:63]'v97 alloc 'idst'v16    s:12(35) v:81(161) a:0(0)    sid:2071 idst,sgpr_const_32768,accum[63:63],;	v16 = s5 + v97
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:2072 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2073 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2074 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2075 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:2076 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2077 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:2078 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:2079 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:2080 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:2081 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:2082 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2083 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:78(161) a:0(0)    sid:2084 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_11 ; # asmjit.py:1526 contextlib.py:137   sid:2085;	jump if execz is 1 (exec mask == 0)
_bb_no_name_25:	 ;BB#25 predecessors:[_execmask_end_263_10] successors:[_execmask_end_263_11]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:2086 packed,offset,self.desc,0,
_execmask_end_263_11:	 ;BB#26 predecessors:[_bb_no_name_25,_execmask_end_263_10] successors:[_bb_no_name_27,_execmask_end_263_12]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2087 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:78(161) a:0(0)    sid:2088 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0x0,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:78(161) a:0(0)    sid:2089 src0_gprs,0,src1_gprs,;	v4.u32 = (0x0 ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:78(161) a:0(0)    sid:2090 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:78(161) a:0(0)    sid:2091 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:79(161) a:0(0)    sid:2092 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:79(161) a:0(0)    sid:2093 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:80(161) a:0(0)    sid:2094 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:79(161) a:0(0)    sid:2095 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v98  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[64:64]'v98 alloc 'idst'v11    s:12(35) v:79(161) a:0(0)    sid:2096 idst,sgpr_const_32768,accum[64:64],;	v11 = s5 + v98
	v_add_f32 v16,s5,v99  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[65:65]'v99 alloc 'idst'v16    s:12(35) v:79(161) a:0(0)    sid:2097 idst,sgpr_const_32768,accum[65:65],;	v16 = s5 + v99
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:2098 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v100  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[66:66]'v100 alloc 'idst'v11    s:12(35) v:77(161) a:0(0)    sid:2099 idst,sgpr_const_32768,accum[66:66],;	v11 = s5 + v100
	v_add_f32 v16,s5,v101  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[67:67]'v101 alloc 'idst'v16    s:12(35) v:77(161) a:0(0)    sid:2100 idst,sgpr_const_32768,accum[67:67],;	v16 = s5 + v101
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:2101 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v102  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[68:68]'v102 alloc 'idst'v11    s:12(35) v:75(161) a:0(0)    sid:2102 idst,sgpr_const_32768,accum[68:68],;	v11 = s5 + v102
	v_add_f32 v16,s5,v103  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[69:69]'v103 alloc 'idst'v16    s:12(35) v:75(161) a:0(0)    sid:2103 idst,sgpr_const_32768,accum[69:69],;	v16 = s5 + v103
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:2104 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v104  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[70:70]'v104 alloc 'idst'v11    s:12(35) v:73(161) a:0(0)    sid:2105 idst,sgpr_const_32768,accum[70:70],;	v11 = s5 + v104
	v_add_f32 v16,s5,v105  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[71:71]'v105 alloc 'idst'v16    s:12(35) v:73(161) a:0(0)    sid:2106 idst,sgpr_const_32768,accum[71:71],;	v16 = s5 + v105
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:2107 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2108 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2109 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2110 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:2111 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2112 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:2113 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:2114 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:2115 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:2116 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:2117 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2118 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:70(161) a:0(0)    sid:2119 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_12 ; # asmjit.py:1526 contextlib.py:137   sid:2120;	jump if execz is 1 (exec mask == 0)
_bb_no_name_27:	 ;BB#27 predecessors:[_execmask_end_263_11] successors:[_execmask_end_263_12]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:2121 packed,offset,self.desc,0,
_execmask_end_263_12:	 ;BB#28 predecessors:[_bb_no_name_27,_execmask_end_263_11] successors:[_bb_no_name_29,_execmask_end_263_13]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2122 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:70(161) a:0(0)    sid:2123 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0x2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:70(161) a:0(0)    sid:2124 src0_gprs,2,src1_gprs,;	v4.u32 = (0x2 ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:70(161) a:0(0)    sid:2125 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:70(161) a:0(0)    sid:2126 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:71(161) a:0(0)    sid:2127 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:71(161) a:0(0)    sid:2128 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:72(161) a:0(0)    sid:2129 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:71(161) a:0(0)    sid:2130 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v106  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[72:72]'v106 alloc 'idst'v11    s:12(35) v:71(161) a:0(0)    sid:2131 idst,sgpr_const_32768,accum[72:72],;	v11 = s5 + v106
	v_add_f32 v16,s5,v107  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[73:73]'v107 alloc 'idst'v16    s:12(35) v:71(161) a:0(0)    sid:2132 idst,sgpr_const_32768,accum[73:73],;	v16 = s5 + v107
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:2133 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v108  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[74:74]'v108 alloc 'idst'v11    s:12(35) v:69(161) a:0(0)    sid:2134 idst,sgpr_const_32768,accum[74:74],;	v11 = s5 + v108
	v_add_f32 v16,s5,v109  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[75:75]'v109 alloc 'idst'v16    s:12(35) v:69(161) a:0(0)    sid:2135 idst,sgpr_const_32768,accum[75:75],;	v16 = s5 + v109
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:2136 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v110  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[76:76]'v110 alloc 'idst'v11    s:12(35) v:67(161) a:0(0)    sid:2137 idst,sgpr_const_32768,accum[76:76],;	v11 = s5 + v110
	v_add_f32 v16,s5,v111  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[77:77]'v111 alloc 'idst'v16    s:12(35) v:67(161) a:0(0)    sid:2138 idst,sgpr_const_32768,accum[77:77],;	v16 = s5 + v111
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:2139 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v112  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[78:78]'v112 alloc 'idst'v11    s:12(35) v:65(161) a:0(0)    sid:2140 idst,sgpr_const_32768,accum[78:78],;	v11 = s5 + v112
	v_add_f32 v16,s5,v113  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[79:79]'v113 alloc 'idst'v16    s:12(35) v:65(161) a:0(0)    sid:2141 idst,sgpr_const_32768,accum[79:79],;	v16 = s5 + v113
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:2142 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2143 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2144 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2145 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:2146 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2147 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:2148 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:2149 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:2150 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:2151 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:2152 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2153 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:62(161) a:0(0)    sid:2154 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_13 ; # asmjit.py:1526 contextlib.py:137   sid:2155;	jump if execz is 1 (exec mask == 0)
_bb_no_name_29:	 ;BB#29 predecessors:[_execmask_end_263_12] successors:[_execmask_end_263_13]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:2156 packed,offset,self.desc,0,
_execmask_end_263_13:	 ;BB#30 predecessors:[_bb_no_name_29,_execmask_end_263_12] successors:[_bb_no_name_31,_execmask_end_263_14]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2157 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:62(161) a:0(0)    sid:2158 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:62(161) a:0(0)    sid:2159 src0_gprs,4,src1_gprs,;	v4.u32 = (0x4 ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:62(161) a:0(0)    sid:2160 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:62(161) a:0(0)    sid:2161 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:63(161) a:0(0)    sid:2162 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:63(161) a:0(0)    sid:2163 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:64(161) a:0(0)    sid:2164 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:63(161) a:0(0)    sid:2165 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v114  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[80:80]'v114 alloc 'idst'v11    s:12(35) v:63(161) a:0(0)    sid:2166 idst,sgpr_const_32768,accum[80:80],;	v11 = s5 + v114
	v_add_f32 v16,s5,v115  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[81:81]'v115 alloc 'idst'v16    s:12(35) v:63(161) a:0(0)    sid:2167 idst,sgpr_const_32768,accum[81:81],;	v16 = s5 + v115
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:2168 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v116  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[82:82]'v116 alloc 'idst'v11    s:12(35) v:61(161) a:0(0)    sid:2169 idst,sgpr_const_32768,accum[82:82],;	v11 = s5 + v116
	v_add_f32 v16,s5,v117  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[83:83]'v117 alloc 'idst'v16    s:12(35) v:61(161) a:0(0)    sid:2170 idst,sgpr_const_32768,accum[83:83],;	v16 = s5 + v117
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:2171 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v118  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[84:84]'v118 alloc 'idst'v11    s:12(35) v:59(161) a:0(0)    sid:2172 idst,sgpr_const_32768,accum[84:84],;	v11 = s5 + v118
	v_add_f32 v16,s5,v119  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[85:85]'v119 alloc 'idst'v16    s:12(35) v:59(161) a:0(0)    sid:2173 idst,sgpr_const_32768,accum[85:85],;	v16 = s5 + v119
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:2174 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v120  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[86:86]'v120 alloc 'idst'v11    s:12(35) v:57(161) a:0(0)    sid:2175 idst,sgpr_const_32768,accum[86:86],;	v11 = s5 + v120
	v_add_f32 v16,s5,v121  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[87:87]'v121 alloc 'idst'v16    s:12(35) v:57(161) a:0(0)    sid:2176 idst,sgpr_const_32768,accum[87:87],;	v16 = s5 + v121
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:2177 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2178 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2179 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2180 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:2181 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2182 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:2183 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:2184 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:2185 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:2186 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:2187 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2188 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:54(161) a:0(0)    sid:2189 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_14 ; # asmjit.py:1526 contextlib.py:137   sid:2190;	jump if execz is 1 (exec mask == 0)
_bb_no_name_31:	 ;BB#31 predecessors:[_execmask_end_263_13] successors:[_execmask_end_263_14]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:2191 packed,offset,self.desc,0,
_execmask_end_263_14:	 ;BB#32 predecessors:[_bb_no_name_31,_execmask_end_263_13] successors:[_bb_no_name_33,_execmask_end_263_15]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2192 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:54(161) a:0(0)    sid:2193 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0x6,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:54(161) a:0(0)    sid:2194 src0_gprs,6,src1_gprs,;	v4.u32 = (0x6 ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:54(161) a:0(0)    sid:2195 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:54(161) a:0(0)    sid:2196 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:55(161) a:0(0)    sid:2197 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:55(161) a:0(0)    sid:2198 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:56(161) a:0(0)    sid:2199 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:55(161) a:0(0)    sid:2200 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v122  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[88:88]'v122 alloc 'idst'v11    s:12(35) v:55(161) a:0(0)    sid:2201 idst,sgpr_const_32768,accum[88:88],;	v11 = s5 + v122
	v_add_f32 v16,s5,v123  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[89:89]'v123 alloc 'idst'v16    s:12(35) v:55(161) a:0(0)    sid:2202 idst,sgpr_const_32768,accum[89:89],;	v16 = s5 + v123
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:2203 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v124  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[90:90]'v124 alloc 'idst'v11    s:12(35) v:53(161) a:0(0)    sid:2204 idst,sgpr_const_32768,accum[90:90],;	v11 = s5 + v124
	v_add_f32 v16,s5,v125  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[91:91]'v125 alloc 'idst'v16    s:12(35) v:53(161) a:0(0)    sid:2205 idst,sgpr_const_32768,accum[91:91],;	v16 = s5 + v125
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:2206 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v126  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[92:92]'v126 alloc 'idst'v11    s:12(35) v:51(161) a:0(0)    sid:2207 idst,sgpr_const_32768,accum[92:92],;	v11 = s5 + v126
	v_add_f32 v16,s5,v127  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[93:93]'v127 alloc 'idst'v16    s:12(35) v:51(161) a:0(0)    sid:2208 idst,sgpr_const_32768,accum[93:93],;	v16 = s5 + v127
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:2209 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v128  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[94:94]'v128 alloc 'idst'v11    s:12(35) v:49(161) a:0(0)    sid:2210 idst,sgpr_const_32768,accum[94:94],;	v11 = s5 + v128
	v_add_f32 v16,s5,v129  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[95:95]'v129 alloc 'idst'v16    s:12(35) v:49(161) a:0(0)    sid:2211 idst,sgpr_const_32768,accum[95:95],;	v16 = s5 + v129
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:2212 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2213 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2214 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2215 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:2216 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2217 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:2218 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:2219 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:2220 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:2221 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:2222 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2223 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:46(161) a:0(0)    sid:2224 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_15 ; # asmjit.py:1526 contextlib.py:137   sid:2225;	jump if execz is 1 (exec mask == 0)
_bb_no_name_33:	 ;BB#33 predecessors:[_execmask_end_263_14] successors:[_execmask_end_263_15]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:2226 packed,offset,self.desc,0,
_execmask_end_263_15:	 ;BB#34 predecessors:[_bb_no_name_33,_execmask_end_263_14] successors:[_bb_no_name_35,_execmask_end_263_16]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2227 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:46(161) a:0(0)    sid:2228 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0x8,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:46(161) a:0(0)    sid:2229 src0_gprs,8,src1_gprs,;	v4.u32 = (0x8 ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:46(161) a:0(0)    sid:2230 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:46(161) a:0(0)    sid:2231 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:47(161) a:0(0)    sid:2232 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:47(161) a:0(0)    sid:2233 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:48(161) a:0(0)    sid:2234 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:47(161) a:0(0)    sid:2235 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v130  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[96:96]'v130 alloc 'idst'v11    s:12(35) v:47(161) a:0(0)    sid:2236 idst,sgpr_const_32768,accum[96:96],;	v11 = s5 + v130
	v_add_f32 v16,s5,v131  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[97:97]'v131 alloc 'idst'v16    s:12(35) v:47(161) a:0(0)    sid:2237 idst,sgpr_const_32768,accum[97:97],;	v16 = s5 + v131
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:2238 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v132  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[98:98]'v132 alloc 'idst'v11    s:12(35) v:45(161) a:0(0)    sid:2239 idst,sgpr_const_32768,accum[98:98],;	v11 = s5 + v132
	v_add_f32 v16,s5,v133  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[99:99]'v133 alloc 'idst'v16    s:12(35) v:45(161) a:0(0)    sid:2240 idst,sgpr_const_32768,accum[99:99],;	v16 = s5 + v133
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:2241 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v134  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[100:100]'v134 alloc 'idst'v11    s:12(35) v:43(161) a:0(0)    sid:2242 idst,sgpr_const_32768,accum[100:100],;	v11 = s5 + v134
	v_add_f32 v16,s5,v135  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[101:101]'v135 alloc 'idst'v16    s:12(35) v:43(161) a:0(0)    sid:2243 idst,sgpr_const_32768,accum[101:101],;	v16 = s5 + v135
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:2244 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v136  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[102:102]'v136 alloc 'idst'v11    s:12(35) v:41(161) a:0(0)    sid:2245 idst,sgpr_const_32768,accum[102:102],;	v11 = s5 + v136
	v_add_f32 v16,s5,v137  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[103:103]'v137 alloc 'idst'v16    s:12(35) v:41(161) a:0(0)    sid:2246 idst,sgpr_const_32768,accum[103:103],;	v16 = s5 + v137
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:2247 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2248 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2249 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2250 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:2251 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2252 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:2253 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:2254 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:2255 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:2256 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:2257 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2258 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:38(161) a:0(0)    sid:2259 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_16 ; # asmjit.py:1526 contextlib.py:137   sid:2260;	jump if execz is 1 (exec mask == 0)
_bb_no_name_35:	 ;BB#35 predecessors:[_execmask_end_263_15] successors:[_execmask_end_263_16]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:2261 packed,offset,self.desc,0,
_execmask_end_263_16:	 ;BB#36 predecessors:[_bb_no_name_35,_execmask_end_263_15] successors:[_bb_no_name_37,_execmask_end_263_17]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2262 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:38(161) a:0(0)    sid:2263 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0xa,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:38(161) a:0(0)    sid:2264 src0_gprs,10,src1_gprs,;	v4.u32 = (0xa ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:38(161) a:0(0)    sid:2265 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:38(161) a:0(0)    sid:2266 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:39(161) a:0(0)    sid:2267 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:39(161) a:0(0)    sid:2268 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:40(161) a:0(0)    sid:2269 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:39(161) a:0(0)    sid:2270 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v138  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[104:104]'v138 alloc 'idst'v11    s:12(35) v:39(161) a:0(0)    sid:2271 idst,sgpr_const_32768,accum[104:104],;	v11 = s5 + v138
	v_add_f32 v16,s5,v139  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[105:105]'v139 alloc 'idst'v16    s:12(35) v:39(161) a:0(0)    sid:2272 idst,sgpr_const_32768,accum[105:105],;	v16 = s5 + v139
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:2273 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v140  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[106:106]'v140 alloc 'idst'v11    s:12(35) v:37(161) a:0(0)    sid:2274 idst,sgpr_const_32768,accum[106:106],;	v11 = s5 + v140
	v_add_f32 v16,s5,v141  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[107:107]'v141 alloc 'idst'v16    s:12(35) v:37(161) a:0(0)    sid:2275 idst,sgpr_const_32768,accum[107:107],;	v16 = s5 + v141
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:2276 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v142  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[108:108]'v142 alloc 'idst'v11    s:12(35) v:35(161) a:0(0)    sid:2277 idst,sgpr_const_32768,accum[108:108],;	v11 = s5 + v142
	v_add_f32 v16,s5,v143  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[109:109]'v143 alloc 'idst'v16    s:12(35) v:35(161) a:0(0)    sid:2278 idst,sgpr_const_32768,accum[109:109],;	v16 = s5 + v143
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:2279 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v144  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[110:110]'v144 alloc 'idst'v11    s:12(35) v:33(161) a:0(0)    sid:2280 idst,sgpr_const_32768,accum[110:110],;	v11 = s5 + v144
	v_add_f32 v16,s5,v145  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[111:111]'v145 alloc 'idst'v16    s:12(35) v:33(161) a:0(0)    sid:2281 idst,sgpr_const_32768,accum[111:111],;	v16 = s5 + v145
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:2282 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2283 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2284 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2285 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:2286 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2287 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:2288 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:2289 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:2290 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:2291 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:2292 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2293 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:30(161) a:0(0)    sid:2294 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_17 ; # asmjit.py:1526 contextlib.py:137   sid:2295;	jump if execz is 1 (exec mask == 0)
_bb_no_name_37:	 ;BB#37 predecessors:[_execmask_end_263_16] successors:[_execmask_end_263_17]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:2296 packed,offset,self.desc,0,
_execmask_end_263_17:	 ;BB#38 predecessors:[_bb_no_name_37,_execmask_end_263_16] successors:[_bb_no_name_39,_execmask_end_263_18]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2297 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 alloc 'src1_gprs'v4    s:12(35) v:30(161) a:0(0)    sid:2298 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0xc,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:12(35) v:30(161) a:0(0)    sid:2299 src0_gprs,12,src1_gprs,;	v4.u32 = (0xc ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:12(35) v:30(161) a:0(0)    sid:2300 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v4,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'column'v4    s:12(35) v:30(161) a:0(0)    sid:2301 column,output_col,src1_gprs,;	v4 = v2 + v4
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:251 alloc 'src0_gprs'v5    s:12(35) v:31(161) a:0(0)    sid:2302 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:12(35) v:31(161) a:0(0)    sid:2303 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v11    s:12(35) v:32(161) a:0(0)    sid:2304 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:12(35) v:31(161) a:0(0)    sid:2305 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v146  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[112:112]'v146 alloc 'idst'v11    s:12(35) v:31(161) a:0(0)    sid:2306 idst,sgpr_const_32768,accum[112:112],;	v11 = s5 + v146
	v_add_f32 v16,s5,v147  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[113:113]'v147 alloc 'idst'v16    s:12(35) v:31(161) a:0(0)    sid:2307 idst,sgpr_const_32768,accum[113:113],;	v16 = s5 + v147
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v11 free 'idst'v16   sid:2308 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v148  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[114:114]'v148 alloc 'idst'v11    s:12(35) v:29(161) a:0(0)    sid:2309 idst,sgpr_const_32768,accum[114:114],;	v11 = s5 + v148
	v_add_f32 v16,s5,v149  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[115:115]'v149 alloc 'idst'v16    s:12(35) v:29(161) a:0(0)    sid:2310 idst,sgpr_const_32768,accum[115:115],;	v16 = s5 + v149
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v11 free 'idst'v16   sid:2311 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v150  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[116:116]'v150 alloc 'idst'v11    s:12(35) v:27(161) a:0(0)    sid:2312 idst,sgpr_const_32768,accum[116:116],;	v11 = s5 + v150
	v_add_f32 v16,s5,v151  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[117:117]'v151 alloc 'idst'v16    s:12(35) v:27(161) a:0(0)    sid:2313 idst,sgpr_const_32768,accum[117:117],;	v16 = s5 + v151
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v11 free 'idst'v16   sid:2314 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v152  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[118:118]'v152 alloc 'idst'v11    s:12(35) v:25(161) a:0(0)    sid:2315 idst,sgpr_const_32768,accum[118:118],;	v11 = s5 + v152
	v_add_f32 v16,s5,v153  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[119:119]'v153 alloc 'idst'v16    s:12(35) v:25(161) a:0(0)    sid:2316 idst,sgpr_const_32768,accum[119:119],;	v16 = s5 + v153
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'idst'v11 free 'idst'v16   sid:2317 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2318 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2319 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2320 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257   sid:2321 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2322 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259   sid:2323 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261   sid:2324 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262   sid:2325 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261   sid:2326 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262   sid:2327 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2328 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:14(35) v:22(161) a:0(0)    sid:2329 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_18 ; # asmjit.py:1526 contextlib.py:137   sid:2330;	jump if execz is 1 (exec mask == 0)
_bb_no_name_39:	 ;BB#39 predecessors:[_execmask_end_263_17] successors:[_execmask_end_263_18]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'offset'v5   sid:2331 packed,offset,self.desc,0,
_execmask_end_263_18:	 ;BB#40 predecessors:[_bb_no_name_39,_execmask_end_263_17] successors:[_bb_no_name_41,_execmask_end_263_19]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2332 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_lshlrev_b32 v4,0x2,s18  ; # gemm_fp8_gfx942.py:250 free 'packet_phase's18 alloc 'src1_gprs'v4    s:11(35) v:22(161) a:0(0)    sid:2333 src1_gprs,2,packet_phase,;	v4.b32 = s18 << 0x2[4:0];
	v_xor_b32 v4,0xe,v4  ; # gemm_fp8_gfx942.py:250 free 'src1_gprs'v4 alloc 'src0_gprs'v4    s:11(35) v:22(161) a:0(0)    sid:2334 src0_gprs,14,src1_gprs,;	v4.u32 = (0xe ^ v4.u32)
	v_lshlrev_b32 v4,0x4,v4  ; # gemm_fp8_gfx942.py:250 free 'src0_gprs'v4 alloc 'src1_gprs'v4    s:11(35) v:22(161) a:0(0)    sid:2335 src1_gprs,4,src0_gprs,;	v4.b32 = v4 << 0x4[4:0];
	v_add_u32_e32 v2,v2,v4  ; # gemm_fp8_gfx942.py:250 free 'output_col'v2 free 'src1_gprs'v4 alloc 'column'v2    s:11(35) v:21(161) a:0(0)    sid:2336 column,output_col,src1_gprs,;	v2 = v2 + v4
	v_add_u32_e32 v4,0x80,v9  ; # gemm_fp8_gfx942.py:251 free 'local_row'v9 alloc 'src0_gprs'v4    s:11(35) v:21(161) a:0(0)    sid:2337 src0_gprs,128,local_row,;	v4 = 0x80 + v9
	v_lshlrev_b32 v4,0xd,v4  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v4 alloc 'src0_gprs'v4    s:11(35) v:21(161) a:0(0)    sid:2338 src0_gprs,13,src0_gprs,;	v4.b32 = v4 << 0xd[4:0];
	v_lshlrev_b32 v5,0x1,v2  ; # gemm_fp8_gfx942.py:251 alloc 'src1_gprs'v5    s:11(35) v:22(161) a:0(0)    sid:2339 src1_gprs,1,column,;	v5.b32 = v2 << 0x1[4:0];
	v_add_u32_e32 v4,v4,v5  ; # gemm_fp8_gfx942.py:251 free 'src0_gprs'v4 free 'src1_gprs'v5 alloc 'offset'v4    s:11(35) v:21(161) a:0(0)    sid:2340 offset,src0_gprs,src1_gprs,;	v4 = v4 + v5
	v_add_f32 v5,s5,v154  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[120:120]'v154 alloc 'idst'v5    s:11(35) v:21(161) a:0(0)    sid:2341 idst,sgpr_const_32768,accum[120:120],;	v5 = s5 + v154
	v_add_f32 v9,s5,v155  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'accum[121:121]'v155 alloc 'idst'v9    s:11(35) v:21(161) a:0(0)    sid:2342 idst,sgpr_const_32768,accum[121:121],;	v9 = s5 + v155
	v_perm_b32 v12,v5,v9,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:252 free 'idst'v5 free 'idst'v9   sid:2343 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v5,s5,v156  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[122:122]'v156 alloc 'idst'v5    s:11(35) v:19(161) a:0(0)    sid:2344 idst,sgpr_const_32768,accum[122:122],;	v5 = s5 + v156
	v_add_f32 v9,s5,v157  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'accum[123:123]'v157 alloc 'idst'v9    s:11(35) v:19(161) a:0(0)    sid:2345 idst,sgpr_const_32768,accum[123:123],;	v9 = s5 + v157
	v_perm_b32 v13,v5,v9,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:253 free 'idst'v5 free 'idst'v9   sid:2346 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v5,s5,v158  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[124:124]'v158 alloc 'idst'v5    s:11(35) v:17(161) a:0(0)    sid:2347 idst,sgpr_const_32768,accum[124:124],;	v5 = s5 + v158
	v_add_f32 v9,s5,v159  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'accum[125:125]'v159 alloc 'idst'v9    s:11(35) v:17(161) a:0(0)    sid:2348 idst,sgpr_const_32768,accum[125:125],;	v9 = s5 + v159
	v_perm_b32 v14,v5,v9,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:254 free 'idst'v5 free 'idst'v9   sid:2349 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v5,s5,v160  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'accum[126:126]'v160 alloc 'idst'v5    s:11(35) v:15(161) a:0(0)    sid:2350 idst,sgpr_const_32768,accum[126:126],;	v5 = s5 + v160
	v_add_f32 v9,s5,v161  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'sgpr_const_32768's5 free 'accum[127:127]'v161 alloc 'idst'v9    s:10(35) v:15(15) a:0(0)    sid:2351 idst,sgpr_const_32768,accum[127:127],;	v9 = s5 + v161
	v_perm_b32 v15,v5,v9,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:255 free 'sgpr_const_50464518's6 free 'idst'v5 free 'idst'v9   sid:2352 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:257   sid:2353 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:257   sid:2354 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:257   sid:2355 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:257 free 'exchange_lane'v1   sid:2356 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:258   sid:2357 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:259 free 'odd_group'v3   sid:2358 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:261 free 'exchanged[2:2]'v8   sid:2359 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:262 free 'exchanged[0:0]'v6   sid:2360 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:261 free 'exchanged[3:3]'v10   sid:2361 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:262 free 'exchanged[1:1]'v7   sid:2362 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v2  ; # asmjit.py:1520 contextlib.py:137 free 'column'v2   sid:2363 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v2.u32 )
	s_and_saveexec_b64 s[6:7],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[6:7]    s:11(35) v:6(15) a:0(0)    sid:2364 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[6:7]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_263_19 ; # asmjit.py:1526 contextlib.py:137   sid:2365;	jump if execz is 1 (exec mask == 0)
_bb_no_name_41:	 ;BB#41 predecessors:[_execmask_end_263_18] successors:[_execmask_end_263_19]
	buffer_store_dwordx4 v[12:15],v4,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:264 free 'self.desc's[32:35] free 'offset'v4 free 'packed'v[12:15]   sid:2366 packed,offset,self.desc,0,
_execmask_end_263_19:	 ;BB#42 predecessors:[_bb_no_name_41,_execmask_end_263_18] successors:[]
	s_mov_b64 exec,s[6:7]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[6:7]   sid:2367 exec,ExecMask_exec_backup,;	exec = s[6:7]

	;;#ASMEND
	s_mov_b32 s0, 0                                  ;	s0 = 0
	;;#ASMSTART
	 ; lds_buffer s0 
	;;#ASMEND
	;;#ASMSTART
	.pushsection .rodata
    .align 8
    .asciz  ".git:c945d7560eddf91dec8ee9468cebd06a9b595383"
    .popsection
	;;#ASMEND
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
		.amdhsa_group_segment_fixed_size 32768
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 44
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_kernarg_preload_length 0
		.amdhsa_user_sgpr_kernarg_preload_offset 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 1
		.amdhsa_system_sgpr_workgroup_id_z 1
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 240
		.amdhsa_next_free_sgpr 36
		.amdhsa_accum_offset 240
		.amdhsa_reserve_vcc 0
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_tg_split 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i, .Lfunc_end0-_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
                                        ; -- End function
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.num_vgpr, 240
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.num_agpr, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.numbered_sgpr, 36
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.num_named_barrier, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.private_seg_size, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.uses_vcc, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.uses_flat_scratch, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.has_dyn_sized_stack, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.has_recursion, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.has_indirect_call, 0
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 19320
; TotalNumSgprs: 42
; NumVgprs: 240
; NumAgprs: 0
; TotalNumVgprs: 240
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 32768 bytes/workgroup (compile time only)
; SGPRBlocks: 5
; VGPRBlocks: 29
; NumSGPRsForWavesPerEU: 42
; NumVGPRsForWavesPerEU: 240
; AccumOffset: 240
; Occupancy: 2
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 2
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 1
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX90A:ACCUM_OFFSET: 59
; COMPUTE_PGM_RSRC3_GFX90A:TG_SPLIT: 0
	.text
	.p2alignl 6, 3212836864
	.fill 256, 4, 3212836864
	.section	.AMDGPU.gpr_maximums,"",@progbits
	.set amdgpu.max_num_vgpr, 0
	.set amdgpu.max_num_agpr, 0
	.set amdgpu.max_num_sgpr, 0
	.text
	.type	__hip_cuid_190d38dbe30f21b9,@object ; @__hip_cuid_190d38dbe30f21b9
	.section	.bss,"aw",@nobits
	.globl	__hip_cuid_190d38dbe30f21b9
__hip_cuid_190d38dbe30f21b9:
	.byte	0                               ; 0x0
	.size	__hip_cuid_190d38dbe30f21b9, 1

	.ident	"AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.4 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __hip_cuid_190d38dbe30f21b9
	.amdgpu_metadata
---
amdhsa.kernels:
  - .agpr_count:     0
    .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         24
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         32
        .size:           8
        .value_kind:     global_buffer
      - .offset:         40
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 32768
    .kernarg_segment_align: 8
    .kernarg_segment_size: 44
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 1024
    .name:           _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
    .private_segment_fixed_size: 0
    .sgpr_count:     42
    .sgpr_spill_count: 0
    .symbol:         _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     240
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx942
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
