import argparse
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET


parser = argparse.ArgumentParser()
parser.add_argument("--output", required=True, type=Path)
args = parser.parse_args()
root = Path("/tmp/gfx942_perf")
repository = Path("/mywork/pyhip")
source = repository / "src/contrib/gemm_fp8_gfx942.py"
tests = repository / "tests/contrib/gemm/test_a8w8_f32_blockscale.py"
comparison = json.loads((root / "final_v32_pair.json").read_text())
assert len(comparison["results"]) == 1
timing = comparison["results"][0]
assert timing["shape"] == [4096, 4096, 16384] and timing["preshuffle_b"]
assert all(value["samples"] == 64 and value["diff"] <= 1e-5 for value in timing["summary"].values())
assert len(timing["input_pointers"]) == 32
assert all(gate["ptl"] and set(gate["formats"]) == {"VECTOR", "F8"} and len(gate["pids"]) <= 1 for gate in comparison["gates"])
baseline_time = timing["summary"]["baseline"]["median_us"]
candidate_time = timing["summary"]["v32"]["median_us"]
traces = {}
physical_sets = []
for name in ("v25_4096", "v32_4096", "v25_8192"):
    report = json.loads((root / f"{name}_wide_stalls.json").read_text())
    run = json.loads((root / f"{name}_wide_att_run.json").read_text())
    log = (root / f"{name}_wide_att.log").read_text()
    assert "Data Lost" not in log and "Wave incomplete" not in log
    assert report["trace"]["complete_wave_files"] == report["trace"]["wave_files"]
    assert report["trace"]["physical_simds"] == 14
    assert all(gate["ptl"] and set(gate["formats"]) == {"VECTOR", "F8"} and len(gate["pids"]) <= 1 for gate in run["gates"])
    assert run["checks"]["timed_0_baseline"]["calc_diff"] <= 1e-5
    physical = set()
    for path in Path(report["dispatch"]).glob("se*_sm*_sl*_wv*.json"):
        payload = json.loads(path.read_text())
        assert payload["num_insts"] == payload["num_stitched"]
        wave = payload["wave"]
        shader_engine = int(re.match(r"se(\d+)_", path.name).group(1))
        physical.add((shader_engine, int(wave["cu"]), int(wave["simd"])))
    physical_sets.append(physical)
    steady = report["steady"]
    traces[name] = {
        "mfma_efficiency_pct": 100 * steady["mfma_busy_fraction"],
        "total_active_mainloop_cycles": steady["total_cycles"],
        "mfma_busy_cycles": steady["mfma_busy_cycles"],
        "idle_categories_pct": {category: 100 * data["cycles"] / steady["total_cycles"] for category, data in steady["categories"].items()},
        "physical_simds": sorted(physical),
        "complete_waves": report["trace"]["complete_wave_files"],
        "code_object": run["code_objects"]["baseline"],
        "analysis": f"{name}_wide_stalls.json",
        "run": f"{name}_wide_att_run.json",
    }
assert physical_sets[0] == physical_sets[1] == physical_sets[2]
assert traces["v32_4096"]["mfma_efficiency_pct"] >= traces["v25_8192"]["mfma_efficiency_pct"]
assert (root / "v32_profiled.text").read_bytes() == (root / "v32_final.text").read_bytes()
unchanged = json.loads((root / "final_v32_unchanged_paths.json").read_text())
assert len(unchanged) == 5 and all(record["identical"] for record in unchanged)
suites = ET.parse(root / "final_v32_correctness.xml").getroot().findall(".//testsuite")
assert sum(int(suite.get("tests", "0")) for suite in suites) == 24
assert all(int(suite.get("failures", "0")) == 0 and int(suite.get("errors", "0")) == 0 for suite in suites)
descriptions = {
    26: "Current B LDS reads before waiting for next B VMEM; full DS retirement before publication",
    27: "Four B staging banks, prefetch q+5 instead of q+3; baseline LDS order",
    28: "Task groups 8 to 2; baseline mainloop",
    29: "Task groups 8 to 1; baseline mainloop",
    30: "v29 plus row group 8 to 16",
    31: "Two N128 phases selected by (blockIdx.x//4)&1",
    32: "Four N64 XOR phases selected by (blockIdx.x//4)&3",
    33: "v32 plus task groups 8 to 1",
    34: "Four N64 phases selected by blockIdx.x&3",
}
experiments = []
for version, description in descriptions.items():
    report = json.loads((root / f"v{version}_4096.json").read_text())
    result = report["results"][0]
    experiments.append({
        "version": f"v{version}", "change": description,
        "median_us": result["median_us"], "median_tflops": result["median_tflops"],
        "calc_diff": result["diff"], "source_sha256": report["kernel_sha256"],
        "artifacts": report["artifacts"],
        "comparison_scope": "Screening in separate allocations/runs; see final_v32_pair.json for same-address acceptance",
    })
adjacent_log = (root / "final_v32_adjacent.log").read_text()
assert "AssertionError" in adjacent_log and '"stage": "entry"' in adjacent_log
summary = {
    "date": "2026-10-31",
    "version": "v32",
    "source": str(source), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "test_source_sha256": hashlib.sha256(tests.read_bytes()).hexdigest(),
    "change": "For preshuffled N4096, remap logical N64 packet p to p XOR ((blockIdx.x//4)&3); remap B-scale and output consistently",
    "preserved": ["256x256 tile", "8 waves", "M split=1", "K128 scale/FMA order", "v25 MFMA/DQ/wait/barrier pipeline", "240 VGPR", "32 KiB LDS", "zero scratch"],
    "timing": timing["summary"],
    "latency_reduction_pct": 100 * (1 - candidate_time / baseline_time),
    "throughput_improvement_pct": 100 * (baseline_time / candidate_time - 1),
    "timing_protocol": comparison["protocol"],
    "att_scope": "Same 14 physical SE/CU/SIMD locations; all complete waves; both resident waves inside K2..125; no CU-idle denominator",
    "att_condition": "PTL Enabled/VECTOR,F8; 16-SE mask, one SIMD/CU, 1GiB trace buffer; target kernel iteration 33 after 32 disjoint cold inputs",
    "att": traces,
    "validation": {"pipeline_tests": 24, "additional_untouched_path_guard_graph_controls": 5, "unchanged_device_text": unchanged, "profiled_final_text_sha256": hashlib.sha256((root / "v32_final.text").read_bytes()).hexdigest()},
    "mechanism_supported": "Cross-WG B request ordering exposes VMEM stalls and propagates to publication barriers; address-only phase permutation reduces both without changing the mainloop instructions",
    "mechanism_not_proven": "Exact TCC bank, fabric partition or hardware queue causing the contention; PMC at Disabled PTL cannot prove this for Enabled ATT",
    "experiments": experiments,
    "limitations": [
        "ATT is sampled physical SIMD activity, not full-device utilization or ordinary benchmark latency",
        "One target dispatch per ATT configuration; do not claim statistical equivalence from the 0.19 percentage-point margin",
        "The 8192 all-16-SE/all-4-SIMD trace lost data and is excluded; its log remains archived",
        "Adjacent M3840/M5120 performance validation stopped at entry because six other GPU processes appeared; not rerun and not claimed passed",
        "Other runtime M/K values in the N4096 branch have correctness coverage but no general performance guarantee",
    ],
}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(summary, indent=2) + "\n")
print("PASS: matched physical locations, complete traces, cold timing, tests and code identity")
print("EFFICIENCY", {name: round(data["mfma_efficiency_pct"], 4) for name, data in traces.items()})
print("LATENCY_REDUCTION_PCT", summary["latency_reduction_pct"])