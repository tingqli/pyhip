import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import statistics


def merged(intervals):
    output = []
    for begin, end in sorted(intervals):
        if output and begin <= output[-1][1]:
            output[-1][1] = max(output[-1][1], end)
        else:
            output.append([begin, end])
    return output


def clipped_cycles(intervals, begin, end):
    return sum(max(0, min(stop, end) - max(start, begin)) for start, stop in intervals)


def analyze(trace):
    code = {int(row[2]): str(row[0]).split(';', 1)[0].strip() for row in json.loads((trace / 'code.json').read_text())['code']}
    groups = defaultdict(lambda: defaultdict(list))
    for path in sorted(trace.glob('se0_sm*_sl*_wv*.json')):
        payload = json.loads(path.read_text())
        assert payload['num_insts'] == payload['num_stitched'], path
        wave = payload['wave']
        if int(wave['cu']) != 0:
            continue
        records = [(int(raw[0]), int(raw[0]) + int(raw[2]), int(raw[3]), int(raw[2]), code[int(raw[4])]) for raw in wave['instructions']]
        mfma = [record[1] for record in records if record[4].startswith('v_mfma')]
        assert len(mfma) == 128 * 128, (path, len(mfma))
        groups[int(wave['simd'])][int(wave['slot'])].append({'file': path.name, 'begin': int(wave['begin']), 'end': int(wave['end']), 'records': records, 'mfma': mfma})
    batches = []
    bands = [(2, 126), (2, 32), (32, 64), (64, 96), (96, 126)]
    for simd, slots in sorted(groups.items()):
        assert len(slots) == 2
        streams = [sorted(waves, key=lambda wave: wave['begin']) for waves in slots.values()]
        assert len(streams[0]) == len(streams[1])
        for batch_index, waves in enumerate(zip(*streams)):
            intervals = merged([(issue, issue + 16) for wave in waves for issue in wave['mfma']])
            band_results = {}
            for first, last in bands:
                begin = max(wave['mfma'][first * 128] for wave in waves)
                end = min(wave['mfma'][last * 128] for wave in waves)
                assert begin < end
                busy = clipped_cycles(intervals, begin, end)
                stalls = defaultdict(list)
                inside_gaps = []
                for wave in waves:
                    for attempt, issue, duration, stall, instruction in wave['records']:
                        if begin <= attempt < end:
                            opcode = instruction.split()[0]
                            if opcode.startswith(('buffer_load', 's_waitcnt', 's_barrier', 'ds_read', 'ds_write', 's_load')):
                                stalls[instruction].append(stall)
                    for ordinal in range(first * 128 + 1, last * 128):
                        if ordinal % 32 not in (0, 31):
                            inside_gaps.append(wave['mfma'][ordinal] - wave['mfma'][ordinal - 1])
                worst = sorted(stalls.items(), key=lambda pair: -sum(pair[1]))[:10]
                band_results[f'{first}:{last}'] = {
                    'begin': begin, 'end': end, 'cycles': end - begin, 'mfma_busy_cycles': busy, 'mfma_efficiency': busy / (end - begin),
                    'inside_compute_mfma_gap_median': statistics.median(inside_gaps),
                    'inside_compute_mfma_gap_counts': dict(Counter(inside_gaps)),
                    'largest_raw_stalls': [{'instruction': instruction, 'count': len(values), 'sum': sum(values), 'mean': statistics.mean(values), 'maximum': max(values)} for instruction, values in worst],
                }
            batches.append({'simd': simd, 'batch': batch_index, 'files': [wave['file'] for wave in waves], 'begin': min(wave['begin'] for wave in waves), 'end': max(wave['end'] for wave in waves), 'bands': band_results})
    by_batch = {}
    for batch_index in sorted({batch['batch'] for batch in batches}):
        selected = [batch for batch in batches if batch['batch'] == batch_index]
        by_batch[str(batch_index)] = {}
        for first, last in bands:
            key = f'{first}:{last}'
            cycles = sum(batch['bands'][key]['cycles'] for batch in selected)
            busy = sum(batch['bands'][key]['mfma_busy_cycles'] for batch in selected)
            by_batch[str(batch_index)][key] = {'mfma_efficiency': busy / cycles, 'cycles_per_simd': cycles / len(selected)}
    total = sum(batch['bands']['2:126']['cycles'] for batch in batches)
    busy = sum(batch['bands']['2:126']['mfma_busy_cycles'] for batch in batches)
    return {'trace': str(trace), 'scope': 'SE0/CU0, all four SIMD, both resident waves in the same K band; no CU-idle periods in denominator',
            'raw_stall_warning': 'Raw stalls are per-wave diagnostics; do not sum them into wall-time loss.',
            'mfma_efficiency': busy / total, 'by_batch': by_batch, 'batches': batches}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--small', required=True, type=Path)
    parser.add_argument('--large', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    report = {'4096': analyze(args.small), '8192': analyze(args.large)}
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    for shape, result in report.items():
        print('SHAPE', shape, 'MAINLOOP', round(result['mfma_efficiency'] * 100, 3))
        for batch, bands in result['by_batch'].items():
            print('BATCH', batch, {key: round(value['mfma_efficiency'] * 100, 2) for key, value in bands.items()})


if __name__ == '__main__':
    main()