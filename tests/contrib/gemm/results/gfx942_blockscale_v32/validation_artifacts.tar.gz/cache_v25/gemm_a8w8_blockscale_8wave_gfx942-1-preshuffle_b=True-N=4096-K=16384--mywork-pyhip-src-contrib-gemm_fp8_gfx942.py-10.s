	.amdgcn_target "amdgcn-amd-amdhsa--gfx942"
	.amdhsa_code_object_version 6
	.text
	.protected	_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i ; -- Begin function _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
	.globl	_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
	.p2align	8
	.type	_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i,@function
_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i: ; @_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
; %bb.0:
	;;#ASMSTART
	 ; blockIdx.x s2, blockIdx.y s3, blockIdx.z s4
	;;#ASMEND
	;;#ASMSTART
	
_jit_main:	 ;BB#43 predecessors:[] successors:[_bb_no_name_44,_if_else_28_0]
	s_load_dwordx2 s[6:7],s[0:1],0x0  ; # asmjit.py:4434 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'pA's[6:7]    s:7(7) v:1(0) a:0(0)    sid:0 pA,kargs,0,;	s[6:7] = load_dwordx2_from(s[0:1] + 0x0, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_load_dwordx2 s[8:9],s[0:1],0x8  ; # asmjit.py:4434 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'pB's[8:9]    s:9(9) v:1(0) a:0(0)    sid:1 pB,kargs,8,;	s[8:9] = load_dwordx2_from(s[0:1] + 0x8, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_load_dwordx2 s[10:11],s[0:1],0x10  ; # asmjit.py:4434 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'pC's[10:11]    s:11(11) v:1(0) a:0(0)    sid:2 pC,kargs,16,;	s[10:11] = load_dwordx2_from(s[0:1] + 0x10, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_load_dwordx2 s[12:13],s[0:1],0x18  ; # asmjit.py:4434 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'pScaleA's[12:13]    s:13(13) v:1(0) a:0(0)    sid:3 pScaleA,kargs,24,;	s[12:13] = load_dwordx2_from(s[0:1] + 0x18, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_load_dwordx2 s[14:15],s[0:1],0x20  ; # asmjit.py:4434 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'pScaleB's[14:15]    s:15(15) v:1(0) a:0(0)    sid:4 pScaleB,kargs,32,;	s[14:15] = load_dwordx2_from(s[0:1] + 0x20, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_load_dword s5,s[0:1],0x28  ; # asmjit.py:4443 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'M's5    s:16(15) v:1(0) a:0(0)    sid:5 M,kargs,40,;	s5 = load_dword_from(s[0:1] + 0x28, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	v_lshrrev_b32 v1,0x6,v0  ; # asmjit.py:4273 asmjit.py:4461 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc 'idst'v1    s:16(15) v:2(1) a:0(0)    sid:6 idst,6,threadIdx.x,;	v1.b32 = v0 >> 0x6[4:0];
	s_nop 0x1  ; #   sid:7 1,                        ;	s_nop  wait 2 cycles
	v_readfirstlane_b32 s16,v1  ; # asmjit.py:4273 asmjit.py:4461 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 free 'idst'v1 alloc '_warp_id's16    s:17(16) v:1(0) a:0(0)    sid:8 _warp_id,idst,
	v_and_b32 v1,0x3f,v0  ; # asmjit.py:4280 asmjit.py:4462 asmjit.py:4501 test_a8w8_f32_blockscale.py:228 alloc '_lane_id'v1    s:17(16) v:2(1) a:0(0)    sid:9 _lane_id,63,threadIdx.x,;	v1.u32 = (0x3f & v0.u32)
	s_waitcnt  lgkmcnt(0) ; # asmjit.py:4465 asmjit.py:4501 test_a8w8_f32_blockscale.py:228   sid:10 
	s_add_i32 s17,0x100,s5  ; # loaders.py:19 alloc 'src0_gprs's17    s:18(17) v:2(1) a:0(0)    sid:11 src0_gprs,256,M,;	s17.i32 = 0x100 + s5; scc=overflow_or_carry
	s_sub_i32 s17,s17,0x1  ; # loaders.py:19 free 'src0_gprs's17 alloc 'src0_gprs's17    s:18(17) v:2(1) a:0(0)    sid:12 src0_gprs,src0_gprs,1,;	s17.i32 = (s17.i32 - 0x1.i32); scc=(overflow or carry-out of last arith);
	s_ashr_i32 s17,s17,0x8  ; # loaders.py:19 free 'src0_gprs's17 alloc 'M0's17    s:18(17) v:2(1) a:0(0)    sid:13 M0,src0_gprs,8,
	s_lshl_b32 s18,s17,0x4  ; # loaders.py:22 alloc 'src1_gprs's18    s:19(18) v:2(1) a:0(0)    sid:14 src1_gprs,M0,4,;	s18 = s17 << 0x4[4:0]; scc=(s18!=0);
	s_add_i32 s18,0x8,s18  ; # loaders.py:22 free 'src1_gprs's18 alloc 'src0_gprs's18    s:19(18) v:2(1) a:0(0)    sid:15 src0_gprs,8,src1_gprs,;	s18.i32 = 0x8 + s18; scc=overflow_or_carry
	s_sub_i32 s18,s18,0x1  ; # loaders.py:22 free 'src0_gprs's18 alloc 'src0_gprs's18    s:19(18) v:2(1) a:0(0)    sid:16 src0_gprs,src0_gprs,1,;	s18.i32 = (s18.i32 - 0x1.i32); scc=(overflow or carry-out of last arith);
	s_ashr_i32 s18,s18,0x3  ; # loaders.py:22 free 'src0_gprs's18 alloc 'src0_gprs's18    s:19(18) v:2(1) a:0(0)    sid:17 src0_gprs,src0_gprs,3,
	s_lshl_b32 s18,s18,0x3  ; # loaders.py:22 free 'src0_gprs's18 alloc 'src0_gprs's18    s:19(18) v:2(1) a:0(0)    sid:18 src0_gprs,src0_gprs,3,;	s18 = s18 << 0x3[4:0]; scc=(s18!=0);
	s_lshl_b32 s19,s17,0x4  ; # loaders.py:22 alloc 'src1_gprs's19    s:20(19) v:2(1) a:0(0)    sid:19 src1_gprs,M0,4,;	s19 = s17 << 0x4[4:0]; scc=(s19!=0);
	s_sub_i32 s18,s18,s19  ; # loaders.py:22 free 'src0_gprs's18 free 'src1_gprs's19 alloc 'src1_gprs's18    s:19(18) v:2(1) a:0(0)    sid:20 src1_gprs,src0_gprs,src1_gprs,;	s18.i32 = (s18.i32 - s19.i32); scc=(overflow or carry-out of last arith);
	s_sub_i32 s18,0x8,s18  ; # loaders.py:22 free 'src1_gprs's18 alloc 'big_group_num's18    s:19(18) v:2(1) a:0(0)    sid:21 big_group_num,8,src1_gprs,;	s18.i32 = (0x8.i32 - s18.i32); scc=(overflow or carry-out of last arith);
	s_lshr_b32 s19,s2,0x3  ; # loaders.py:23 alloc 'group_id_y's19    s:20(19) v:2(1) a:0(0)    sid:22 group_id_y,blockIdx.x,3,
	s_lshl_b32 s20,s19,0x3  ; # loaders.py:24 alloc 'src1_gprs's20    s:21(20) v:2(1) a:0(0)    sid:23 src1_gprs,group_id_y,3,;	s20 = s19 << 0x3[4:0]; scc=(s20!=0);
	s_sub_u32 s20,s2,s20  ; # loaders.py:24 free 'src1_gprs's20 alloc 'group_id_x's20    s:21(20) v:2(1) a:0(0)    sid:24 group_id_x,blockIdx.x,src1_gprs,;	s20.u32 = (s2.u32 - s20.u32); scc=(overflow or carry-out of last arith);
	s_lshl_b32 s21,s17,0x4  ; # loaders.py:26 alloc 'src1_gprs's21    s:22(21) v:2(1) a:0(0)    sid:25 src1_gprs,M0,4,;	s21 = s17 << 0x4[4:0]; scc=(s21!=0);
	s_add_u32 s21,0x8,s21  ; # loaders.py:26 free 'src1_gprs's21 alloc 'src0_gprs's21    s:22(21) v:2(1) a:0(0)    sid:26 src0_gprs,8,src1_gprs,;	s21.u32 = 0x8 + s21; scc=overflow_or_carry
	s_sub_u32 s21,s21,0x1  ; # loaders.py:26 free 'src0_gprs's21 alloc 'src0_gprs's21    s:22(21) v:2(1) a:0(0)    sid:27 src0_gprs,src0_gprs,1,;	s21.u32 = (s21.u32 - 0x1.u32); scc=(overflow or carry-out of last arith);
	s_lshr_b32 s21,s21,0x3  ; # loaders.py:26 free 'src0_gprs's21 alloc 'src1_gprs's21    s:22(21) v:2(1) a:0(0)    sid:28 src1_gprs,src0_gprs,3,
	s_mul_i32 s21,s20,s21  ; # loaders.py:26 free 'src1_gprs's21 alloc 'src0_gprs's21    s:22(21) v:2(1) a:0(0)    sid:29 src0_gprs,group_id_x,src1_gprs,;	s21 = s20 * s21
	s_add_u32 s19,s21,s19  ; # loaders.py:26 free 'group_id_y's19 free 'src0_gprs's21 alloc 'remap_block_1d_id's19    s:21(20) v:2(1) a:0(0)    sid:30 remap_block_1d_id,src0_gprs,group_id_y,;	s19.u32 = s21 + s19; scc=overflow_or_carry
	s_cmp_gt_u32 s20,s18  ; # asmjit.py:1421 contextlib.py:137   sid:31 group_id_x,big_group_num,;	scc = (s20.u32 > s18.u32)
	s_cbranch_scc0  _if_else_28_0 ; # asmjit.py:1367 asmjit.py:1421 contextlib.py:137   sid:32;	jump if scc is 0 (scc == 0)
_bb_no_name_44:	 ;BB#44 predecessors:[_jit_main] successors:[_if_else_28_0]
	s_sub_u32 s18,s18,s20  ; # loaders.py:29 free 'big_group_num's18 free 'group_id_x's20 alloc 'src1_gprs's18    s:20(19) v:2(1) a:0(0)    sid:33 src1_gprs,big_group_num,group_id_x,;	s18.u32 = (s18.u32 - s20.u32); scc=(overflow or carry-out of last arith);
	s_add_u32 s19,s19,s18  ; # loaders.py:29 free 'src1_gprs's18   sid:34 remap_block_1d_id,remap_block_1d_id,src1_gprs,;	s19.u32 = s19 + s18; scc=overflow_or_carry
_if_else_28_0:	 ;BB#45 predecessors:[_bb_no_name_44,_jit_main] successors:[_bb_no_name_46,_if_else_213_1]
	s_lshr_b32 s18,s19,0x4  ; # loaders.py:31 alloc 'idx_M0's18    s:20(19) v:2(1) a:0(0)    sid:35 idx_M0,remap_block_1d_id,4,
	s_lshl_b32 s20,s18,0x4  ; # loaders.py:32 alloc 'src1_gprs's20    s:21(20) v:2(1) a:0(0)    sid:36 src1_gprs,idx_M0,4,;	s20 = s18 << 0x4[4:0]; scc=(s20!=0);
	s_sub_u32 s19,s19,s20  ; # loaders.py:32 free 'remap_block_1d_id's19 free 'src1_gprs's20 alloc 'idx_N0's19    s:20(19) v:2(1) a:0(0)    sid:37 idx_N0,remap_block_1d_id,src1_gprs,;	s19.u32 = (s19.u32 - s20.u32); scc=(overflow or carry-out of last arith);
	s_ashr_i32 s20,s17,0x3  ; # loaders.py:34 alloc 'M0_tmp's20    s:21(20) v:2(1) a:0(0)    sid:38 M0_tmp,M0,3,
	s_lshl_b32 s20,s20,0x3  ; # loaders.py:35 free 'M0_tmp's20 alloc 'src1_gprs's20    s:21(20) v:2(1) a:0(0)    sid:39 src1_gprs,M0_tmp,3,;	s20 = s20 << 0x3[4:0]; scc=(s20!=0);
	s_sub_i32 s20,s17,s20  ; # loaders.py:35 free 'src1_gprs's20 alloc 'M0_mod_M01's20    s:21(20) v:2(1) a:0(0)    sid:40 M0_mod_M01,M0,src1_gprs,;	s20.i32 = (s17.i32 - s20.i32); scc=(overflow or carry-out of last arith);
	s_sub_u32 s17,s17,s20  ; # loaders.py:39 free 'M0's17 alloc 'src1_gprs's17    s:21(20) v:2(1) a:0(0)    sid:41 src1_gprs,M0,M0_mod_M01,;	s17.u32 = (s17.u32 - s20.u32); scc=(overflow or carry-out of last arith);
	s_cmp_lt_u32 s18,s17  ; # loaders.py:39 free 'src1_gprs's17   sid:42 idx_M0,src1_gprs,;	scc = (s18.u32 < s17.u32)
	s_cselect_b32 s17,0x8,s20  ; # loaders.py:40 free 'M0_mod_M01's20 alloc 'M01_adapt's17    s:20(19) v:2(1) a:0(0)    sid:43 M01_adapt,8,M0_mod_M01,;	s17 = scc ? 0x8 : s20
	s_lshr_b32 s20,s18,0x3  ; # loaders.py:42 alloc 'idx_M00's20    s:21(20) v:2(1) a:0(0)    sid:44 idx_M00,idx_M0,3,
	s_lshl_b32 s21,s20,0x3  ; # loaders.py:43 alloc 'src1_gprs's21    s:22(21) v:2(1) a:0(0)    sid:45 src1_gprs,idx_M00,3,;	s21 = s20 << 0x3[4:0]; scc=(s21!=0);
	s_sub_u32 s18,s18,s21  ; # loaders.py:43 free 'idx_M0's18 free 'src1_gprs's21 alloc 'idx_M01's18    s:21(20) v:2(1) a:0(0)    sid:46 idx_M01,idx_M0,src1_gprs,;	s18.u32 = (s18.u32 - s21.u32); scc=(overflow or carry-out of last arith);
	s_lshl_b32 s18,s18,0x4  ; # loaders.py:44 free 'idx_M01's18 alloc 'src1_gprs's18    s:21(20) v:2(1) a:0(0)    sid:47 src1_gprs,idx_M01,4,;	s18 = s18 << 0x4[4:0]; scc=(s18!=0);
	s_add_u32 s18,s19,s18  ; # loaders.py:44 free 'idx_N0's19 free 'src1_gprs's18 alloc 'idx_N0_M01_local's18    s:20(20) v:2(1) a:0(0)    sid:48 idx_N0_M01_local,idx_N0,src1_gprs,;	s18.u32 = s19 + s18; scc=overflow_or_carry
	s_abs_i32 s19,s17  ; # asmjit.py:2552 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 's4's19    s:21(20) v:2(1) a:0(0)    sid:49 s4,M01_adapt,
	v_cvt_f32_u32_e32 v2,s19  ; # asmjit.py:2553 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 'v1'v2    s:21(20) v:3(2) a:0(0)    sid:50 v1,s4,
	s_sub_i32 s21,0x0,s19  ; # asmjit.py:2554 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 's5's21    s:22(21) v:3(2) a:0(0)    sid:51 s5,0,s4,;	s21.i32 = (0x0.i32 - s19.i32); scc=(overflow or carry-out of last arith);
	s_xor_b32 s22,s18,s17  ; # asmjit.py:2555 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 's3's22    s:23(22) v:3(2) a:0(0)    sid:52 s3,idx_N0_M01_local,M01_adapt,;	s22 = s18 ^ s17;  scc=(s22!=0);
	s_abs_i32 s23,s18  ; # asmjit.py:2556 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 'N_out's23    s:24(23) v:3(2) a:0(0)    sid:53 N_out,idx_N0_M01_local,
	v_rcp_iflag_f32_e32 v2,v2  ; # asmjit.py:2557 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:54 v1,v1,
	s_ashr_i32 s22,s22,0x1f  ; # asmjit.py:2558 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:55 s3,s3,31,
	v_mul_f32_e32 v2,0x4f7ffffe,v2  ; # asmjit.py:2559 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:56 v1,1333788670,v1,
	v_cvt_u32_f32_e32 v2,v2  ; # asmjit.py:2560 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:57 v1,v1,
	s_nop  0 ; # asmjit.py:2561 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:58;	s_nop  wait 1 cycles
	v_readfirstlane_b32 s24,v2  ; # asmjit.py:2562 asmjit.py:1552 asmjit.py:1582 loaders.py:46 free 'v1'v2 alloc 's6's24    s:25(24) v:2(1) a:0(0)    sid:59 s6,v1,
	s_mul_i32 s21,s21,s24  ; # asmjit.py:2563 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:60 s5,s5,s6,;	s21 = s21 * s24
	s_mul_hi_u32 s21,s24,s21  ; # asmjit.py:2564 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:61 s5,s6,s5,;	s21 = s24 * s21
	s_add_i32 s24,s24,s21  ; # asmjit.py:2565 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:62 s6,s6,s5,;	s24.i32 = s24 + s21; scc=overflow_or_carry
	s_mul_hi_u32 s21,s23,s24  ; # asmjit.py:2566 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:63 s5,N_out,s6,;	s21 = s23 * s24
	s_mul_i32 s24,s21,s19  ; # asmjit.py:2567 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:64 s6,s5,s4,;	s24 = s21 * s19
	s_sub_i32 s23,s23,s24  ; # asmjit.py:2568 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:65 N_out,N_out,s6,;	s23.i32 = (s23.i32 - s24.i32); scc=(overflow or carry-out of last arith);
	s_add_i32 s25,s21,0x1  ; # asmjit.py:2569 asmjit.py:1552 asmjit.py:1582 loaders.py:46 alloc 's7's25    s:26(25) v:2(1) a:0(0)    sid:66 s7,s5,1,;	s25.i32 = s21 + 0x1; scc=overflow_or_carry
	s_sub_i32 s24,s23,s19  ; # asmjit.py:2570 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:67 s6,N_out,s4,;	s24.i32 = (s23.i32 - s19.i32); scc=(overflow or carry-out of last arith);
	s_cmp_ge_u32 s23,s19  ; # asmjit.py:2571 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:68 N_out,s4,;	scc = (s23.u32 >= s19.u32)
	s_cselect_b32 s21,s25,s21  ; # asmjit.py:2572 asmjit.py:1552 asmjit.py:1582 loaders.py:46 free 's7's25   sid:69 s5,s7,s5,;	s21 = scc ? s25 : s21
	s_cselect_b32 s23,s24,s23  ; # asmjit.py:2573 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:70 N_out,s6,N_out,;	s23 = scc ? s24 : s23
	s_add_i32 s24,s21,0x1  ; # asmjit.py:2574 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:71 s6,s5,1,;	s24.i32 = s21 + 0x1; scc=overflow_or_carry
	s_cmp_ge_u32 s23,s19  ; # asmjit.py:2575 asmjit.py:1552 asmjit.py:1582 loaders.py:46 free 's4's19   sid:72 N_out,s4,;	scc = (s23.u32 >= s19.u32)
	s_cselect_b32 s23,s24,s21  ; # asmjit.py:2576 asmjit.py:1552 asmjit.py:1582 loaders.py:46 free 's5's21 free 's6's24   sid:73 N_out,s6,s5,;	s23 = scc ? s24 : s21
	s_xor_b32 s23,s23,s22  ; # asmjit.py:2577 asmjit.py:1552 asmjit.py:1582 loaders.py:46   sid:74 N_out,N_out,s3,;	s23 = s23 ^ s22;  scc=(s23!=0);
	s_sub_i32 s23,s23,s22  ; # asmjit.py:2578 asmjit.py:1552 asmjit.py:1582 loaders.py:46 free 's3's22   sid:75 N_out,N_out,s3,;	s23.i32 = (s23.i32 - s22.i32); scc=(overflow or carry-out of last arith);
	s_mul_i32 s17,s23,s17  ; # loaders.py:47 free 'M01_adapt's17 alloc 'src1_gprs's17    s:21(23) v:2(1) a:0(0)    sid:76 src1_gprs,N_out,M01_adapt,;	s17 = s23 * s17
	s_sub_u32 s17,s18,s17  ; # loaders.py:47 free 'idx_N0_M01_local's18 free 'src1_gprs's17 alloc 'idx_loc_mod_M01's17    s:20(23) v:2(1) a:0(0)    sid:77 idx_loc_mod_M01,idx_N0_M01_local,src1_gprs,;	s17.u32 = (s18.u32 - s17.u32); scc=(overflow or carry-out of last arith);
	s_lshl_b32 s18,s20,0x3  ; # loaders.py:49 free 'idx_M00's20 alloc 'src1_gprs's18    s:20(23) v:2(1) a:0(0)    sid:78 src1_gprs,idx_M00,3,;	s18 = s20 << 0x3[4:0]; scc=(s18!=0);
	s_add_u32 s17,s17,s18  ; # loaders.py:49 free 'idx_loc_mod_M01's17 free 'src1_gprs's18 alloc 'M_out's17    s:19(23) v:2(1) a:0(0)    sid:79 M_out,idx_loc_mod_M01,src1_gprs,;	s17.u32 = s17 + s18; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x8  ; # asmjit.py:1627 gemm_fp8_gfx942.py:26 free 'M_out's17 alloc 'row_base's17    s:19(23) v:2(1) a:0(0)    sid:80 row_base,M_out,8,;	s17 = s17 << 0x8[4:0]; scc=(s17!=0);
	s_lshl_b32 s18,s23,0x8  ; # asmjit.py:1627 gemm_fp8_gfx942.py:27 free 'N_out's23 alloc 'col_base's18    s:19(18) v:2(1) a:0(0)    sid:81 col_base,N_out,8,;	s18 = s23 << 0x8[4:0]; scc=(s18!=0);
	s_sub_i32 s19,s5,s17  ; # gemm_fp8_gfx942.py:30 alloc 'idst's19    s:20(19) v:2(1) a:0(0)    sid:82 idst,M,row_base,;	s19.i32 = (s5.i32 - s17.i32); scc=(overflow or carry-out of last arith);
	s_min_u32 s19,s19,0x100  ; # gemm_fp8_gfx942.py:30 free 'idst's19 alloc 'rows's19    s:20(19) v:2(1) a:0(0)    sid:83 rows,idst,256,
	s_sub_u32 s20,0x1000,s18  ; # gemm_fp8_gfx942.py:31 alloc 'idst's20    s:21(20) v:2(1) a:0(0)    sid:84 idst,4096,col_base,;	s20.u32 = (0x1000.u32 - s18.u32); scc=(overflow or carry-out of last arith);
	s_min_u32 s20,s20,0x100  ; # gemm_fp8_gfx942.py:31 free 'idst's20 alloc 'cols's20    s:21(20) v:2(1) a:0(0)    sid:85 cols,idst,256,
	s_lshl_b32 s21,s17,0xe  ; # gemm_fp8_gfx942.py:32 alloc 'src1_gprs's21    s:22(21) v:2(1) a:0(0)    sid:86 src1_gprs,row_base,14,;	s21 = s17 << 0xe[4:0]; scc=(s21!=0);
	s_add_u32 s6,s6,s21  ; # gemm_fp8_gfx942.py:32 free 'src1_gprs's21   sid:87 pA,pA,src1_gprs,;	s6.u32 = s6 + s21; scc=overflow_or_carry
	s_addc_u32 s7,s7,0x0  ; # gemm_fp8_gfx942.py:32   sid:88 pA,pA,0,;	s7.u32 = s7 + 0x0 + scc; scc=overflow_or_carry
	s_lshl_b32 s21,s18,0xe  ; # gemm_fp8_gfx942.py:33 alloc 'src1_gprs's21    s:22(21) v:2(1) a:0(0)    sid:89 src1_gprs,col_base,14,;	s21 = s18 << 0xe[4:0]; scc=(s21!=0);
	s_add_u32 s8,s8,s21  ; # gemm_fp8_gfx942.py:33 free 'src1_gprs's21   sid:90 pB,pB,src1_gprs,;	s8.u32 = s8 + s21; scc=overflow_or_carry
	s_addc_u32 s9,s9,0x0  ; # gemm_fp8_gfx942.py:33   sid:91 pB,pB,0,;	s9.u32 = s9 + 0x0 + scc; scc=overflow_or_carry
	s_lshl_b32 s21,s17,0xd  ; # gemm_fp8_gfx942.py:34 alloc 'src1_gprs's21    s:22(21) v:2(1) a:0(0)    sid:92 src1_gprs,row_base,13,;	s21 = s17 << 0xd[4:0]; scc=(s21!=0);
	s_add_u32 s10,s10,s21  ; # gemm_fp8_gfx942.py:34 free 'src1_gprs's21   sid:93 pC,pC,src1_gprs,;	s10.u32 = s10 + s21; scc=overflow_or_carry
	s_addc_u32 s11,s11,0x0  ; # gemm_fp8_gfx942.py:34   sid:94 pC,pC,0,;	s11.u32 = s11 + 0x0 + scc; scc=overflow_or_carry
	s_mov_b32 s21,s16  ; # gemm_fp8_gfx942.py:35 alloc 'wave_m's21    s:22(21) v:2(1) a:0(0)    sid:95 wave_m,_warp_id,;	s21 = s16
	s_lshr_b32 s16,s16,0x2  ; # asmjit.py:1627 gemm_fp8_gfx942.py:36 free '_warp_id's16 alloc 'group's16    s:22(21) v:2(1) a:0(0)    sid:96 group,_warp_id,2,
	v_lshrrev_b32 v2,0x1,s21  ; # gemm_fp8_gfx942.py:42 alloc 'src0_gprs'v2    s:22(21) v:3(2) a:0(0)    sid:97 src0_gprs,1,wave_m,;	v2.b32 = s21 >> 0x1[4:0];
	v_lshlrev_b32 v3,0x12,v2  ; # gemm_fp8_gfx942.py:42 alloc 'src0_gprs'v3    s:22(21) v:4(3) a:0(0)    sid:98 src0_gprs,18,src0_gprs,;	v3.b32 = v2 << 0x12[4:0];
	v_and_b32 v4,0x1,s21  ; # gemm_fp8_gfx942.py:42 alloc 'src0_gprs'v4    s:22(21) v:5(4) a:0(0)    sid:99 src0_gprs,1,wave_m,;	v4.u32 = (0x1 & s21.u32)
	v_lshlrev_b32 v5,0xa,v4  ; # gemm_fp8_gfx942.py:42 alloc 'src1_gprs'v5    s:22(21) v:6(5) a:0(0)    sid:100 src1_gprs,10,src0_gprs,;	v5.b32 = v4 << 0xa[4:0];
	v_add_u32_e32 v3,v3,v5  ; # gemm_fp8_gfx942.py:42 free 'src0_gprs'v3 free 'src1_gprs'v5 alloc 'src0_gprs'v3    s:22(21) v:5(4) a:0(0)    sid:101 src0_gprs,src0_gprs,src1_gprs,;	v3 = v3 + v5
	v_lshlrev_b32 v5,0x4,v1  ; # gemm_fp8_gfx942.py:42 alloc 'src1_gprs'v5    s:22(21) v:6(5) a:0(0)    sid:102 src1_gprs,4,_lane_id,;	v5.b32 = v1 << 0x4[4:0];
	v_add_u32_e32 v3,v3,v5  ; # gemm_fp8_gfx942.py:42 free 'src0_gprs'v3 free 'src1_gprs'v5 alloc 'lane_b'v3    s:22(21) v:5(4) a:0(0)    sid:103 lane_b,src0_gprs,src1_gprs,;	v3 = v3 + v5
	v_lshlrev_b32 v2,0x4,v2  ; # gemm_fp8_gfx942.py:45 free 'src0_gprs'v2 alloc 'src0_gprs'v2    s:22(21) v:5(4) a:0(0)    sid:104 src0_gprs,4,src0_gprs,;	v2.b32 = v2 << 0x4[4:0];
	v_and_b32 v5,0xf,v1  ; # gemm_fp8_gfx942.py:45 alloc 'src1_gprs'v5    s:22(21) v:6(5) a:0(0)    sid:105 src1_gprs,15,_lane_id,;	v5.u32 = (0xf & v1.u32)
	v_add_u32_e32 v2,v2,v5  ; # gemm_fp8_gfx942.py:45 free 'src0_gprs'v2 alloc 'write_row'v2    s:22(21) v:6(5) a:0(0)    sid:106 write_row,src0_gprs,src1_gprs,;	v2 = v2 + v5
	v_lshlrev_b32 v4,0x2,v4  ; # gemm_fp8_gfx942.py:46 free 'src0_gprs'v4 alloc 'src0_gprs'v4    s:22(21) v:6(5) a:0(0)    sid:107 src0_gprs,2,src0_gprs,;	v4.b32 = v4 << 0x2[4:0];
	v_lshrrev_b32 v6,0x4,v1  ; # gemm_fp8_gfx942.py:46 alloc 'src1_gprs'v6    s:22(21) v:7(6) a:0(0)    sid:108 src1_gprs,4,_lane_id,;	v6.b32 = v1 >> 0x4[4:0];
	v_add_u32_e32 v4,v4,v6  ; # gemm_fp8_gfx942.py:46 free 'src0_gprs'v4 alloc 'write_col'v4    s:22(21) v:7(6) a:0(0)    sid:109 write_col,src0_gprs,src1_gprs,;	v4 = v4 + v6
	v_lshlrev_b32 v7,0x7,v2  ; # gemm_fp8_gfx942.py:51 alloc 'src0_gprs'v7    s:22(21) v:8(7) a:0(0)    sid:110 src0_gprs,7,write_row,;	v7.b32 = v2 << 0x7[4:0];
	v_xor_b32 v2,v2,v4  ; # gemm_fp8_gfx942.py:51 free 'write_row'v2 free 'write_col'v4 alloc 'src1_gprs'v2    s:22(21) v:7(7) a:0(0)    sid:111 src1_gprs,write_row,write_col,;	v2.u32 = (v2 ^ v4.u32)
	v_and_b32 v2,0x7,v2  ; # gemm_fp8_gfx942.py:51 free 'src1_gprs'v2 alloc 'src0_gprs'v2    s:22(21) v:7(7) a:0(0)    sid:112 src0_gprs,7,src1_gprs,;	v2.u32 = (0x7 & v2.u32)
	v_lshlrev_b32 v2,0x4,v2  ; # gemm_fp8_gfx942.py:51 free 'src0_gprs'v2 alloc 'src1_gprs'v2    s:22(21) v:7(7) a:0(0)    sid:113 src1_gprs,4,src0_gprs,;	v2.b32 = v2 << 0x4[4:0];
	v_add_u32_e32 v2,v7,v2  ; # gemm_fp8_gfx942.py:51 free 'src0_gprs'v7 free 'src1_gprs'v2 alloc 'write_b'v2    s:22(21) v:6(6) a:0(0)    sid:114 write_b,src0_gprs,src1_gprs,;	v2 = v7 + v2
	v_add_u32_e32 v4,0x0,v3  ; # gemm_fp8_gfx942.py:55 alloc 'load_b[0:0]'v4    s:22(21) v:7(6) a:0(0)    sid:115 load_b[0:0],0,lane_b,;	v4 = 0x0 + v3
	v_add_u32_e32 v7,0x100000,v3  ; # gemm_fp8_gfx942.py:55 alloc 'load_b[1:1]'v7    s:22(21) v:8(7) a:0(0)    sid:116 load_b[1:1],1048576,lane_b,;	v7 = 0x100000 + v3
	v_add_u32_e32 v8,0x200000,v3  ; # gemm_fp8_gfx942.py:55 alloc 'load_b[2:2]'v8    s:22(21) v:9(8) a:0(0)    sid:117 load_b[2:2],2097152,lane_b,;	v8 = 0x200000 + v3
	v_add_u32_e32 v3,0x300000,v3  ; # gemm_fp8_gfx942.py:55 free 'lane_b'v3 alloc 'load_b[3:3]'v3    s:22(21) v:9(8) a:0(0)    sid:118 load_b[3:3],3145728,lane_b,;	v3 = 0x300000 + v3
	s_mov_b32 s27,0x20000  ; # asmjit.py:766 asmjit.py:1328 gemm_fp8_gfx942.py:56 alloc 'self.desc's[24:27]    s:26(27) v:9(8) a:0(0)    sid:119 self.desc,131072,;	s27 = 0x20000
	s_mov_b32 s24,s6  ; # asmjit.py:769 asmjit.py:1329 gemm_fp8_gfx942.py:56   sid:120 self.desc,pA,;	s24 = s6
	s_mov_b32 s25,s7  ; # asmjit.py:770 asmjit.py:1329 gemm_fp8_gfx942.py:56 free 'pA's[6:7]   sid:121 self.desc,pA,;	s25 = s7
	s_lshl_b32 s26,s19,0xe  ; # asmjit.py:771 asmjit.py:1329 gemm_fp8_gfx942.py:56   sid:122 self.desc,rows,14,;	s26 = s19 << 0xe[4:0]; scc=(s26!=0);
	s_mov_b32 s31,0x20000  ; # asmjit.py:766 asmjit.py:1328 gemm_fp8_gfx942.py:57 alloc 'self.desc's[28:31]    s:28(31) v:9(8) a:0(0)    sid:123 self.desc,131072,;	s31 = 0x20000
	s_mov_b32 s28,s8  ; # asmjit.py:769 asmjit.py:1329 gemm_fp8_gfx942.py:57   sid:124 self.desc,pB,;	s28 = s8
	s_mov_b32 s29,s9  ; # asmjit.py:770 asmjit.py:1329 gemm_fp8_gfx942.py:57 free 'pB's[8:9]   sid:125 self.desc,pB,;	s29 = s9
	s_lshl_b32 s30,s20,0xe  ; # asmjit.py:771 asmjit.py:1329 gemm_fp8_gfx942.py:57 free 'cols's20   sid:126 self.desc,cols,14,;	s30 = s20 << 0xe[4:0]; scc=(s30!=0);
	s_mov_b32 s35,0x20000  ; # asmjit.py:766 asmjit.py:1328 gemm_fp8_gfx942.py:58 alloc 'self.desc's[32:35]    s:29(35) v:9(8) a:0(0)    sid:127 self.desc,131072,;	s35 = 0x20000
	s_mov_b32 s32,s10  ; # asmjit.py:769 asmjit.py:1329 gemm_fp8_gfx942.py:58   sid:128 self.desc,pC,;	s32 = s10
	s_mov_b32 s33,s11  ; # asmjit.py:770 asmjit.py:1329 gemm_fp8_gfx942.py:58 free 'pC's[10:11]   sid:129 self.desc,pC,;	s33 = s11
	s_lshl_b32 s34,s19,0xd  ; # asmjit.py:771 asmjit.py:1329 gemm_fp8_gfx942.py:58 free 'rows's19   sid:130 self.desc,rows,13,;	s34 = s19 << 0xd[4:0]; scc=(s34!=0);
	s_mov_b32 s11,0x20000  ; # asmjit.py:766 asmjit.py:1328 gemm_fp8_gfx942.py:59 alloc 'self.desc's[8:11]    s:30(35) v:9(8) a:0(0)    sid:131 self.desc,131072,;	s11 = 0x20000
	s_mov_b32 s8,s12  ; # asmjit.py:769 asmjit.py:1329 gemm_fp8_gfx942.py:59   sid:132 self.desc,pScaleA,;	s8 = s12
	s_mov_b32 s9,s13  ; # asmjit.py:770 asmjit.py:1329 gemm_fp8_gfx942.py:59 free 'pScaleA's[12:13]   sid:133 self.desc,pScaleA,;	s9 = s13
	s_lshl_b32 s10,s5,0x9  ; # asmjit.py:771 asmjit.py:1329 gemm_fp8_gfx942.py:59   sid:134 self.desc,M,9,;	s10 = s5 << 0x9[4:0]; scc=(s10!=0);
	v_lshlrev_b32 v9,0x4,s21  ; # gemm_fp8_gfx942.py:62 free 'wave_m's21 alloc 'src0_gprs'v9    s:27(35) v:10(9) a:0(0)    sid:135 src0_gprs,4,wave_m,;	v9.b32 = s21 << 0x4[4:0];
	v_add_u32_e32 v9,v9,v5  ; # gemm_fp8_gfx942.py:62 free 'src0_gprs'v9 alloc 'local_row'v9    s:27(35) v:10(9) a:0(0)    sid:136 local_row,src0_gprs,src1_gprs,;	v9 = v9 + v5
	s_sub_u32 s6,s5,0x1  ; # asmjit.py:1627 gemm_fp8_gfx942.py:63 alloc 'last_row's6    s:28(35) v:10(9) a:0(0)    sid:137 last_row,M,1,;	s6.u32 = (s5.u32 - 0x1.u32); scc=(overflow or carry-out of last arith);
	v_add_u32_e32 v10,s17,v9  ; # gemm_fp8_gfx942.py:66 free 'row_base's17 alloc 'src1_gprs'v10    s:27(35) v:11(10) a:0(0)    sid:138 src1_gprs,row_base,local_row,;	v10 = s17 + v9
	v_add_u32_e32 v11,0x0,v10  ; # gemm_fp8_gfx942.py:66 alloc 'load_scale_a[0:0]'v11    s:27(35) v:12(11) a:0(0)    sid:139 load_scale_a[0:0],0,src1_gprs,;	v11 = 0x0 + v10
	v_min_u32 v11,s6,v11  ; # gemm_fp8_gfx942.py:68   sid:140 load_scale_a[0:0],last_row,load_scale_a[0:0],
	v_lshlrev_b32 v11,0x2,v11  ; # gemm_fp8_gfx942.py:69   sid:141 load_scale_a[0:0],2,load_scale_a[0:0],;	v11.b32 = v11 << 0x2[4:0];
	v_add_u32_e32 v10,0x80,v10  ; # gemm_fp8_gfx942.py:66 free 'src1_gprs'v10 alloc 'load_scale_a[1:1]'v10    s:27(35) v:12(11) a:0(0)    sid:142 load_scale_a[1:1],128,src1_gprs,;	v10 = 0x80 + v10
	v_min_u32 v10,s6,v10  ; # gemm_fp8_gfx942.py:68 free 'last_row's6   sid:143 load_scale_a[1:1],last_row,load_scale_a[1:1],
	v_lshlrev_b32 v10,0x2,v10  ; # gemm_fp8_gfx942.py:69   sid:144 load_scale_a[1:1],2,load_scale_a[1:1],;	v10.b32 = v10 << 0x2[4:0];
	s_lshr_b32 s6,s18,0x7  ; # gemm_fp8_gfx942.py:72 alloc 'src0_gprs's6    s:27(35) v:12(11) a:0(0)    sid:145 src0_gprs,col_base,7,
	s_lshl_b32 s6,s6,0x9  ; # gemm_fp8_gfx942.py:72 free 'src0_gprs's6 alloc 'scale_offset_b's[6:7]    s:28(35) v:12(11) a:0(0)    sid:146 scale_offset_b,src0_gprs,9,;	s6 = s6 << 0x9[4:0]; scc=(s6!=0);
	s_add_u32 s7,0x200,s6  ; # gemm_fp8_gfx942.py:73   sid:147 scale_offset_b,512,scale_offset_b,;	s7.u32 = 0x200 + s6; scc=overflow_or_carry
	s_min_u32 s7,s7,0x3e00  ; # gemm_fp8_gfx942.py:75   sid:148 scale_offset_b,scale_offset_b,15872,
	v_add_u32_e32 v12,0x0,v9  ; # gemm_fp8_gfx942.py:82 alloc 'src0_gprs'v12    s:28(35) v:13(12) a:0(0)    sid:149 src0_gprs,0,local_row,;	v12 = 0x0 + v9
	v_lshlrev_b32 v12,0xe,v12  ; # gemm_fp8_gfx942.py:82 free 'src0_gprs'v12 alloc 'src0_gprs'v12    s:28(35) v:13(12) a:0(0)    sid:150 src0_gprs,14,src0_gprs,;	v12.b32 = v12 << 0xe[4:0];
	v_add_u32_e32 v13,0x0,v6  ; # gemm_fp8_gfx942.py:82 alloc 'src0_gprs'v13    s:28(35) v:14(13) a:0(0)    sid:151 src0_gprs,0,src1_gprs,;	v13 = 0x0 + v6
	v_lshlrev_b32 v14,0x4,v13  ; # gemm_fp8_gfx942.py:82 alloc 'src1_gprs'v14    s:28(35) v:15(14) a:0(0)    sid:152 src1_gprs,4,src0_gprs,;	v14.b32 = v13 << 0x4[4:0];
	v_add_u32_e32 v15,v12,v14  ; # gemm_fp8_gfx942.py:82 alloc 'load_a[0:0]'v15    s:28(35) v:16(15) a:0(0)    sid:153 load_a[0:0],src0_gprs,src1_gprs,;	v15 = v12 + v14
	v_add_u32_e32 v16,0x80,v9  ; # gemm_fp8_gfx942.py:82 alloc 'src0_gprs'v16    s:28(35) v:17(16) a:0(0)    sid:154 src0_gprs,128,local_row,;	v16 = 0x80 + v9
	v_lshlrev_b32 v16,0xe,v16  ; # gemm_fp8_gfx942.py:82 free 'src0_gprs'v16 alloc 'src0_gprs'v16    s:28(35) v:17(16) a:0(0)    sid:155 src0_gprs,14,src0_gprs,;	v16.b32 = v16 << 0xe[4:0];
	v_add_u32_e32 v14,v16,v14  ; # gemm_fp8_gfx942.py:82 free 'src1_gprs'v14 alloc 'load_a[2:2]'v14    s:28(35) v:17(16) a:0(0)    sid:156 load_a[2:2],src0_gprs,src1_gprs,;	v14 = v16 + v14
	v_lshlrev_b32 v17,0x7,v5  ; # gemm_fp8_gfx942.py:83 alloc 'src0_gprs'v17    s:28(35) v:18(17) a:0(0)    sid:157 src0_gprs,7,src1_gprs,;	v17.b32 = v5 << 0x7[4:0];
	v_xor_b32 v13,v5,v13  ; # gemm_fp8_gfx942.py:83 free 'src0_gprs'v13 alloc 'src1_gprs'v13    s:28(35) v:18(17) a:0(0)    sid:158 src1_gprs,src1_gprs,src0_gprs,;	v13.u32 = (v5 ^ v13.u32)
	v_and_b32 v13,0x7,v13  ; # gemm_fp8_gfx942.py:83 free 'src1_gprs'v13 alloc 'src0_gprs'v13    s:28(35) v:18(17) a:0(0)    sid:159 src0_gprs,7,src1_gprs,;	v13.u32 = (0x7 & v13.u32)
	v_lshlrev_b32 v13,0x4,v13  ; # gemm_fp8_gfx942.py:83 free 'src0_gprs'v13 alloc 'src1_gprs'v13    s:28(35) v:18(17) a:0(0)    sid:160 src1_gprs,4,src0_gprs,;	v13.b32 = v13 << 0x4[4:0];
	v_add_u32_e32 v13,v17,v13  ; # gemm_fp8_gfx942.py:83 free 'src1_gprs'v13 alloc 'read_b[0:0]'v13    s:28(35) v:18(17) a:0(0)    sid:161 read_b[0:0],src0_gprs,src1_gprs,;	v13 = v17 + v13
	v_add_u32_e32 v6,0x4,v6  ; # gemm_fp8_gfx942.py:82 free 'src1_gprs'v6 alloc 'src0_gprs'v6    s:28(35) v:18(17) a:0(0)    sid:162 src0_gprs,4,src1_gprs,;	v6 = 0x4 + v6
	v_lshlrev_b32 v18,0x4,v6  ; # gemm_fp8_gfx942.py:82 alloc 'src1_gprs'v18    s:28(35) v:19(18) a:0(0)    sid:163 src1_gprs,4,src0_gprs,;	v18.b32 = v6 << 0x4[4:0];
	v_add_u32_e32 v12,v12,v18  ; # gemm_fp8_gfx942.py:82 free 'src0_gprs'v12 alloc 'load_a[1:1]'v12    s:28(35) v:19(18) a:0(0)    sid:164 load_a[1:1],src0_gprs,src1_gprs,;	v12 = v12 + v18
	v_add_u32_e32 v16,v16,v18  ; # gemm_fp8_gfx942.py:82 free 'src0_gprs'v16 free 'src1_gprs'v18 alloc 'load_a[3:3]'v16    s:28(35) v:18(17) a:0(0)    sid:165 load_a[3:3],src0_gprs,src1_gprs,;	v16 = v16 + v18
	v_xor_b32 v5,v5,v6  ; # gemm_fp8_gfx942.py:83 free 'src1_gprs'v5 free 'src0_gprs'v6 alloc 'src1_gprs'v5    s:28(35) v:17(17) a:0(0)    sid:166 src1_gprs,src1_gprs,src0_gprs,;	v5.u32 = (v5 ^ v6.u32)
	v_and_b32 v5,0x7,v5  ; # gemm_fp8_gfx942.py:83 free 'src1_gprs'v5 alloc 'src0_gprs'v5    s:28(35) v:17(17) a:0(0)    sid:167 src0_gprs,7,src1_gprs,;	v5.u32 = (0x7 & v5.u32)
	v_lshlrev_b32 v5,0x4,v5  ; # gemm_fp8_gfx942.py:83 free 'src0_gprs'v5 alloc 'src1_gprs'v5    s:28(35) v:17(17) a:0(0)    sid:168 src1_gprs,4,src0_gprs,;	v5.b32 = v5 << 0x4[4:0];
	v_add_u32_e32 v5,v17,v5  ; # gemm_fp8_gfx942.py:83 free 'src0_gprs'v17 free 'src1_gprs'v5 alloc 'read_b[1:1]'v5    s:28(35) v:16(16) a:0(0)    sid:169 read_b[1:1],src0_gprs,src1_gprs,;	v5 = v17 + v5
	v_mov_b32 v20,0x0  ; # gemm_fp8_gfx942.py:89 alloc 'partial[0:3]'v[20:23]    s:28(35) v:20(23) a:0(0)    sid:170 partial[0:3],0,;	v20 = 0x0;
	v_mov_b32 v21,0x0  ; # gemm_fp8_gfx942.py:89   sid:171 partial[0:3],0,;	v21 = 0x0;
	v_mov_b32 v22,0x0  ; # gemm_fp8_gfx942.py:89   sid:172 partial[0:3],0,;	v22 = 0x0;
	v_mov_b32 v23,0x0  ; # gemm_fp8_gfx942.py:89   sid:173 partial[0:3],0,;	v23 = 0x0;
	v_mov_b32 v24,0x0  ; # gemm_fp8_gfx942.py:89 alloc 'partial[4:7]'v[24:27]    s:28(35) v:24(27) a:0(0)    sid:174 partial[4:7],0,;	v24 = 0x0;
	v_mov_b32 v25,0x0  ; # gemm_fp8_gfx942.py:89   sid:175 partial[4:7],0,;	v25 = 0x0;
	v_mov_b32 v26,0x0  ; # gemm_fp8_gfx942.py:89   sid:176 partial[4:7],0,;	v26 = 0x0;
	v_mov_b32 v27,0x0  ; # gemm_fp8_gfx942.py:89   sid:177 partial[4:7],0,;	v27 = 0x0;
	v_mov_b32 v28,0x0  ; # gemm_fp8_gfx942.py:89 alloc 'partial[8:11]'v[28:31]    s:28(35) v:28(31) a:0(0)    sid:178 partial[8:11],0,;	v28 = 0x0;
	v_mov_b32 v29,0x0  ; # gemm_fp8_gfx942.py:89   sid:179 partial[8:11],0,;	v29 = 0x0;
	v_mov_b32 v30,0x0  ; # gemm_fp8_gfx942.py:89   sid:180 partial[8:11],0,;	v30 = 0x0;
	v_mov_b32 v31,0x0  ; # gemm_fp8_gfx942.py:89   sid:181 partial[8:11],0,;	v31 = 0x0;
	v_mov_b32 v32,0x0  ; # gemm_fp8_gfx942.py:89 alloc 'partial[12:15]'v[32:35]    s:28(35) v:32(35) a:0(0)    sid:182 partial[12:15],0,;	v32 = 0x0;
	v_mov_b32 v33,0x0  ; # gemm_fp8_gfx942.py:89   sid:183 partial[12:15],0,;	v33 = 0x0;
	v_mov_b32 v34,0x0  ; # gemm_fp8_gfx942.py:89   sid:184 partial[12:15],0,;	v34 = 0x0;
	v_mov_b32 v35,0x0  ; # gemm_fp8_gfx942.py:89   sid:185 partial[12:15],0,;	v35 = 0x0;
	v_mov_b32 v6,0x0  ; # gemm_fp8_gfx942.py:90 alloc 'partial_scale[0:0]'v6    s:28(35) v:33(35) a:0(0)    sid:186 partial_scale[0:0],0,;	v6 = 0x0;
	v_mov_b32 v17,0x0  ; # gemm_fp8_gfx942.py:90 alloc 'partial_scale[1:1]'v17    s:28(35) v:34(35) a:0(0)    sid:187 partial_scale[1:1],0,;	v17 = 0x0;
	v_mov_b32 v18,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[0:0]'v18    s:28(35) v:35(35) a:0(0)    sid:188 accum[0:0],0,;	v18 = 0x0;
	v_mov_b32 v19,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[1:1]'v19    s:28(35) v:36(35) a:0(0)    sid:189 accum[1:1],0,;	v19 = 0x0;
	v_mov_b32 v36,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[2:2]'v36    s:28(35) v:37(36) a:0(0)    sid:190 accum[2:2],0,;	v36 = 0x0;
	v_mov_b32 v37,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[3:3]'v37    s:28(35) v:38(37) a:0(0)    sid:191 accum[3:3],0,;	v37 = 0x0;
	v_mov_b32 v38,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[4:4]'v38    s:28(35) v:39(38) a:0(0)    sid:192 accum[4:4],0,;	v38 = 0x0;
	v_mov_b32 v39,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[5:5]'v39    s:28(35) v:40(39) a:0(0)    sid:193 accum[5:5],0,;	v39 = 0x0;
	v_mov_b32 v40,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[6:6]'v40    s:28(35) v:41(40) a:0(0)    sid:194 accum[6:6],0,;	v40 = 0x0;
	v_mov_b32 v41,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[7:7]'v41    s:28(35) v:42(41) a:0(0)    sid:195 accum[7:7],0,;	v41 = 0x0;
	v_mov_b32 v42,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[8:8]'v42    s:28(35) v:43(42) a:0(0)    sid:196 accum[8:8],0,;	v42 = 0x0;
	v_mov_b32 v43,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[9:9]'v43    s:28(35) v:44(43) a:0(0)    sid:197 accum[9:9],0,;	v43 = 0x0;
	v_mov_b32 v44,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[10:10]'v44    s:28(35) v:45(44) a:0(0)    sid:198 accum[10:10],0,;	v44 = 0x0;
	v_mov_b32 v45,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[11:11]'v45    s:28(35) v:46(45) a:0(0)    sid:199 accum[11:11],0,;	v45 = 0x0;
	v_mov_b32 v46,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[12:12]'v46    s:28(35) v:47(46) a:0(0)    sid:200 accum[12:12],0,;	v46 = 0x0;
	v_mov_b32 v47,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[13:13]'v47    s:28(35) v:48(47) a:0(0)    sid:201 accum[13:13],0,;	v47 = 0x0;
	v_mov_b32 v48,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[14:14]'v48    s:28(35) v:49(48) a:0(0)    sid:202 accum[14:14],0,;	v48 = 0x0;
	v_mov_b32 v49,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[15:15]'v49    s:28(35) v:50(49) a:0(0)    sid:203 accum[15:15],0,;	v49 = 0x0;
	v_mov_b32 v50,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[16:16]'v50    s:28(35) v:51(50) a:0(0)    sid:204 accum[16:16],0,;	v50 = 0x0;
	v_mov_b32 v51,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[17:17]'v51    s:28(35) v:52(51) a:0(0)    sid:205 accum[17:17],0,;	v51 = 0x0;
	v_mov_b32 v52,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[18:18]'v52    s:28(35) v:53(52) a:0(0)    sid:206 accum[18:18],0,;	v52 = 0x0;
	v_mov_b32 v53,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[19:19]'v53    s:28(35) v:54(53) a:0(0)    sid:207 accum[19:19],0,;	v53 = 0x0;
	v_mov_b32 v54,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[20:20]'v54    s:28(35) v:55(54) a:0(0)    sid:208 accum[20:20],0,;	v54 = 0x0;
	v_mov_b32 v55,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[21:21]'v55    s:28(35) v:56(55) a:0(0)    sid:209 accum[21:21],0,;	v55 = 0x0;
	v_mov_b32 v56,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[22:22]'v56    s:28(35) v:57(56) a:0(0)    sid:210 accum[22:22],0,;	v56 = 0x0;
	v_mov_b32 v57,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[23:23]'v57    s:28(35) v:58(57) a:0(0)    sid:211 accum[23:23],0,;	v57 = 0x0;
	v_mov_b32 v58,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[24:24]'v58    s:28(35) v:59(58) a:0(0)    sid:212 accum[24:24],0,;	v58 = 0x0;
	v_mov_b32 v59,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[25:25]'v59    s:28(35) v:60(59) a:0(0)    sid:213 accum[25:25],0,;	v59 = 0x0;
	v_mov_b32 v60,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[26:26]'v60    s:28(35) v:61(60) a:0(0)    sid:214 accum[26:26],0,;	v60 = 0x0;
	v_mov_b32 v61,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[27:27]'v61    s:28(35) v:62(61) a:0(0)    sid:215 accum[27:27],0,;	v61 = 0x0;
	v_mov_b32 v62,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[28:28]'v62    s:28(35) v:63(62) a:0(0)    sid:216 accum[28:28],0,;	v62 = 0x0;
	v_mov_b32 v63,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[29:29]'v63    s:28(35) v:64(63) a:0(0)    sid:217 accum[29:29],0,;	v63 = 0x0;
	v_mov_b32 v64,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[30:30]'v64    s:28(35) v:65(64) a:0(0)    sid:218 accum[30:30],0,;	v64 = 0x0;
	v_mov_b32 v65,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[31:31]'v65    s:28(35) v:66(65) a:0(0)    sid:219 accum[31:31],0,;	v65 = 0x0;
	v_mov_b32 v66,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[32:32]'v66    s:28(35) v:67(66) a:0(0)    sid:220 accum[32:32],0,;	v66 = 0x0;
	v_mov_b32 v67,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[33:33]'v67    s:28(35) v:68(67) a:0(0)    sid:221 accum[33:33],0,;	v67 = 0x0;
	v_mov_b32 v68,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[34:34]'v68    s:28(35) v:69(68) a:0(0)    sid:222 accum[34:34],0,;	v68 = 0x0;
	v_mov_b32 v69,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[35:35]'v69    s:28(35) v:70(69) a:0(0)    sid:223 accum[35:35],0,;	v69 = 0x0;
	v_mov_b32 v70,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[36:36]'v70    s:28(35) v:71(70) a:0(0)    sid:224 accum[36:36],0,;	v70 = 0x0;
	v_mov_b32 v71,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[37:37]'v71    s:28(35) v:72(71) a:0(0)    sid:225 accum[37:37],0,;	v71 = 0x0;
	v_mov_b32 v72,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[38:38]'v72    s:28(35) v:73(72) a:0(0)    sid:226 accum[38:38],0,;	v72 = 0x0;
	v_mov_b32 v73,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[39:39]'v73    s:28(35) v:74(73) a:0(0)    sid:227 accum[39:39],0,;	v73 = 0x0;
	v_mov_b32 v74,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[40:40]'v74    s:28(35) v:75(74) a:0(0)    sid:228 accum[40:40],0,;	v74 = 0x0;
	v_mov_b32 v75,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[41:41]'v75    s:28(35) v:76(75) a:0(0)    sid:229 accum[41:41],0,;	v75 = 0x0;
	v_mov_b32 v76,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[42:42]'v76    s:28(35) v:77(76) a:0(0)    sid:230 accum[42:42],0,;	v76 = 0x0;
	v_mov_b32 v77,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[43:43]'v77    s:28(35) v:78(77) a:0(0)    sid:231 accum[43:43],0,;	v77 = 0x0;
	v_mov_b32 v78,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[44:44]'v78    s:28(35) v:79(78) a:0(0)    sid:232 accum[44:44],0,;	v78 = 0x0;
	v_mov_b32 v79,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[45:45]'v79    s:28(35) v:80(79) a:0(0)    sid:233 accum[45:45],0,;	v79 = 0x0;
	v_mov_b32 v80,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[46:46]'v80    s:28(35) v:81(80) a:0(0)    sid:234 accum[46:46],0,;	v80 = 0x0;
	v_mov_b32 v81,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[47:47]'v81    s:28(35) v:82(81) a:0(0)    sid:235 accum[47:47],0,;	v81 = 0x0;
	v_mov_b32 v82,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[48:48]'v82    s:28(35) v:83(82) a:0(0)    sid:236 accum[48:48],0,;	v82 = 0x0;
	v_mov_b32 v83,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[49:49]'v83    s:28(35) v:84(83) a:0(0)    sid:237 accum[49:49],0,;	v83 = 0x0;
	v_mov_b32 v84,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[50:50]'v84    s:28(35) v:85(84) a:0(0)    sid:238 accum[50:50],0,;	v84 = 0x0;
	v_mov_b32 v85,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[51:51]'v85    s:28(35) v:86(85) a:0(0)    sid:239 accum[51:51],0,;	v85 = 0x0;
	v_mov_b32 v86,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[52:52]'v86    s:28(35) v:87(86) a:0(0)    sid:240 accum[52:52],0,;	v86 = 0x0;
	v_mov_b32 v87,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[53:53]'v87    s:28(35) v:88(87) a:0(0)    sid:241 accum[53:53],0,;	v87 = 0x0;
	v_mov_b32 v88,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[54:54]'v88    s:28(35) v:89(88) a:0(0)    sid:242 accum[54:54],0,;	v88 = 0x0;
	v_mov_b32 v89,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[55:55]'v89    s:28(35) v:90(89) a:0(0)    sid:243 accum[55:55],0,;	v89 = 0x0;
	v_mov_b32 v90,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[56:56]'v90    s:28(35) v:91(90) a:0(0)    sid:244 accum[56:56],0,;	v90 = 0x0;
	v_mov_b32 v91,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[57:57]'v91    s:28(35) v:92(91) a:0(0)    sid:245 accum[57:57],0,;	v91 = 0x0;
	v_mov_b32 v92,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[58:58]'v92    s:28(35) v:93(92) a:0(0)    sid:246 accum[58:58],0,;	v92 = 0x0;
	v_mov_b32 v93,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[59:59]'v93    s:28(35) v:94(93) a:0(0)    sid:247 accum[59:59],0,;	v93 = 0x0;
	v_mov_b32 v94,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[60:60]'v94    s:28(35) v:95(94) a:0(0)    sid:248 accum[60:60],0,;	v94 = 0x0;
	v_mov_b32 v95,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[61:61]'v95    s:28(35) v:96(95) a:0(0)    sid:249 accum[61:61],0,;	v95 = 0x0;
	v_mov_b32 v96,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[62:62]'v96    s:28(35) v:97(96) a:0(0)    sid:250 accum[62:62],0,;	v96 = 0x0;
	v_mov_b32 v97,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[63:63]'v97    s:28(35) v:98(97) a:0(0)    sid:251 accum[63:63],0,;	v97 = 0x0;
	v_mov_b32 v98,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[64:64]'v98    s:28(35) v:99(98) a:0(0)    sid:252 accum[64:64],0,;	v98 = 0x0;
	v_mov_b32 v99,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[65:65]'v99    s:28(35) v:100(99) a:0(0)    sid:253 accum[65:65],0,;	v99 = 0x0;
	v_mov_b32 v100,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[66:66]'v100    s:28(35) v:101(100) a:0(0)    sid:254 accum[66:66],0,;	v100 = 0x0;
	v_mov_b32 v101,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[67:67]'v101    s:28(35) v:102(101) a:0(0)    sid:255 accum[67:67],0,;	v101 = 0x0;
	v_mov_b32 v102,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[68:68]'v102    s:28(35) v:103(102) a:0(0)    sid:256 accum[68:68],0,;	v102 = 0x0;
	v_mov_b32 v103,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[69:69]'v103    s:28(35) v:104(103) a:0(0)    sid:257 accum[69:69],0,;	v103 = 0x0;
	v_mov_b32 v104,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[70:70]'v104    s:28(35) v:105(104) a:0(0)    sid:258 accum[70:70],0,;	v104 = 0x0;
	v_mov_b32 v105,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[71:71]'v105    s:28(35) v:106(105) a:0(0)    sid:259 accum[71:71],0,;	v105 = 0x0;
	v_mov_b32 v106,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[72:72]'v106    s:28(35) v:107(106) a:0(0)    sid:260 accum[72:72],0,;	v106 = 0x0;
	v_mov_b32 v107,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[73:73]'v107    s:28(35) v:108(107) a:0(0)    sid:261 accum[73:73],0,;	v107 = 0x0;
	v_mov_b32 v108,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[74:74]'v108    s:28(35) v:109(108) a:0(0)    sid:262 accum[74:74],0,;	v108 = 0x0;
	v_mov_b32 v109,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[75:75]'v109    s:28(35) v:110(109) a:0(0)    sid:263 accum[75:75],0,;	v109 = 0x0;
	v_mov_b32 v110,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[76:76]'v110    s:28(35) v:111(110) a:0(0)    sid:264 accum[76:76],0,;	v110 = 0x0;
	v_mov_b32 v111,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[77:77]'v111    s:28(35) v:112(111) a:0(0)    sid:265 accum[77:77],0,;	v111 = 0x0;
	v_mov_b32 v112,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[78:78]'v112    s:28(35) v:113(112) a:0(0)    sid:266 accum[78:78],0,;	v112 = 0x0;
	v_mov_b32 v113,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[79:79]'v113    s:28(35) v:114(113) a:0(0)    sid:267 accum[79:79],0,;	v113 = 0x0;
	v_mov_b32 v114,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[80:80]'v114    s:28(35) v:115(114) a:0(0)    sid:268 accum[80:80],0,;	v114 = 0x0;
	v_mov_b32 v115,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[81:81]'v115    s:28(35) v:116(115) a:0(0)    sid:269 accum[81:81],0,;	v115 = 0x0;
	v_mov_b32 v116,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[82:82]'v116    s:28(35) v:117(116) a:0(0)    sid:270 accum[82:82],0,;	v116 = 0x0;
	v_mov_b32 v117,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[83:83]'v117    s:28(35) v:118(117) a:0(0)    sid:271 accum[83:83],0,;	v117 = 0x0;
	v_mov_b32 v118,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[84:84]'v118    s:28(35) v:119(118) a:0(0)    sid:272 accum[84:84],0,;	v118 = 0x0;
	v_mov_b32 v119,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[85:85]'v119    s:28(35) v:120(119) a:0(0)    sid:273 accum[85:85],0,;	v119 = 0x0;
	v_mov_b32 v120,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[86:86]'v120    s:28(35) v:121(120) a:0(0)    sid:274 accum[86:86],0,;	v120 = 0x0;
	v_mov_b32 v121,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[87:87]'v121    s:28(35) v:122(121) a:0(0)    sid:275 accum[87:87],0,;	v121 = 0x0;
	v_mov_b32 v122,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[88:88]'v122    s:28(35) v:123(122) a:0(0)    sid:276 accum[88:88],0,;	v122 = 0x0;
	v_mov_b32 v123,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[89:89]'v123    s:28(35) v:124(123) a:0(0)    sid:277 accum[89:89],0,;	v123 = 0x0;
	v_mov_b32 v124,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[90:90]'v124    s:28(35) v:125(124) a:0(0)    sid:278 accum[90:90],0,;	v124 = 0x0;
	v_mov_b32 v125,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[91:91]'v125    s:28(35) v:126(125) a:0(0)    sid:279 accum[91:91],0,;	v125 = 0x0;
	v_mov_b32 v126,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[92:92]'v126    s:28(35) v:127(126) a:0(0)    sid:280 accum[92:92],0,;	v126 = 0x0;
	v_mov_b32 v127,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[93:93]'v127    s:28(35) v:128(127) a:0(0)    sid:281 accum[93:93],0,;	v127 = 0x0;
	v_mov_b32 v128,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[94:94]'v128    s:28(35) v:129(128) a:0(0)    sid:282 accum[94:94],0,;	v128 = 0x0;
	v_mov_b32 v129,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[95:95]'v129    s:28(35) v:130(129) a:0(0)    sid:283 accum[95:95],0,;	v129 = 0x0;
	v_mov_b32 v130,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[96:96]'v130    s:28(35) v:131(130) a:0(0)    sid:284 accum[96:96],0,;	v130 = 0x0;
	v_mov_b32 v131,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[97:97]'v131    s:28(35) v:132(131) a:0(0)    sid:285 accum[97:97],0,;	v131 = 0x0;
	v_mov_b32 v132,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[98:98]'v132    s:28(35) v:133(132) a:0(0)    sid:286 accum[98:98],0,;	v132 = 0x0;
	v_mov_b32 v133,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[99:99]'v133    s:28(35) v:134(133) a:0(0)    sid:287 accum[99:99],0,;	v133 = 0x0;
	v_mov_b32 v134,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[100:100]'v134    s:28(35) v:135(134) a:0(0)    sid:288 accum[100:100],0,;	v134 = 0x0;
	v_mov_b32 v135,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[101:101]'v135    s:28(35) v:136(135) a:0(0)    sid:289 accum[101:101],0,;	v135 = 0x0;
	v_mov_b32 v136,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[102:102]'v136    s:28(35) v:137(136) a:0(0)    sid:290 accum[102:102],0,;	v136 = 0x0;
	v_mov_b32 v137,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[103:103]'v137    s:28(35) v:138(137) a:0(0)    sid:291 accum[103:103],0,;	v137 = 0x0;
	v_mov_b32 v138,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[104:104]'v138    s:28(35) v:139(138) a:0(0)    sid:292 accum[104:104],0,;	v138 = 0x0;
	v_mov_b32 v139,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[105:105]'v139    s:28(35) v:140(139) a:0(0)    sid:293 accum[105:105],0,;	v139 = 0x0;
	v_mov_b32 v140,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[106:106]'v140    s:28(35) v:141(140) a:0(0)    sid:294 accum[106:106],0,;	v140 = 0x0;
	v_mov_b32 v141,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[107:107]'v141    s:28(35) v:142(141) a:0(0)    sid:295 accum[107:107],0,;	v141 = 0x0;
	v_mov_b32 v142,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[108:108]'v142    s:28(35) v:143(142) a:0(0)    sid:296 accum[108:108],0,;	v142 = 0x0;
	v_mov_b32 v143,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[109:109]'v143    s:28(35) v:144(143) a:0(0)    sid:297 accum[109:109],0,;	v143 = 0x0;
	v_mov_b32 v144,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[110:110]'v144    s:28(35) v:145(144) a:0(0)    sid:298 accum[110:110],0,;	v144 = 0x0;
	v_mov_b32 v145,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[111:111]'v145    s:28(35) v:146(145) a:0(0)    sid:299 accum[111:111],0,;	v145 = 0x0;
	v_mov_b32 v146,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[112:112]'v146    s:28(35) v:147(146) a:0(0)    sid:300 accum[112:112],0,;	v146 = 0x0;
	v_mov_b32 v147,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[113:113]'v147    s:28(35) v:148(147) a:0(0)    sid:301 accum[113:113],0,;	v147 = 0x0;
	v_mov_b32 v148,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[114:114]'v148    s:28(35) v:149(148) a:0(0)    sid:302 accum[114:114],0,;	v148 = 0x0;
	v_mov_b32 v149,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[115:115]'v149    s:28(35) v:150(149) a:0(0)    sid:303 accum[115:115],0,;	v149 = 0x0;
	v_mov_b32 v150,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[116:116]'v150    s:28(35) v:151(150) a:0(0)    sid:304 accum[116:116],0,;	v150 = 0x0;
	v_mov_b32 v151,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[117:117]'v151    s:28(35) v:152(151) a:0(0)    sid:305 accum[117:117],0,;	v151 = 0x0;
	v_mov_b32 v152,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[118:118]'v152    s:28(35) v:153(152) a:0(0)    sid:306 accum[118:118],0,;	v152 = 0x0;
	v_mov_b32 v153,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[119:119]'v153    s:28(35) v:154(153) a:0(0)    sid:307 accum[119:119],0,;	v153 = 0x0;
	v_mov_b32 v154,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[120:120]'v154    s:28(35) v:155(154) a:0(0)    sid:308 accum[120:120],0,;	v154 = 0x0;
	v_mov_b32 v155,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[121:121]'v155    s:28(35) v:156(155) a:0(0)    sid:309 accum[121:121],0,;	v155 = 0x0;
	v_mov_b32 v156,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[122:122]'v156    s:28(35) v:157(156) a:0(0)    sid:310 accum[122:122],0,;	v156 = 0x0;
	v_mov_b32 v157,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[123:123]'v157    s:28(35) v:158(157) a:0(0)    sid:311 accum[123:123],0,;	v157 = 0x0;
	v_mov_b32 v158,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[124:124]'v158    s:28(35) v:159(158) a:0(0)    sid:312 accum[124:124],0,;	v158 = 0x0;
	v_mov_b32 v159,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[125:125]'v159    s:28(35) v:160(159) a:0(0)    sid:313 accum[125:125],0,;	v159 = 0x0;
	v_mov_b32 v160,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[126:126]'v160    s:28(35) v:161(160) a:0(0)    sid:314 accum[126:126],0,;	v160 = 0x0;
	v_mov_b32 v161,0x0  ; # gemm_fp8_gfx942.py:91 alloc 'accum[127:127]'v161    s:28(35) v:162(161) a:0(0)    sid:315 accum[127:127],0,;	v161 = 0x0;
	s_mov_b32 s12,0x0  ; # asmjit.py:1627 gemm_fp8_gfx942.py:92 alloc 'k_offset's12    s:29(35) v:162(161) a:0(0)    sid:316 k_offset,0,;	s12 = 0x0
	s_mov_b32 s13,0x0  ; # asmjit.py:1627 gemm_fp8_gfx942.py:93 alloc 'scale_offset's13    s:30(35) v:162(161) a:0(0)    sid:317 scale_offset,0,;	s13 = 0x0
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'idst's17    s:31(35) v:162(161) a:0(0)    sid:318 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v4,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17 alloc 'staging_b[0:3]'v[164:167]    s:30(35) v:166(167) a:0(0)    sid:319 staging_b[0:3],load_b[0:0],self.desc,idst,
	buffer_load_dwordx4 v[168:171],v15,s[24:27],s12 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'operands_a[0:3]'v[168:171]    s:30(35) v:170(171) a:0(0)    sid:320 operands_a[0:3],load_a[0:0],self.desc,k_offset,
	buffer_load_dwordx4 v[172:175],v12,s[24:27],s12 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'operands_a[4:7]'v[172:175]    s:30(35) v:174(175) a:0(0)    sid:321 operands_a[4:7],load_a[1:1],self.desc,k_offset,
	buffer_load_dword v162,v11,s[8:11],s13 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:99 alloc 'scale_a[0:0]'v162    s:30(35) v:175(175) a:0(0)    sid:322 scale_a[0:0],load_scale_a[0:0],self.desc,scale_offset,
	buffer_load_dwordx4 v[176:179],v14,s[24:27],s12 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'operands_a[8:11]'v[176:179]    s:30(35) v:179(179) a:0(0)    sid:323 operands_a[8:11],load_a[2:2],self.desc,k_offset,
	buffer_load_dwordx4 v[180:183],v16,s[24:27],s12 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'operands_a[12:15]'v[180:183]    s:30(35) v:183(183) a:0(0)    sid:324 operands_a[12:15],load_a[3:3],self.desc,k_offset,
	buffer_load_dword v163,v10,s[8:11],s13 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:99 alloc 'scale_a[1:1]'v163    s:30(35) v:184(183) a:0(0)    sid:325 scale_a[1:1],load_scale_a[1:1],self.desc,scale_offset,
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:110 alloc 'src1_gprs's17    s:31(35) v:184(183) a:0(0)    sid:326 src1_gprs,k_offset,5,
	s_add_u32 s17,s6,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'idst's17    s:31(35) v:184(183) a:0(0)    sid:327 idst,scale_offset_b,src1_gprs,;	s17.u32 = s6 + s17; scc=overflow_or_carry
	s_load_dword s20,s[14:15],s17  ; # gemm_fp8_gfx942.py:110 free 'idst's17 alloc 'scale_b's[20:23]    s:34(35) v:184(183) a:0(0)    sid:328 scale_b,pScaleB,idst,;	s20 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:110 alloc 'src1_gprs's17    s:35(35) v:184(183) a:0(0)    sid:329 src1_gprs,k_offset,5,
	s_add_u32 s17,s7,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:184(183) a:0(0)    sid:330 idst,scale_offset_b,src1_gprs,;	s17.u32 = s7 + s17; scc=overflow_or_carry
	s_load_dword s21,s[14:15],s17  ; # gemm_fp8_gfx942.py:110 free 'idst's17   sid:331 scale_b,pScaleB,idst,;	s21 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_waitcnt  vmcnt(6) ; # gemm_fp8_gfx942.py:207   sid:332 
	ds_write_b128 v2,v[164:167] offset:0 ; # gemm_fp8_gfx942.py:208   sid:333 write_b,staging_b[0:3],;	LDS_MEM[v2 + 0].b128 = v[164:167].b128
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'idst's17    s:35(35) v:184(183) a:0(0)    sid:334 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v7,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:335 staging_b[0:3],load_b[1:1],self.desc,idst,
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'idst's17    s:35(35) v:184(183) a:0(0)    sid:336 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v8,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17 alloc 'staging_b[4:7]'v[184:187]    s:34(35) v:188(187) a:0(0)    sid:337 staging_b[4:7],load_b[2:2],self.desc,idst,
	s_waitcnt  vmcnt(2) lgkmcnt(0) ; # gemm_fp8_gfx942.py:211   sid:338 
	s_barrier   ; # gemm_fp8_gfx942.py:212   sid:339 
	s_cmp_eq_u32 s16,0x1  ; # asmjit.py:1421 contextlib.py:137   sid:340 group,1,;	scc = (s16.u32 == 0x1.u32)
	s_cbranch_scc0  _if_else_213_1 ; # asmjit.py:1367 asmjit.py:1421 contextlib.py:137   sid:341;	jump if scc is 0 (scc == 0)
_bb_no_name_46:	 ;BB#46 predecessors:[_if_else_28_0] successors:[_if_else_213_1]
	s_barrier   ; # gemm_fp8_gfx942.py:214   sid:342 
_if_else_213_1:	 ;BB#47 predecessors:[_bb_no_name_46,_if_else_28_0] successors:[_while_begin_220_2]
	s_waitcnt  vmcnt(1) ; # gemm_fp8_gfx942.py:149   sid:343 
	ds_write_b128 v2,v[164:167] offset:8192 ; # gemm_fp8_gfx942.py:150   sid:344 write_b,staging_b[0:3],;	LDS_MEM[v2 + 8192].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:188(187) a:0(0)    sid:345 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[188:191],v15,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17 alloc 'operands_a[16:19]'v[188:191]    s:34(35) v:192(191) a:0(0)    sid:346 operands_a[16:19],load_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 alloc 'src1_gprs's17    s:35(35) v:192(191) a:0(0)    sid:347 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:192(191) a:0(0)    sid:348 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v192,v11,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'idst's17 alloc 'scale_a[2:2]'v192    s:34(35) v:193(192) a:0(0)    sid:349 scale_a[2:2],load_scale_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'idst's17    s:35(35) v:193(192) a:0(0)    sid:350 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v3,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:351 staging_b[0:3],load_b[3:3],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:0 ; # gemm_fp8_gfx942.py:161 alloc 'operands_b[0:3]'v[196:199]    s:34(35) v:197(199) a:0(0)    sid:352 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:0 ; # gemm_fp8_gfx942.py:161 alloc 'operands_b[4:7]'v[200:203]    s:34(35) v:201(203) a:0(0)    sid:353 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:2048 ; # gemm_fp8_gfx942.py:161 alloc 'operands_b[8:11]'v[204:207]    s:34(35) v:205(207) a:0(0)    sid:354 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:2048 ; # gemm_fp8_gfx942.py:161 alloc 'operands_b[12:15]'v[208:211]    s:34(35) v:209(211) a:0(0)    sid:355 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:4096 ; # gemm_fp8_gfx942.py:161 alloc 'operands_b[16:19]'v[212:215]    s:34(35) v:213(215) a:0(0)    sid:356 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:4096 ; # gemm_fp8_gfx942.py:161 alloc 'operands_b[20:23]'v[216:219]    s:34(35) v:217(219) a:0(0)    sid:357 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:6144 ; # gemm_fp8_gfx942.py:161 alloc 'operands_b[24:27]'v[220:223]    s:34(35) v:221(223) a:0(0)    sid:358 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 6144].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:6144 ; # gemm_fp8_gfx942.py:161 alloc 'operands_b[28:31]'v[224:227]    s:34(35) v:225(227) a:0(0)    sid:359 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 6144].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:360 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:361 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:362 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:363 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:364 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s20,v162  ; # gemm_fp8_gfx942.py:185   sid:365 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v154,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:366 accum[120:120],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:367 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v155,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:368 accum[121:121],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:369 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v156,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:370 accum[122:122],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:371 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v157,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:372 accum[123:123],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:373 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v158,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:374 accum[124:124],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:375 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v159,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:376 accum[125:125],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:377 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v160,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:378 accum[126:126],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:379 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v161,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:380 accum[127:127],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:381 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v18,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:382 accum[0:0],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:383 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v19,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:384 accum[1:1],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:385 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v36,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:386 accum[2:2],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:387 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v37,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:388 accum[3:3],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:389 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v38,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:390 accum[4:4],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:391 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v39,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:392 accum[5:5],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:393 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v40,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:394 accum[6:6],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:395 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v41,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:396 accum[7:7],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:397 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s20,v163  ; # gemm_fp8_gfx942.py:185   sid:398 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v42,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:399 accum[8:8],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:400 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v43,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:401 accum[9:9],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:402 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v44,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:403 accum[10:10],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:404 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v45,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:405 accum[11:11],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:406 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v46,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:407 accum[12:12],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:408 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v47,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:409 accum[13:13],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:410 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v48,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:411 accum[14:14],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:412 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v49,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:413 accum[15:15],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:414 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v98,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:415 accum[64:64],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:416 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v99,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:417 accum[65:65],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:418 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v100,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:419 accum[66:66],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:420 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v101,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:421 accum[67:67],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:422 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v102,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:423 accum[68:68],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:424 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v103,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:425 accum[69:69],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:426 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v104,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:427 accum[70:70],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:428 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:429 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v105,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:430 accum[71:71],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:431 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:149   sid:432 
	ds_write_b128 v2,v[184:187] offset:16384 ; # gemm_fp8_gfx942.py:150   sid:433 write_b,staging_b[4:7],;	LDS_MEM[v2 + 16384].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:225(227) a:0(0)    sid:434 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[228:231],v14,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17 alloc 'operands_a[24:27]'v[228:231]    s:34(35) v:229(231) a:0(0)    sid:435 operands_a[24:27],load_a[2:2],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 alloc 'src1_gprs's17    s:35(35) v:229(231) a:0(0)    sid:436 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:229(231) a:0(0)    sid:437 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v193,v10,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'idst's17 alloc 'scale_a[3:3]'v193    s:34(35) v:230(231) a:0(0)    sid:438 scale_a[3:3],load_scale_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'src0_gprs's17    s:35(35) v:230(231) a:0(0)    sid:439 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'src0_gprs's17 alloc 'idst's17    s:35(35) v:230(231) a:0(0)    sid:440 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v4,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:441 staging_b[4:7],load_b[0:0],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:8192 ; # gemm_fp8_gfx942.py:161   sid:442 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:8192 ; # gemm_fp8_gfx942.py:161   sid:443 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:10240 ; # gemm_fp8_gfx942.py:161   sid:444 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:10240 ; # gemm_fp8_gfx942.py:161   sid:445 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:12288 ; # gemm_fp8_gfx942.py:161   sid:446 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:12288 ; # gemm_fp8_gfx942.py:161   sid:447 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:14336 ; # gemm_fp8_gfx942.py:161   sid:448 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 14336].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:14336 ; # gemm_fp8_gfx942.py:161   sid:449 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 14336].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:450 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:451 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:452 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:453 
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:110 alloc 'src1_gprs's17    s:35(35) v:230(231) a:0(0)    sid:454 src1_gprs,k_offset,5,
	s_add_u32 s17,s6,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'src1_gprs's17    s:35(35) v:230(231) a:0(0)    sid:455 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s6 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:230(231) a:0(0)    sid:456 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s22,s[14:15],s17  ; # gemm_fp8_gfx942.py:110 free 'idst's17   sid:457 scale_b,pScaleB,idst,;	s22 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:110 alloc 'src1_gprs's17    s:35(35) v:230(231) a:0(0)    sid:458 src1_gprs,k_offset,5,
	s_add_u32 s17,s7,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'src1_gprs's17    s:35(35) v:230(231) a:0(0)    sid:459 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s7 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:230(231) a:0(0)    sid:460 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s23,s[14:15],s17  ; # gemm_fp8_gfx942.py:110 free 'idst's17   sid:461 scale_b,pScaleB,idst,;	s23 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:462 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s20,v162  ; # gemm_fp8_gfx942.py:185   sid:463 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v106,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:464 accum[72:72],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:465 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v107,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:466 accum[73:73],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:467 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v108,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:468 accum[74:74],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:469 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v109,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:470 accum[75:75],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:471 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v110,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:472 accum[76:76],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:473 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v111,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:474 accum[77:77],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:475 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v112,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:476 accum[78:78],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:477 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v113,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:478 accum[79:79],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:479 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v50,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:480 accum[16:16],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:481 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v51,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:482 accum[17:17],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:483 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v52,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:484 accum[18:18],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:485 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v53,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:486 accum[19:19],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:487 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v54,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:488 accum[20:20],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:489 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v55,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:490 accum[21:21],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:491 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v56,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:492 accum[22:22],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:493 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v57,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:494 accum[23:23],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:495 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s20,v163  ; # gemm_fp8_gfx942.py:185   sid:496 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v58,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:497 accum[24:24],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:498 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v59,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:499 accum[25:25],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:500 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v60,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:501 accum[26:26],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:502 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v61,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:503 accum[27:27],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:504 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v62,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:505 accum[28:28],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:506 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v63,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:507 accum[29:29],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:508 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v64,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:509 accum[30:30],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:510 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v65,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:511 accum[31:31],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:512 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v114,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:513 accum[80:80],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:514 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v115,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:515 accum[81:81],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:516 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v116,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:517 accum[82:82],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:518 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v117,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:519 accum[83:83],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:520 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v118,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:521 accum[84:84],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:522 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v119,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:523 accum[85:85],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:524 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v120,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:525 accum[86:86],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:526 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:527 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v121,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:528 accum[87:87],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:529 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:149   sid:530 
	ds_write_b128 v2,v[164:167] offset:24576 ; # gemm_fp8_gfx942.py:150   sid:531 write_b,staging_b[0:3],;	LDS_MEM[v2 + 24576].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:230(231) a:0(0)    sid:532 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[232:235],v12,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17 alloc 'operands_a[20:23]'v[232:235]    s:34(35) v:234(235) a:0(0)    sid:533 operands_a[20:23],load_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'src0_gprs's17    s:35(35) v:234(235) a:0(0)    sid:534 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'src0_gprs's17 alloc 'idst's17    s:35(35) v:234(235) a:0(0)    sid:535 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v7,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:536 staging_b[0:3],load_b[1:1],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:16384 ; # gemm_fp8_gfx942.py:161   sid:537 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:16384 ; # gemm_fp8_gfx942.py:161   sid:538 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:18432 ; # gemm_fp8_gfx942.py:161   sid:539 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:18432 ; # gemm_fp8_gfx942.py:161   sid:540 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:20480 ; # gemm_fp8_gfx942.py:161   sid:541 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:20480 ; # gemm_fp8_gfx942.py:161   sid:542 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:22528 ; # gemm_fp8_gfx942.py:161   sid:543 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 22528].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:22528 ; # gemm_fp8_gfx942.py:161   sid:544 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 22528].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:545 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:546 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:547 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:548 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:549 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s21,v162  ; # gemm_fp8_gfx942.py:185   sid:550 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v122,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:551 accum[88:88],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:552 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v123,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:553 accum[89:89],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:554 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v124,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:555 accum[90:90],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:556 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v125,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:557 accum[91:91],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:558 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v126,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:559 accum[92:92],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:560 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v127,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:561 accum[93:93],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:562 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v128,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:563 accum[94:94],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:564 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v129,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:565 accum[95:95],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:566 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v66,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:567 accum[32:32],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:568 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v67,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:569 accum[33:33],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:570 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v68,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:571 accum[34:34],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:572 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v69,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:573 accum[35:35],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:574 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v70,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:575 accum[36:36],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:576 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v71,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:577 accum[37:37],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:578 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v72,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:579 accum[38:38],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:580 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v73,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:581 accum[39:39],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:582 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s21,v163  ; # gemm_fp8_gfx942.py:185   sid:583 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v74,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:584 accum[40:40],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:585 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v75,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:586 accum[41:41],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:587 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v76,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:588 accum[42:42],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:589 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v77,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:590 accum[43:43],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:591 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v78,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:592 accum[44:44],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:593 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v79,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:594 accum[45:45],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:595 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v80,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:596 accum[46:46],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:597 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v81,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:598 accum[47:47],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:599 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v130,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:600 accum[96:96],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:601 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v131,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:602 accum[97:97],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:603 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v132,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:604 accum[98:98],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:605 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v133,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:606 accum[99:99],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:607 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v134,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:608 accum[100:100],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:609 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v135,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:610 accum[101:101],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:611 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v136,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:612 accum[102:102],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:613 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:614 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v137,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:615 accum[103:103],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:616 0,
	s_waitcnt  vmcnt(2) ; # gemm_fp8_gfx942.py:149   sid:617 
	ds_write_b128 v2,v[184:187] offset:0 ; # gemm_fp8_gfx942.py:150   sid:618 write_b,staging_b[4:7],;	LDS_MEM[v2 + 0].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:234(235) a:0(0)    sid:619 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[236:239],v16,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17 alloc 'operands_a[28:31]'v[236:239]    s:34(35) v:238(239) a:0(0)    sid:620 operands_a[28:31],load_a[3:3],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'src0_gprs's17    s:35(35) v:238(239) a:0(0)    sid:621 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'src0_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:622 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v8,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:623 staging_b[4:7],load_b[2:2],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:24576 ; # gemm_fp8_gfx942.py:161   sid:624 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:24576 ; # gemm_fp8_gfx942.py:161   sid:625 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:26624 ; # gemm_fp8_gfx942.py:161   sid:626 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:26624 ; # gemm_fp8_gfx942.py:161   sid:627 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:28672 ; # gemm_fp8_gfx942.py:161   sid:628 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:28672 ; # gemm_fp8_gfx942.py:161   sid:629 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:30720 ; # gemm_fp8_gfx942.py:161   sid:630 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 30720].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:30720 ; # gemm_fp8_gfx942.py:161   sid:631 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 30720].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:632 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:633 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:634 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:635 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:636 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s21,v162  ; # gemm_fp8_gfx942.py:185   sid:637 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v138,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:638 accum[104:104],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:639 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v139,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:640 accum[105:105],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:641 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v140,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:642 accum[106:106],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:643 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v141,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:644 accum[107:107],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:645 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v142,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:646 accum[108:108],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:647 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v143,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:648 accum[109:109],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:649 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v144,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:650 accum[110:110],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:651 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v145,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:652 accum[111:111],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:653 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v82,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:654 accum[48:48],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:655 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v83,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:656 accum[49:49],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:657 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v84,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:658 accum[50:50],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:659 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v85,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:660 accum[51:51],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:661 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v86,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:662 accum[52:52],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:663 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v87,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:664 accum[53:53],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:665 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v88,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:666 accum[54:54],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:667 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v89,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:668 accum[55:55],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:669 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s21,v163  ; # gemm_fp8_gfx942.py:185   sid:670 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v90,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:671 accum[56:56],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:672 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v91,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:673 accum[57:57],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:674 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v92,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:675 accum[58:58],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:676 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v93,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:677 accum[59:59],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:678 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v94,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:679 accum[60:60],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:680 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v95,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:681 accum[61:61],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:682 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v96,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:683 accum[62:62],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:684 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v97,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:685 accum[63:63],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:686 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v146,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:687 accum[112:112],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:688 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v147,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:689 accum[113:113],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:690 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v148,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:691 accum[114:114],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:692 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v149,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:693 accum[115:115],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:694 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v150,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:695 accum[116:116],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:696 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v151,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:697 accum[117:117],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:698 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v152,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:699 accum[118:118],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:700 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:701 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v153,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:702 accum[119:119],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:703 0,
	s_add_u32 s12,0x80,s12  ; # gemm_fp8_gfx942.py:200   sid:704 k_offset,128,k_offset,;	s12.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s5,0x2  ; # gemm_fp8_gfx942.py:201 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:705 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s13,s13,s17  ; # gemm_fp8_gfx942.py:201 free 'src1_gprs's17   sid:706 scale_offset,scale_offset,src1_gprs,;	s13.u32 = s13 + s17; scc=overflow_or_carry
_while_begin_220_2:	 ;BB#48 predecessors:[_if_else_213_1,_bb_no_name_49] successors:[_bb_no_name_49,_while_end_220_2]
	s_cmp_lt_u32 s12,0x3f80  ; # asmjit.py:1381 contextlib.py:137   sid:707 k_offset,16256,;	scc = (s12.u32 < 0x3f80.u32)
	s_cbranch_scc0  _while_end_220_2 ; # asmjit.py:1367 asmjit.py:1381 contextlib.py:137   sid:708;	jump if scc is 0 (scc == 0)
_bb_no_name_49:	 ;BB#49 predecessors:[_while_begin_220_2] successors:[_while_begin_220_2]
	s_waitcnt  vmcnt(1) ; # gemm_fp8_gfx942.py:149   sid:709 
	ds_write_b128 v2,v[164:167] offset:8192 ; # gemm_fp8_gfx942.py:150   sid:710 write_b,staging_b[0:3],;	LDS_MEM[v2 + 8192].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:711 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[168:171],v15,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17   sid:712 operands_a[0:3],load_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:713 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:714 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v162,v11,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'idst's17   sid:715 scale_a[0:0],load_scale_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:716 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v3,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:717 staging_b[0:3],load_b[3:3],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:0 ; # gemm_fp8_gfx942.py:161   sid:718 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:0 ; # gemm_fp8_gfx942.py:161   sid:719 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:2048 ; # gemm_fp8_gfx942.py:161   sid:720 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:2048 ; # gemm_fp8_gfx942.py:161   sid:721 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:4096 ; # gemm_fp8_gfx942.py:161   sid:722 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:4096 ; # gemm_fp8_gfx942.py:161   sid:723 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:6144 ; # gemm_fp8_gfx942.py:161   sid:724 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 6144].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:6144 ; # gemm_fp8_gfx942.py:161   sid:725 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 6144].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:726 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:727 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:728 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:729 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:730 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s22,v192  ; # gemm_fp8_gfx942.py:185   sid:731 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v154,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:732 accum[120:120],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:733 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v155,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:734 accum[121:121],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:735 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v156,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:736 accum[122:122],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:737 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v157,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:738 accum[123:123],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:739 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v158,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:740 accum[124:124],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:741 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v159,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:742 accum[125:125],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:743 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v160,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:744 accum[126:126],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:745 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v161,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:746 accum[127:127],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:747 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v18,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:748 accum[0:0],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:749 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v19,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:750 accum[1:1],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:751 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v36,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:752 accum[2:2],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:753 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v37,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:754 accum[3:3],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:755 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v38,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:756 accum[4:4],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:757 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v39,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:758 accum[5:5],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:759 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v40,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:760 accum[6:6],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:761 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v41,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:762 accum[7:7],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:763 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s22,v193  ; # gemm_fp8_gfx942.py:185   sid:764 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v42,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:765 accum[8:8],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:766 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v43,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:767 accum[9:9],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:768 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v44,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:769 accum[10:10],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:770 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v45,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:771 accum[11:11],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:772 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v46,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:773 accum[12:12],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:774 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v47,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:775 accum[13:13],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:776 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v48,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:777 accum[14:14],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:778 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v49,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:779 accum[15:15],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:780 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v98,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:781 accum[64:64],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:782 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v99,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:783 accum[65:65],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:784 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v100,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:785 accum[66:66],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:786 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v101,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:787 accum[67:67],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:788 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v102,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:789 accum[68:68],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:790 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v103,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:791 accum[69:69],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:792 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v104,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:793 accum[70:70],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:794 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:795 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v105,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:796 accum[71:71],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:797 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:149   sid:798 
	ds_write_b128 v2,v[184:187] offset:16384 ; # gemm_fp8_gfx942.py:150   sid:799 write_b,staging_b[4:7],;	LDS_MEM[v2 + 16384].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:800 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[176:179],v14,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17   sid:801 operands_a[8:11],load_a[2:2],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:802 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:803 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v163,v10,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'idst's17   sid:804 scale_a[1:1],load_scale_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'src0_gprs's17    s:35(35) v:238(239) a:0(0)    sid:805 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'src0_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:806 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v4,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:807 staging_b[4:7],load_b[0:0],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:8192 ; # gemm_fp8_gfx942.py:161   sid:808 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:8192 ; # gemm_fp8_gfx942.py:161   sid:809 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:10240 ; # gemm_fp8_gfx942.py:161   sid:810 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:10240 ; # gemm_fp8_gfx942.py:161   sid:811 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:12288 ; # gemm_fp8_gfx942.py:161   sid:812 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:12288 ; # gemm_fp8_gfx942.py:161   sid:813 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:14336 ; # gemm_fp8_gfx942.py:161   sid:814 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 14336].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:14336 ; # gemm_fp8_gfx942.py:161   sid:815 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 14336].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:816 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:817 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:818 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:819 
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:110 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:820 src1_gprs,k_offset,5,
	s_add_u32 s17,s6,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:821 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s6 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:822 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s20,s[14:15],s17  ; # gemm_fp8_gfx942.py:110 free 'idst's17   sid:823 scale_b,pScaleB,idst,;	s20 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:110 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:824 src1_gprs,k_offset,5,
	s_add_u32 s17,s7,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:825 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s7 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:826 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s21,s[14:15],s17  ; # gemm_fp8_gfx942.py:110 free 'idst's17   sid:827 scale_b,pScaleB,idst,;	s21 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:828 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s22,v192  ; # gemm_fp8_gfx942.py:185   sid:829 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v106,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:830 accum[72:72],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:831 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v107,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:832 accum[73:73],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:833 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v108,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:834 accum[74:74],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:835 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v109,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:836 accum[75:75],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:837 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v110,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:838 accum[76:76],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:839 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v111,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:840 accum[77:77],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:841 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v112,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:842 accum[78:78],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:843 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v113,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:844 accum[79:79],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:845 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v50,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:846 accum[16:16],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:847 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v51,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:848 accum[17:17],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:849 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v52,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:850 accum[18:18],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:851 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v53,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:852 accum[19:19],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:853 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v54,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:854 accum[20:20],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:855 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v55,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:856 accum[21:21],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:857 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v56,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:858 accum[22:22],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:859 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v57,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:860 accum[23:23],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:861 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s22,v193  ; # gemm_fp8_gfx942.py:185   sid:862 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v58,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:863 accum[24:24],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:864 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v59,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:865 accum[25:25],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:866 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v60,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:867 accum[26:26],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:868 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v61,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:869 accum[27:27],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:870 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v62,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:871 accum[28:28],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:872 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v63,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:873 accum[29:29],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:874 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v64,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:875 accum[30:30],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:876 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v65,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:877 accum[31:31],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:878 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v114,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:879 accum[80:80],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:880 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v115,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:881 accum[81:81],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:882 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v116,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:883 accum[82:82],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:884 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v117,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:885 accum[83:83],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:886 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v118,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:887 accum[84:84],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:888 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v119,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:889 accum[85:85],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:890 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v120,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:891 accum[86:86],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:892 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:893 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v121,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:894 accum[87:87],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:895 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:149   sid:896 
	ds_write_b128 v2,v[164:167] offset:24576 ; # gemm_fp8_gfx942.py:150   sid:897 write_b,staging_b[0:3],;	LDS_MEM[v2 + 24576].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:898 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[172:175],v12,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17   sid:899 operands_a[4:7],load_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'src0_gprs's17    s:35(35) v:238(239) a:0(0)    sid:900 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'src0_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:901 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v7,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:902 staging_b[0:3],load_b[1:1],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:16384 ; # gemm_fp8_gfx942.py:161   sid:903 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:16384 ; # gemm_fp8_gfx942.py:161   sid:904 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:18432 ; # gemm_fp8_gfx942.py:161   sid:905 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:18432 ; # gemm_fp8_gfx942.py:161   sid:906 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:20480 ; # gemm_fp8_gfx942.py:161   sid:907 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:20480 ; # gemm_fp8_gfx942.py:161   sid:908 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:22528 ; # gemm_fp8_gfx942.py:161   sid:909 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 22528].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:22528 ; # gemm_fp8_gfx942.py:161   sid:910 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 22528].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:911 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:912 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:913 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:914 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:915 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s23,v192  ; # gemm_fp8_gfx942.py:185   sid:916 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v122,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:917 accum[88:88],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:918 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v123,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:919 accum[89:89],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:920 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v124,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:921 accum[90:90],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:922 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v125,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:923 accum[91:91],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:924 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v126,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:925 accum[92:92],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:926 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v127,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:927 accum[93:93],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:928 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v128,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:929 accum[94:94],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:930 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v129,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:931 accum[95:95],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:932 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v66,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:933 accum[32:32],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:934 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v67,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:935 accum[33:33],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:936 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v68,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:937 accum[34:34],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:938 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v69,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:939 accum[35:35],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:940 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v70,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:941 accum[36:36],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:942 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v71,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:943 accum[37:37],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:944 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v72,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:945 accum[38:38],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:946 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v73,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:947 accum[39:39],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:948 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s23,v193  ; # gemm_fp8_gfx942.py:185   sid:949 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v74,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:950 accum[40:40],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:951 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v75,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:952 accum[41:41],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:953 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v76,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:954 accum[42:42],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:955 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v77,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:956 accum[43:43],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:957 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v78,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:958 accum[44:44],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:959 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v79,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:960 accum[45:45],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:961 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v80,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:962 accum[46:46],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:963 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v81,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:964 accum[47:47],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:965 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v130,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:966 accum[96:96],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:967 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v131,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:968 accum[97:97],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:969 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v132,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:970 accum[98:98],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:971 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v133,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:972 accum[99:99],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:973 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v134,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:974 accum[100:100],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:975 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v135,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:976 accum[101:101],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:977 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v136,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:978 accum[102:102],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:979 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:980 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v137,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:981 accum[103:103],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:982 0,
	s_waitcnt  vmcnt(2) ; # gemm_fp8_gfx942.py:149   sid:983 
	ds_write_b128 v2,v[184:187] offset:0 ; # gemm_fp8_gfx942.py:150   sid:984 write_b,staging_b[4:7],;	LDS_MEM[v2 + 0].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:985 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[180:183],v16,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17   sid:986 operands_a[12:15],load_a[3:3],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'src0_gprs's17    s:35(35) v:238(239) a:0(0)    sid:987 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'src0_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:988 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v8,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:989 staging_b[4:7],load_b[2:2],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:24576 ; # gemm_fp8_gfx942.py:161   sid:990 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:24576 ; # gemm_fp8_gfx942.py:161   sid:991 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:26624 ; # gemm_fp8_gfx942.py:161   sid:992 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:26624 ; # gemm_fp8_gfx942.py:161   sid:993 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:28672 ; # gemm_fp8_gfx942.py:161   sid:994 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:28672 ; # gemm_fp8_gfx942.py:161   sid:995 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:30720 ; # gemm_fp8_gfx942.py:161   sid:996 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 30720].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:30720 ; # gemm_fp8_gfx942.py:161   sid:997 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 30720].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:998 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:999 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:1000 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:1001 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1002 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s23,v192  ; # gemm_fp8_gfx942.py:185   sid:1003 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v138,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:1004 accum[104:104],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1005 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v139,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:1006 accum[105:105],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1007 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v140,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:1008 accum[106:106],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1009 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v141,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:1010 accum[107:107],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1011 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v142,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:1012 accum[108:108],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1013 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v143,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:1014 accum[109:109],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1015 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v144,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:1016 accum[110:110],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1017 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v145,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:1018 accum[111:111],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1019 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v82,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:1020 accum[48:48],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1021 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v83,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:1022 accum[49:49],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1023 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v84,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:1024 accum[50:50],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1025 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v85,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:1026 accum[51:51],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1027 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v86,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:1028 accum[52:52],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1029 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v87,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:1030 accum[53:53],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1031 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v88,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:1032 accum[54:54],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1033 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v89,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:1034 accum[55:55],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1035 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s23,v193  ; # gemm_fp8_gfx942.py:185   sid:1036 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v90,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:1037 accum[56:56],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1038 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v91,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:1039 accum[57:57],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1040 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v92,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:1041 accum[58:58],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1042 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v93,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:1043 accum[59:59],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1044 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v94,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:1045 accum[60:60],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1046 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v95,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:1047 accum[61:61],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1048 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v96,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:1049 accum[62:62],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1050 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v97,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:1051 accum[63:63],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1052 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v146,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:1053 accum[112:112],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1054 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v147,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:1055 accum[113:113],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1056 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v148,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:1057 accum[114:114],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1058 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v149,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:1059 accum[115:115],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1060 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v150,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:1061 accum[116:116],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1062 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v151,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:1063 accum[117:117],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1064 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v152,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:1065 accum[118:118],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:1066 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1067 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v153,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:1068 accum[119:119],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:1069 0,
	s_add_u32 s12,0x80,s12  ; # gemm_fp8_gfx942.py:200   sid:1070 k_offset,128,k_offset,;	s12.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s5,0x2  ; # gemm_fp8_gfx942.py:201 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1071 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s13,s13,s17  ; # gemm_fp8_gfx942.py:201 free 'src1_gprs's17   sid:1072 scale_offset,scale_offset,src1_gprs,;	s13.u32 = s13 + s17; scc=overflow_or_carry
	s_waitcnt  vmcnt(1) ; # gemm_fp8_gfx942.py:149   sid:1073 
	ds_write_b128 v2,v[164:167] offset:8192 ; # gemm_fp8_gfx942.py:150   sid:1074 write_b,staging_b[0:3],;	LDS_MEM[v2 + 8192].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1075 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[188:191],v15,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17   sid:1076 operands_a[16:19],load_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1077 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1078 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v192,v11,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'idst's17   sid:1079 scale_a[2:2],load_scale_a[0:0],self.desc,idst,
	s_lshl_b32 s17,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1080 idst,k_offset,4,;	s17 = s12 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v3,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:1081 staging_b[0:3],load_b[3:3],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:0 ; # gemm_fp8_gfx942.py:161   sid:1082 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:0 ; # gemm_fp8_gfx942.py:161   sid:1083 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:2048 ; # gemm_fp8_gfx942.py:161   sid:1084 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:2048 ; # gemm_fp8_gfx942.py:161   sid:1085 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:4096 ; # gemm_fp8_gfx942.py:161   sid:1086 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:4096 ; # gemm_fp8_gfx942.py:161   sid:1087 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:6144 ; # gemm_fp8_gfx942.py:161   sid:1088 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 6144].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:6144 ; # gemm_fp8_gfx942.py:161   sid:1089 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 6144].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:1090 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:1091 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:1092 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:1093 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1094 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s20,v162  ; # gemm_fp8_gfx942.py:185   sid:1095 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v154,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:1096 accum[120:120],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1097 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v155,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:1098 accum[121:121],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1099 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v156,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:1100 accum[122:122],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1101 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v157,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:1102 accum[123:123],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1103 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v158,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:1104 accum[124:124],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1105 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v159,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:1106 accum[125:125],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1107 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v160,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:1108 accum[126:126],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1109 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v161,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:1110 accum[127:127],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1111 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v18,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:1112 accum[0:0],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1113 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v19,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:1114 accum[1:1],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1115 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v36,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:1116 accum[2:2],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1117 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v37,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:1118 accum[3:3],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1119 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v38,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:1120 accum[4:4],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1121 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v39,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:1122 accum[5:5],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1123 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v40,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:1124 accum[6:6],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1125 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v41,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:1126 accum[7:7],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1127 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s20,v163  ; # gemm_fp8_gfx942.py:185   sid:1128 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v42,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:1129 accum[8:8],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1130 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v43,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:1131 accum[9:9],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1132 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v44,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:1133 accum[10:10],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1134 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v45,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:1135 accum[11:11],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1136 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v46,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:1137 accum[12:12],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1138 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v47,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:1139 accum[13:13],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1140 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v48,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:1141 accum[14:14],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1142 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v49,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:1143 accum[15:15],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1144 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v98,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:1145 accum[64:64],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1146 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v99,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:1147 accum[65:65],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1148 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v100,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:1149 accum[66:66],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1150 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v101,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:1151 accum[67:67],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1152 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v102,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:1153 accum[68:68],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1154 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v103,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:1155 accum[69:69],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1156 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v104,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:1157 accum[70:70],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:1158 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1159 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v105,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:1160 accum[71:71],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:1161 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:149   sid:1162 
	ds_write_b128 v2,v[184:187] offset:16384 ; # gemm_fp8_gfx942.py:150   sid:1163 write_b,staging_b[4:7],;	LDS_MEM[v2 + 16384].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1164 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[228:231],v14,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17   sid:1165 operands_a[24:27],load_a[2:2],self.desc,idst,
	s_lshl_b32 s17,s5,0x2  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1166 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s17,s13,s17  ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1167 idst,scale_offset,src1_gprs,;	s17.u32 = s13 + s17; scc=overflow_or_carry
	buffer_load_dword v193,v10,s[8:11],s17 offen ; # asmjit.py:819 gemm_fp8_gfx942.py:99 free 'idst's17   sid:1168 scale_a[3:3],load_scale_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'src0_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1169 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'src0_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1170 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v4,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:1171 staging_b[4:7],load_b[0:0],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:8192 ; # gemm_fp8_gfx942.py:161   sid:1172 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:8192 ; # gemm_fp8_gfx942.py:161   sid:1173 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:10240 ; # gemm_fp8_gfx942.py:161   sid:1174 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:10240 ; # gemm_fp8_gfx942.py:161   sid:1175 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:12288 ; # gemm_fp8_gfx942.py:161   sid:1176 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:12288 ; # gemm_fp8_gfx942.py:161   sid:1177 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:14336 ; # gemm_fp8_gfx942.py:161   sid:1178 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 14336].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:14336 ; # gemm_fp8_gfx942.py:161   sid:1179 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 14336].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:1180 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:1181 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:1182 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:1183 
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:110 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1184 src1_gprs,k_offset,5,
	s_add_u32 s17,s6,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1185 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s6 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1186 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s22,s[14:15],s17  ; # gemm_fp8_gfx942.py:110 free 'idst's17   sid:1187 scale_b,pScaleB,idst,;	s22 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	s_lshr_b32 s17,s12,0x5  ; # gemm_fp8_gfx942.py:110 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1188 src1_gprs,k_offset,5,
	s_add_u32 s17,s7,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1189 src1_gprs,scale_offset_b,src1_gprs,;	s17.u32 = s7 + s17; scc=overflow_or_carry
	s_add_u32 s17,0x4,s17  ; # gemm_fp8_gfx942.py:110 free 'src1_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1190 idst,4,src1_gprs,;	s17.u32 = 0x4 + s17; scc=overflow_or_carry
	s_load_dword s23,s[14:15],s17  ; # gemm_fp8_gfx942.py:110 free 'idst's17   sid:1191 scale_b,pScaleB,idst,;	s23 = load_dword_from(s[14:15] + s17, glc=0);  // 8.2.1.1. Scalar Memory Addressing
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1192 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s20,v162  ; # gemm_fp8_gfx942.py:185   sid:1193 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v106,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:1194 accum[72:72],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1195 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v107,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:1196 accum[73:73],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1197 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v108,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:1198 accum[74:74],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1199 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v109,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:1200 accum[75:75],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1201 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v110,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:1202 accum[76:76],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1203 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v111,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:1204 accum[77:77],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1205 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v112,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:1206 accum[78:78],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1207 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v113,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:1208 accum[79:79],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1209 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v50,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:1210 accum[16:16],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1211 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v51,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:1212 accum[17:17],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1213 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v52,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:1214 accum[18:18],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1215 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v53,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:1216 accum[19:19],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1217 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v54,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:1218 accum[20:20],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1219 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v55,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:1220 accum[21:21],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1221 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v56,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:1222 accum[22:22],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1223 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v57,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:1224 accum[23:23],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1225 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s20,v163  ; # gemm_fp8_gfx942.py:185   sid:1226 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v58,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:1227 accum[24:24],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1228 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v59,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:1229 accum[25:25],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1230 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v60,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:1231 accum[26:26],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1232 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v61,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:1233 accum[27:27],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1234 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v62,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:1235 accum[28:28],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1236 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v63,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:1237 accum[29:29],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1238 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v64,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:1239 accum[30:30],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1240 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v65,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:1241 accum[31:31],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1242 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v114,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:1243 accum[80:80],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1244 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v115,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:1245 accum[81:81],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1246 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v116,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:1247 accum[82:82],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1248 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v117,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:1249 accum[83:83],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1250 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v118,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:1251 accum[84:84],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1252 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v119,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:1253 accum[85:85],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1254 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v120,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:1255 accum[86:86],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:1256 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1257 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v121,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:1258 accum[87:87],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:1259 0,
	s_waitcnt  vmcnt(3) ; # gemm_fp8_gfx942.py:149   sid:1260 
	ds_write_b128 v2,v[164:167] offset:24576 ; # gemm_fp8_gfx942.py:150   sid:1261 write_b,staging_b[0:3],;	LDS_MEM[v2 + 24576].b128 = v[164:167].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1262 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[232:235],v12,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17   sid:1263 operands_a[20:23],load_a[1:1],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'src0_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1264 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'src0_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1265 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[164:167],v7,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:1266 staging_b[0:3],load_b[1:1],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:16384 ; # gemm_fp8_gfx942.py:161   sid:1267 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:16384 ; # gemm_fp8_gfx942.py:161   sid:1268 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:18432 ; # gemm_fp8_gfx942.py:161   sid:1269 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:18432 ; # gemm_fp8_gfx942.py:161   sid:1270 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:20480 ; # gemm_fp8_gfx942.py:161   sid:1271 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:20480 ; # gemm_fp8_gfx942.py:161   sid:1272 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:22528 ; # gemm_fp8_gfx942.py:161   sid:1273 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 22528].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:22528 ; # gemm_fp8_gfx942.py:161   sid:1274 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 22528].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:1275 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:1276 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:1277 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:1278 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1279 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s21,v162  ; # gemm_fp8_gfx942.py:185   sid:1280 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v122,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:1281 accum[88:88],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1282 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v123,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:1283 accum[89:89],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1284 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v124,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:1285 accum[90:90],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1286 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v125,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:1287 accum[91:91],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1288 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v126,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:1289 accum[92:92],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1290 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v127,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:1291 accum[93:93],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1292 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v128,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:1293 accum[94:94],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1294 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v129,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:1295 accum[95:95],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1296 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v66,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:1297 accum[32:32],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1298 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v67,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:1299 accum[33:33],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1300 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v68,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:1301 accum[34:34],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1302 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v69,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:1303 accum[35:35],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1304 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v70,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:1305 accum[36:36],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1306 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v71,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:1307 accum[37:37],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1308 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v72,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:1309 accum[38:38],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1310 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v73,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:1311 accum[39:39],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1312 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s21,v163  ; # gemm_fp8_gfx942.py:185   sid:1313 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v74,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:1314 accum[40:40],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1315 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v75,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:1316 accum[41:41],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1317 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v76,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:1318 accum[42:42],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1319 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v77,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:1320 accum[43:43],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1321 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v78,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:1322 accum[44:44],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1323 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v79,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:1324 accum[45:45],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1325 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v80,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:1326 accum[46:46],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1327 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v81,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:1328 accum[47:47],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1329 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v130,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:1330 accum[96:96],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1331 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v131,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:1332 accum[97:97],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1333 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v132,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:1334 accum[98:98],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1335 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v133,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:1336 accum[99:99],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1337 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v134,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:1338 accum[100:100],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1339 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v135,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:1340 accum[101:101],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1341 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v136,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:1342 accum[102:102],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:1343 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1344 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v137,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:1345 accum[103:103],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:1346 0,
	s_waitcnt  vmcnt(2) ; # gemm_fp8_gfx942.py:149   sid:1347 
	ds_write_b128 v2,v[184:187] offset:0 ; # gemm_fp8_gfx942.py:150   sid:1348 write_b,staging_b[4:7],;	LDS_MEM[v2 + 0].b128 = v[184:187].b128
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:103 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1349 idst,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	buffer_load_dwordx4 v[236:239],v16,s[24:27],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:103 free 'idst's17   sid:1350 operands_a[28:31],load_a[3:3],self.desc,idst,
	s_add_u32 s17,0x80,s12  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'src0_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1351 src0_gprs,128,k_offset,;	s17.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s17,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'src0_gprs's17 alloc 'idst's17    s:35(35) v:238(239) a:0(0)    sid:1352 idst,src0_gprs,4,;	s17 = s17 << 0x4[4:0]; scc=(s17!=0);
	buffer_load_dwordx4 v[184:187],v8,s[28:31],s17 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's17   sid:1353 staging_b[4:7],load_b[2:2],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:24576 ; # gemm_fp8_gfx942.py:161   sid:1354 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:24576 ; # gemm_fp8_gfx942.py:161   sid:1355 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:26624 ; # gemm_fp8_gfx942.py:161   sid:1356 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:26624 ; # gemm_fp8_gfx942.py:161   sid:1357 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:28672 ; # gemm_fp8_gfx942.py:161   sid:1358 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:28672 ; # gemm_fp8_gfx942.py:161   sid:1359 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:30720 ; # gemm_fp8_gfx942.py:161   sid:1360 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 30720].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:30720 ; # gemm_fp8_gfx942.py:161   sid:1361 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 30720].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:1362 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:1363 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:1364 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:1365 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1366 partial[0:3],operands_b[0:3],operands_a[0:3],0,
	v_mul_f32 v6,s21,v162  ; # gemm_fp8_gfx942.py:185   sid:1367 partial_scale[0:0],scale_b,scale_a[0:0],
	v_fmac_f32 v138,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:1368 accum[104:104],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1369 partial[4:7],operands_b[8:11],operands_a[0:3],0,
	v_fmac_f32 v139,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:1370 accum[105:105],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[170:171],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1371 partial[0:3],operands_b[0:3],operands_a[0:3],partial[0:3],
	v_fmac_f32 v140,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:1372 accum[106:106],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[170:171],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1373 partial[4:7],operands_b[8:11],operands_a[0:3],partial[4:7],
	v_fmac_f32 v141,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:1374 accum[107:107],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[172:173],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1375 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v142,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:1376 accum[108:108],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[172:173],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1377 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v143,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:1378 accum[109:109],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[174:175],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1379 partial[0:3],operands_b[4:7],operands_a[4:7],partial[0:3],
	v_fmac_f32 v144,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:1380 accum[110:110],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[174:175],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1381 partial[4:7],operands_b[12:15],operands_a[4:7],partial[4:7],
	v_fmac_f32 v145,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:1382 accum[111:111],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1383 partial[8:11],operands_b[16:19],operands_a[0:3],0,
	v_fmac_f32 v82,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:1384 accum[48:48],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[168:169],0x0  ; # gemm_fp8_gfx942.py:178   sid:1385 partial[12:15],operands_b[24:27],operands_a[0:3],0,
	v_fmac_f32 v83,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:1386 accum[49:49],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[170:171],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1387 partial[8:11],operands_b[16:19],operands_a[0:3],partial[8:11],
	v_fmac_f32 v84,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:1388 accum[50:50],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[170:171],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1389 partial[12:15],operands_b[24:27],operands_a[0:3],partial[12:15],
	v_fmac_f32 v85,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:1390 accum[51:51],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[172:173],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1391 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v86,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:1392 accum[52:52],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[172:173],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1393 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v87,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:1394 accum[53:53],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[174:175],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1395 partial[8:11],operands_b[20:23],operands_a[4:7],partial[8:11],
	v_fmac_f32 v88,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:1396 accum[54:54],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[174:175],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1397 partial[12:15],operands_b[28:31],operands_a[4:7],partial[12:15],
	v_fmac_f32 v89,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:1398 accum[55:55],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1399 partial[0:3],operands_b[0:3],operands_a[8:11],0,
	v_mul_f32 v17,s21,v163  ; # gemm_fp8_gfx942.py:185   sid:1400 partial_scale[1:1],scale_b,scale_a[1:1],
	v_fmac_f32 v90,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:1401 accum[56:56],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1402 partial[4:7],operands_b[8:11],operands_a[8:11],0,
	v_fmac_f32 v91,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:1403 accum[57:57],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[178:179],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1404 partial[0:3],operands_b[0:3],operands_a[8:11],partial[0:3],
	v_fmac_f32 v92,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:1405 accum[58:58],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[178:179],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1406 partial[4:7],operands_b[8:11],operands_a[8:11],partial[4:7],
	v_fmac_f32 v93,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:1407 accum[59:59],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[180:181],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1408 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v94,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:1409 accum[60:60],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[180:181],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1410 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v95,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:1411 accum[61:61],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[182:183],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1412 partial[0:3],operands_b[4:7],operands_a[12:15],partial[0:3],
	v_fmac_f32 v96,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:1413 accum[62:62],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[182:183],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1414 partial[4:7],operands_b[12:15],operands_a[12:15],partial[4:7],
	v_fmac_f32 v97,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:1415 accum[63:63],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1416 partial[8:11],operands_b[16:19],operands_a[8:11],0,
	v_fmac_f32 v146,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:1417 accum[112:112],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[176:177],0x0  ; # gemm_fp8_gfx942.py:178   sid:1418 partial[12:15],operands_b[24:27],operands_a[8:11],0,
	v_fmac_f32 v147,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:1419 accum[113:113],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[178:179],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1420 partial[8:11],operands_b[16:19],operands_a[8:11],partial[8:11],
	v_fmac_f32 v148,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:1421 accum[114:114],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[178:179],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1422 partial[12:15],operands_b[24:27],operands_a[8:11],partial[12:15],
	v_fmac_f32 v149,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:1423 accum[115:115],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[180:181],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1424 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v150,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:1425 accum[116:116],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[180:181],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1426 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v151,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:1427 accum[117:117],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[182:183],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1428 partial[8:11],operands_b[20:23],operands_a[12:15],partial[8:11],
	v_fmac_f32 v152,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:1429 accum[118:118],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:1430 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[182:183],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1431 partial[12:15],operands_b[28:31],operands_a[12:15],partial[12:15],
	v_fmac_f32 v153,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:1432 accum[119:119],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:1433 0,
	s_add_u32 s12,0x80,s12  ; # gemm_fp8_gfx942.py:200   sid:1434 k_offset,128,k_offset,;	s12.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s17,s5,0x2  ; # gemm_fp8_gfx942.py:201 alloc 'src1_gprs's17    s:35(35) v:238(239) a:0(0)    sid:1435 src1_gprs,M,2,;	s17 = s5 << 0x2[4:0]; scc=(s17!=0);
	s_add_u32 s13,s13,s17  ; # gemm_fp8_gfx942.py:201 free 'src1_gprs's17   sid:1436 scale_offset,scale_offset,src1_gprs,;	s13.u32 = s13 + s17; scc=overflow_or_carry
	s_branch  _while_begin_220_2 ; # asmjit.py:1341 asmjit.py:1386 contextlib.py:144 free 'pScaleB's[14:15] free 'self.desc's[24:27] free 'self.desc's[8:11] free 'scale_offset_b's[6:7] free 'load_b[0:0]'v4 free 'load_b[1:1]'v7 free 'load_b[2:2]'v8 free 'load_scale_a[0:0]'v11 free 'load_scale_a[1:1]'v10 free 'load_a[0:0]'v15 free 'load_a[2:2]'v14 free 'load_a[1:1]'v12 free 'load_a[3:3]'v16 free 'scale_a[0:0]'v162 free 'scale_a[1:1]'v163 free 'operands_a[0:3]'v[168:171] free 'operands_a[4:7]'v[172:175] free 'operands_a[8:11]'v[176:179] free 'operands_a[12:15]'v[180:183]   sid:1437 
_while_end_220_2:	 ;BB#51 predecessors:[_while_begin_220_2] successors:[_bb_no_name_52,_if_else_234_3]
	s_waitcnt  vmcnt(1) ; # gemm_fp8_gfx942.py:149   sid:1438 
	ds_write_b128 v2,v[164:167] offset:8192 ; # gemm_fp8_gfx942.py:150   sid:1439 write_b,staging_b[0:3],;	LDS_MEM[v2 + 8192].b128 = v[164:167].b128
	s_lshl_b32 s6,s12,0x4  ; # asmjit.py:799 gemm_fp8_gfx942.py:116 alloc 'idst's6    s:23(35) v:211(239) a:0(0)    sid:1440 idst,k_offset,4,;	s6 = s12 << 0x4[4:0]; scc=(s6!=0);
	buffer_load_dwordx4 v[164:167],v3,s[28:31],s6 offen ; # asmjit.py:799 gemm_fp8_gfx942.py:116 free 'idst's6 free 'self.desc's[28:31] free 'load_b[3:3]'v3   sid:1441 staging_b[0:3],load_b[3:3],self.desc,idst,
	ds_read_b128 v[196:199],v13 offset:0 ; # gemm_fp8_gfx942.py:161   sid:1442 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:0 ; # gemm_fp8_gfx942.py:161   sid:1443 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 0].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:2048 ; # gemm_fp8_gfx942.py:161   sid:1444 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:2048 ; # gemm_fp8_gfx942.py:161   sid:1445 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 2048].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:4096 ; # gemm_fp8_gfx942.py:161   sid:1446 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:4096 ; # gemm_fp8_gfx942.py:161   sid:1447 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 4096].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:6144 ; # gemm_fp8_gfx942.py:161   sid:1448 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 6144].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:6144 ; # gemm_fp8_gfx942.py:161   sid:1449 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 6144].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:1450 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:1451 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:1452 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:1453 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1454 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s22,v192  ; # gemm_fp8_gfx942.py:185   sid:1455 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v154,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:1456 accum[120:120],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1457 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v155,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:1458 accum[121:121],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1459 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v156,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:1460 accum[122:122],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1461 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v157,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:1462 accum[123:123],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1463 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v158,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:1464 accum[124:124],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1465 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v159,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:1466 accum[125:125],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1467 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v160,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:1468 accum[126:126],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1469 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v161,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:1470 accum[127:127],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1471 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v18,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:1472 accum[0:0],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1473 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v19,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:1474 accum[1:1],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1475 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v36,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:1476 accum[2:2],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1477 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v37,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:1478 accum[3:3],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1479 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v38,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:1480 accum[4:4],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1481 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v39,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:1482 accum[5:5],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1483 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v40,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:1484 accum[6:6],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1485 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v41,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:1486 accum[7:7],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1487 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s22,v193  ; # gemm_fp8_gfx942.py:185   sid:1488 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v42,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:1489 accum[8:8],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1490 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v43,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:1491 accum[9:9],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1492 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v44,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:1493 accum[10:10],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1494 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v45,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:1495 accum[11:11],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1496 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v46,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:1497 accum[12:12],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1498 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v47,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:1499 accum[13:13],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1500 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v48,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:1501 accum[14:14],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1502 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v49,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:1503 accum[15:15],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1504 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v98,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:1505 accum[64:64],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1506 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v99,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:1507 accum[65:65],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1508 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v100,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:1509 accum[66:66],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1510 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v101,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:1511 accum[67:67],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1512 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v102,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:1513 accum[68:68],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1514 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v103,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:1515 accum[69:69],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1516 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v104,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:1517 accum[70:70],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:1518 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1519 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v105,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:1520 accum[71:71],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:1521 0,
	s_waitcnt  vmcnt(1) ; # gemm_fp8_gfx942.py:149   sid:1522 
	ds_write_b128 v2,v[184:187] offset:16384 ; # gemm_fp8_gfx942.py:150 free 'staging_b[4:7]'v[184:187]   sid:1523 write_b,staging_b[4:7],;	LDS_MEM[v2 + 16384].b128 = v[184:187].b128
	ds_read_b128 v[196:199],v13 offset:8192 ; # gemm_fp8_gfx942.py:161   sid:1524 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:8192 ; # gemm_fp8_gfx942.py:161   sid:1525 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 8192].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:10240 ; # gemm_fp8_gfx942.py:161   sid:1526 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:10240 ; # gemm_fp8_gfx942.py:161   sid:1527 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 10240].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:12288 ; # gemm_fp8_gfx942.py:161   sid:1528 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:12288 ; # gemm_fp8_gfx942.py:161   sid:1529 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 12288].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:14336 ; # gemm_fp8_gfx942.py:161   sid:1530 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 14336].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:14336 ; # gemm_fp8_gfx942.py:161   sid:1531 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 14336].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:1532 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:1533 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:1534 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:1535 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1536 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s22,v192  ; # gemm_fp8_gfx942.py:185   sid:1537 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v106,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:1538 accum[72:72],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1539 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v107,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:1540 accum[73:73],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1541 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v108,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:1542 accum[74:74],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1543 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v109,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:1544 accum[75:75],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1545 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v110,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:1546 accum[76:76],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1547 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v111,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:1548 accum[77:77],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1549 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v112,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:1550 accum[78:78],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1551 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v113,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:1552 accum[79:79],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1553 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v50,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:1554 accum[16:16],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1555 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v51,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:1556 accum[17:17],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1557 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v52,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:1558 accum[18:18],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1559 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v53,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:1560 accum[19:19],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1561 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v54,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:1562 accum[20:20],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1563 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v55,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:1564 accum[21:21],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1565 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v56,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:1566 accum[22:22],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1567 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v57,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:1568 accum[23:23],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1569 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s22,v193  ; # gemm_fp8_gfx942.py:185   sid:1570 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v58,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:1571 accum[24:24],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1572 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v59,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:1573 accum[25:25],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1574 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v60,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:1575 accum[26:26],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1576 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v61,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:1577 accum[27:27],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1578 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v62,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:1579 accum[28:28],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1580 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v63,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:1581 accum[29:29],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1582 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v64,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:1583 accum[30:30],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1584 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v65,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:1585 accum[31:31],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1586 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v114,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:1587 accum[80:80],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1588 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v115,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:1589 accum[81:81],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1590 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v116,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:1591 accum[82:82],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1592 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v117,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:1593 accum[83:83],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1594 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v118,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:1595 accum[84:84],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1596 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v119,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:1597 accum[85:85],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1598 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v120,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:1599 accum[86:86],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:1600 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1601 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v121,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:1602 accum[87:87],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:1603 0,
	s_waitcnt  vmcnt(0) ; # gemm_fp8_gfx942.py:149   sid:1604 
	ds_write_b128 v2,v[164:167] offset:24576 ; # gemm_fp8_gfx942.py:150 free 'write_b'v2 free 'staging_b[0:3]'v[164:167]   sid:1605 write_b,staging_b[0:3],;	LDS_MEM[v2 + 24576].b128 = v[164:167].b128
	ds_read_b128 v[196:199],v13 offset:16384 ; # gemm_fp8_gfx942.py:161   sid:1606 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:16384 ; # gemm_fp8_gfx942.py:161   sid:1607 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 16384].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:18432 ; # gemm_fp8_gfx942.py:161   sid:1608 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:18432 ; # gemm_fp8_gfx942.py:161   sid:1609 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 18432].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:20480 ; # gemm_fp8_gfx942.py:161   sid:1610 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:20480 ; # gemm_fp8_gfx942.py:161   sid:1611 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 20480].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:22528 ; # gemm_fp8_gfx942.py:161   sid:1612 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 22528].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:22528 ; # gemm_fp8_gfx942.py:161   sid:1613 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 22528].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:1614 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:1615 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:1616 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:1617 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1618 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s23,v192  ; # gemm_fp8_gfx942.py:185   sid:1619 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v122,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:1620 accum[88:88],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1621 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v123,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:1622 accum[89:89],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1623 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v124,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:1624 accum[90:90],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1625 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v125,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:1626 accum[91:91],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1627 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v126,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:1628 accum[92:92],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1629 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v127,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:1630 accum[93:93],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1631 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v128,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:1632 accum[94:94],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1633 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v129,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:1634 accum[95:95],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1635 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v66,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:1636 accum[32:32],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1637 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v67,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:1638 accum[33:33],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1639 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v68,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:1640 accum[34:34],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1641 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v69,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:1642 accum[35:35],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1643 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v70,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:1644 accum[36:36],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1645 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v71,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:1646 accum[37:37],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1647 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v72,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:1648 accum[38:38],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1649 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v73,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:1650 accum[39:39],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1651 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s23,v193  ; # gemm_fp8_gfx942.py:185   sid:1652 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v74,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:1653 accum[40:40],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1654 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v75,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:1655 accum[41:41],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1656 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v76,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:1657 accum[42:42],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1658 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v77,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:1659 accum[43:43],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1660 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v78,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:1661 accum[44:44],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1662 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v79,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:1663 accum[45:45],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1664 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v80,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:1665 accum[46:46],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1666 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v81,v35,v6  ; # gemm_fp8_gfx942.py:193   sid:1667 accum[47:47],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1668 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v130,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:1669 accum[96:96],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1670 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v131,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:1671 accum[97:97],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1672 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v132,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:1673 accum[98:98],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1674 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v133,v23,v17  ; # gemm_fp8_gfx942.py:193   sid:1675 accum[99:99],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1676 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v134,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:1677 accum[100:100],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1678 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v135,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:1679 accum[101:101],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1680 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v136,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:1681 accum[102:102],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:1682 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1683 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v137,v27,v17  ; # gemm_fp8_gfx942.py:193   sid:1684 accum[103:103],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:1685 0,
	ds_read_b128 v[196:199],v13 offset:24576 ; # gemm_fp8_gfx942.py:161   sid:1686 operands_b[0:3],read_b[0:0],;	v[196:199] = LDS_MEM[v13 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[200:203],v5 offset:24576 ; # gemm_fp8_gfx942.py:161   sid:1687 operands_b[4:7],read_b[1:1],;	v[200:203] = LDS_MEM[v5 + 24576].b128; // read w/o any type convertion
	ds_read_b128 v[204:207],v13 offset:26624 ; # gemm_fp8_gfx942.py:161   sid:1688 operands_b[8:11],read_b[0:0],;	v[204:207] = LDS_MEM[v13 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[208:211],v5 offset:26624 ; # gemm_fp8_gfx942.py:161   sid:1689 operands_b[12:15],read_b[1:1],;	v[208:211] = LDS_MEM[v5 + 26624].b128; // read w/o any type convertion
	ds_read_b128 v[212:215],v13 offset:28672 ; # gemm_fp8_gfx942.py:161   sid:1690 operands_b[16:19],read_b[0:0],;	v[212:215] = LDS_MEM[v13 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[216:219],v5 offset:28672 ; # gemm_fp8_gfx942.py:161   sid:1691 operands_b[20:23],read_b[1:1],;	v[216:219] = LDS_MEM[v5 + 28672].b128; // read w/o any type convertion
	ds_read_b128 v[220:223],v13 offset:30720 ; # gemm_fp8_gfx942.py:161 free 'read_b[0:0]'v13   sid:1692 operands_b[24:27],read_b[0:0],;	v[220:223] = LDS_MEM[v13 + 30720].b128; // read w/o any type convertion
	ds_read_b128 v[224:227],v5 offset:30720 ; # gemm_fp8_gfx942.py:161 free 'read_b[1:1]'v5   sid:1693 operands_b[28:31],read_b[1:1],;	v[224:227] = LDS_MEM[v5 + 30720].b128; // read w/o any type convertion
	s_waitcnt  lgkmcnt(8) ; # gemm_fp8_gfx942.py:165   sid:1694 
	s_barrier   ; # gemm_fp8_gfx942.py:166   sid:1695 
	s_setprio 0x3  ; # gemm_fp8_gfx942.py:167   sid:1696 3,
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:168   sid:1697 
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1698 partial[0:3],operands_b[0:3],operands_a[16:19],0,
	v_mul_f32 v6,s23,v192  ; # gemm_fp8_gfx942.py:185 free 'scale_a[2:2]'v192   sid:1699 partial_scale[0:0],scale_b,scale_a[2:2],
	v_fmac_f32 v138,v28,v17  ; # gemm_fp8_gfx942.py:193   sid:1700 accum[104:104],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1701 partial[4:7],operands_b[8:11],operands_a[16:19],0,
	v_fmac_f32 v139,v29,v17  ; # gemm_fp8_gfx942.py:193   sid:1702 accum[105:105],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[190:191],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1703 partial[0:3],operands_b[0:3],operands_a[16:19],partial[0:3],
	v_fmac_f32 v140,v30,v17  ; # gemm_fp8_gfx942.py:193   sid:1704 accum[106:106],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[190:191],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1705 partial[4:7],operands_b[8:11],operands_a[16:19],partial[4:7],
	v_fmac_f32 v141,v31,v17  ; # gemm_fp8_gfx942.py:193   sid:1706 accum[107:107],partial[8:11],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[232:233],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1707 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v142,v32,v17  ; # gemm_fp8_gfx942.py:193   sid:1708 accum[108:108],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[232:233],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1709 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v143,v33,v17  ; # gemm_fp8_gfx942.py:193   sid:1710 accum[109:109],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[234:235],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1711 partial[0:3],operands_b[4:7],operands_a[20:23],partial[0:3],
	v_fmac_f32 v144,v34,v17  ; # gemm_fp8_gfx942.py:193   sid:1712 accum[110:110],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[234:235],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1713 partial[4:7],operands_b[12:15],operands_a[20:23],partial[4:7],
	v_fmac_f32 v145,v35,v17  ; # gemm_fp8_gfx942.py:193   sid:1714 accum[111:111],partial[12:15],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1715 partial[8:11],operands_b[16:19],operands_a[16:19],0,
	v_fmac_f32 v82,v20,v6  ; # gemm_fp8_gfx942.py:193   sid:1716 accum[48:48],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[188:189],0x0  ; # gemm_fp8_gfx942.py:178   sid:1717 partial[12:15],operands_b[24:27],operands_a[16:19],0,
	v_fmac_f32 v83,v21,v6  ; # gemm_fp8_gfx942.py:193   sid:1718 accum[49:49],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[190:191],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1719 partial[8:11],operands_b[16:19],operands_a[16:19],partial[8:11],
	v_fmac_f32 v84,v22,v6  ; # gemm_fp8_gfx942.py:193   sid:1720 accum[50:50],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[190:191],v[32:35]  ; # gemm_fp8_gfx942.py:178 free 'operands_a[16:19]'v[188:191]   sid:1721 partial[12:15],operands_b[24:27],operands_a[16:19],partial[12:15],
	v_fmac_f32 v85,v23,v6  ; # gemm_fp8_gfx942.py:193   sid:1722 accum[51:51],partial[0:3],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[232:233],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1723 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v86,v24,v6  ; # gemm_fp8_gfx942.py:193   sid:1724 accum[52:52],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[232:233],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1725 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v87,v25,v6  ; # gemm_fp8_gfx942.py:193   sid:1726 accum[53:53],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[234:235],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1727 partial[8:11],operands_b[20:23],operands_a[20:23],partial[8:11],
	v_fmac_f32 v88,v26,v6  ; # gemm_fp8_gfx942.py:193   sid:1728 accum[54:54],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[234:235],v[32:35]  ; # gemm_fp8_gfx942.py:178 free 'operands_a[20:23]'v[232:235]   sid:1729 partial[12:15],operands_b[28:31],operands_a[20:23],partial[12:15],
	v_fmac_f32 v89,v27,v6  ; # gemm_fp8_gfx942.py:193   sid:1730 accum[55:55],partial[4:7],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[196:197],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1731 partial[0:3],operands_b[0:3],operands_a[24:27],0,
	v_mul_f32 v17,s23,v193  ; # gemm_fp8_gfx942.py:185 free 'scale_b's[20:23] free 'scale_a[3:3]'v193   sid:1732 partial_scale[1:1],scale_b,scale_a[3:3],
	v_fmac_f32 v90,v28,v6  ; # gemm_fp8_gfx942.py:193   sid:1733 accum[56:56],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[204:205],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1734 partial[4:7],operands_b[8:11],operands_a[24:27],0,
	v_fmac_f32 v91,v29,v6  ; # gemm_fp8_gfx942.py:193   sid:1735 accum[57:57],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[198:199],v[230:231],v[20:23]  ; # gemm_fp8_gfx942.py:178 free 'operands_b[0:3]'v[196:199]   sid:1736 partial[0:3],operands_b[0:3],operands_a[24:27],partial[0:3],
	v_fmac_f32 v92,v30,v6  ; # gemm_fp8_gfx942.py:193   sid:1737 accum[58:58],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[206:207],v[230:231],v[24:27]  ; # gemm_fp8_gfx942.py:178 free 'operands_b[8:11]'v[204:207]   sid:1738 partial[4:7],operands_b[8:11],operands_a[24:27],partial[4:7],
	v_fmac_f32 v93,v31,v6  ; # gemm_fp8_gfx942.py:193   sid:1739 accum[59:59],partial[8:11],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[200:201],v[236:237],v[20:23]  ; # gemm_fp8_gfx942.py:178   sid:1740 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v94,v32,v6  ; # gemm_fp8_gfx942.py:193   sid:1741 accum[60:60],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[208:209],v[236:237],v[24:27]  ; # gemm_fp8_gfx942.py:178   sid:1742 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v95,v33,v6  ; # gemm_fp8_gfx942.py:193   sid:1743 accum[61:61],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[20:23],v[202:203],v[238:239],v[20:23]  ; # gemm_fp8_gfx942.py:178 free 'operands_b[4:7]'v[200:203]   sid:1744 partial[0:3],operands_b[4:7],operands_a[28:31],partial[0:3],
	v_fmac_f32 v96,v34,v6  ; # gemm_fp8_gfx942.py:193   sid:1745 accum[62:62],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[24:27],v[210:211],v[238:239],v[24:27]  ; # gemm_fp8_gfx942.py:178 free 'operands_b[12:15]'v[208:211]   sid:1746 partial[4:7],operands_b[12:15],operands_a[28:31],partial[4:7],
	v_fmac_f32 v97,v35,v6  ; # gemm_fp8_gfx942.py:193 free 'partial_scale[0:0]'v6   sid:1747 accum[63:63],partial[12:15],partial_scale[0:0],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[212:213],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1748 partial[8:11],operands_b[16:19],operands_a[24:27],0,
	v_fmac_f32 v146,v20,v17  ; # gemm_fp8_gfx942.py:193   sid:1749 accum[112:112],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[220:221],v[228:229],0x0  ; # gemm_fp8_gfx942.py:178   sid:1750 partial[12:15],operands_b[24:27],operands_a[24:27],0,
	v_fmac_f32 v147,v21,v17  ; # gemm_fp8_gfx942.py:193   sid:1751 accum[113:113],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[214:215],v[230:231],v[28:31]  ; # gemm_fp8_gfx942.py:178 free 'operands_b[16:19]'v[212:215]   sid:1752 partial[8:11],operands_b[16:19],operands_a[24:27],partial[8:11],
	v_fmac_f32 v148,v22,v17  ; # gemm_fp8_gfx942.py:193   sid:1753 accum[114:114],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[222:223],v[230:231],v[32:35]  ; # gemm_fp8_gfx942.py:178 free 'operands_a[24:27]'v[228:231] free 'operands_b[24:27]'v[220:223]   sid:1754 partial[12:15],operands_b[24:27],operands_a[24:27],partial[12:15],
	v_fmac_f32 v149,v23,v17  ; # gemm_fp8_gfx942.py:193 free 'partial[0:3]'v[20:23]   sid:1755 accum[115:115],partial[0:3],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[216:217],v[236:237],v[28:31]  ; # gemm_fp8_gfx942.py:178   sid:1756 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v150,v24,v17  ; # gemm_fp8_gfx942.py:193   sid:1757 accum[116:116],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[224:225],v[236:237],v[32:35]  ; # gemm_fp8_gfx942.py:178   sid:1758 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v151,v25,v17  ; # gemm_fp8_gfx942.py:193   sid:1759 accum[117:117],partial[4:7],partial_scale[1:1],
	v_mfma_f32_16x16x32_fp8_fp8 v[28:31],v[218:219],v[238:239],v[28:31]  ; # gemm_fp8_gfx942.py:178 free 'operands_b[20:23]'v[216:219]   sid:1760 partial[8:11],operands_b[20:23],operands_a[28:31],partial[8:11],
	v_fmac_f32 v152,v26,v17  ; # gemm_fp8_gfx942.py:193   sid:1761 accum[118:118],partial[4:7],partial_scale[1:1],
	s_barrier   ; # gemm_fp8_gfx942.py:176   sid:1762 
	v_mfma_f32_16x16x32_fp8_fp8 v[32:35],v[226:227],v[238:239],v[32:35]  ; # gemm_fp8_gfx942.py:178 free 'operands_a[28:31]'v[236:239] free 'operands_b[28:31]'v[224:227]   sid:1763 partial[12:15],operands_b[28:31],operands_a[28:31],partial[12:15],
	v_fmac_f32 v153,v27,v17  ; # gemm_fp8_gfx942.py:193 free 'partial[4:7]'v[24:27]   sid:1764 accum[119:119],partial[4:7],partial_scale[1:1],
	s_setprio 0x0  ; # gemm_fp8_gfx942.py:197   sid:1765 0,
	s_add_u32 s12,0x80,s12  ; # gemm_fp8_gfx942.py:200 free 'k_offset's12   sid:1766 k_offset,128,k_offset,;	s12.u32 = 0x80 + s12; scc=overflow_or_carry
	s_lshl_b32 s5,s5,0x2  ; # gemm_fp8_gfx942.py:201 free 'M's5 alloc 'src1_gprs's5    s:13(35) v:140(161) a:0(0)    sid:1767 src1_gprs,M,2,;	s5 = s5 << 0x2[4:0]; scc=(s5!=0);
	s_add_u32 s13,s13,s5  ; # gemm_fp8_gfx942.py:201 free 'scale_offset's13 free 'src1_gprs's5   sid:1768 scale_offset,scale_offset,src1_gprs,;	s13.u32 = s13 + s5; scc=overflow_or_carry
	s_nop 0xf  ; # gemm_fp8_gfx942.py:228   sid:1769 15,;	s_nop  wait 16 cycles
	v_fmac_f32 v154,v28,v17  ; # gemm_fp8_gfx942.py:231   sid:1770 accum[120:120],partial[8:11],partial_scale[1:1],
	v_fmac_f32 v155,v29,v17  ; # gemm_fp8_gfx942.py:231   sid:1771 accum[121:121],partial[8:11],partial_scale[1:1],
	v_fmac_f32 v156,v30,v17  ; # gemm_fp8_gfx942.py:231   sid:1772 accum[122:122],partial[8:11],partial_scale[1:1],
	v_fmac_f32 v157,v31,v17  ; # gemm_fp8_gfx942.py:231 free 'partial[8:11]'v[28:31]   sid:1773 accum[123:123],partial[8:11],partial_scale[1:1],
	v_fmac_f32 v158,v32,v17  ; # gemm_fp8_gfx942.py:231   sid:1774 accum[124:124],partial[12:15],partial_scale[1:1],
	v_fmac_f32 v159,v33,v17  ; # gemm_fp8_gfx942.py:231   sid:1775 accum[125:125],partial[12:15],partial_scale[1:1],
	v_fmac_f32 v160,v34,v17  ; # gemm_fp8_gfx942.py:231   sid:1776 accum[126:126],partial[12:15],partial_scale[1:1],
	v_fmac_f32 v161,v35,v17  ; # gemm_fp8_gfx942.py:231 free 'partial_scale[1:1]'v17 free 'partial[12:15]'v[32:35]   sid:1777 accum[127:127],partial[12:15],partial_scale[1:1],
	s_cmp_eq_u32 s16,0x0  ; # asmjit.py:1421 contextlib.py:137 free 'group's16   sid:1778 group,0,;	scc = (s16.u32 == 0x0.u32)
	s_cbranch_scc0  _if_else_234_3 ; # asmjit.py:1367 asmjit.py:1421 contextlib.py:137   sid:1779;	jump if scc is 0 (scc == 0)
_bb_no_name_52:	 ;BB#52 predecessors:[_while_end_220_2] successors:[_if_else_234_3]
	s_barrier   ; # gemm_fp8_gfx942.py:235   sid:1780 
_if_else_234_3:	 ;BB#53 predecessors:[_bb_no_name_52,_while_end_220_2] successors:[_bb_no_name_54,_execmask_end_258_4]
	v_lshrrev_b32 v2,0x4,v1  ; # gemm_fp8_gfx942.py:239 alloc 'lane_group'v2    s:10(35) v:132(161) a:0(0)    sid:1781 lane_group,4,_lane_id,;	v2.b32 = v1 >> 0x4[4:0];
	v_and_b32 v3,0x1,v2  ; # gemm_fp8_gfx942.py:240 alloc 'odd_group'v3    s:10(35) v:133(161) a:0(0)    sid:1782 odd_group,1,lane_group,;	v3.u32 = (0x1 & v2.u32)
	v_xor_b32 v1,0x10,v1  ; # gemm_fp8_gfx942.py:241 free '_lane_id'v1 alloc 'src0_gprs'v1    s:10(35) v:133(161) a:0(0)    sid:1783 src0_gprs,16,_lane_id,;	v1.u32 = (0x10 ^ v1.u32)
	v_lshlrev_b32 v1,0x2,v1  ; # gemm_fp8_gfx942.py:241 free 'src0_gprs'v1 alloc 'exchange_lane'v1    s:10(35) v:133(161) a:0(0)    sid:1784 exchange_lane,2,src0_gprs,;	v1.b32 = v1 << 0x2[4:0];
	v_lshlrev_b32 v4,0x1,v3  ; # gemm_fp8_gfx942.py:242 alloc 'src0_gprs'v4    s:10(35) v:134(161) a:0(0)    sid:1785 src0_gprs,1,odd_group,;	v4.b32 = v3 << 0x1[4:0];
	v_lshrrev_b32 v2,0x1,v2  ; # gemm_fp8_gfx942.py:242 free 'lane_group'v2 alloc 'src1_gprs'v2    s:10(35) v:134(161) a:0(0)    sid:1786 src1_gprs,1,lane_group,;	v2.b32 = v2 >> 0x1[4:0];
	v_add_u32_e32 v2,v4,v2  ; # gemm_fp8_gfx942.py:242 free 'src0_gprs'v4 free 'src1_gprs'v2 alloc 'src0_gprs'v2    s:10(35) v:133(161) a:0(0)    sid:1787 src0_gprs,src0_gprs,src1_gprs,;	v2 = v4 + v2
	v_lshlrev_b32 v2,0x3,v2  ; # gemm_fp8_gfx942.py:242 free 'src0_gprs'v2 alloc 'src1_gprs'v2    s:10(35) v:133(161) a:0(0)    sid:1788 src1_gprs,3,src0_gprs,;	v2.b32 = v2 << 0x3[4:0];
	v_add_u32_e32 v2,s18,v2  ; # gemm_fp8_gfx942.py:242 free 'col_base's18 free 'src1_gprs'v2 alloc 'output_col'v2    s:9(35) v:133(161) a:0(0)    sid:1789 output_col,col_base,src1_gprs,;	v2 = s18 + v2
	v_add_u32_e32 v4,0x0,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:9(35) v:134(161) a:0(0)    sid:1790 column,0,output_col,;	v4 = 0x0 + v2
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:9(35) v:135(161) a:0(0)    sid:1791 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:9(35) v:135(161) a:0(0)    sid:1792 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v6,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v6    s:9(35) v:136(161) a:0(0)    sid:1793 src1_gprs,1,column,;	v6.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v6  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v6 alloc 'offset'v5    s:9(35) v:135(161) a:0(0)    sid:1794 offset,src0_gprs,src1_gprs,;	v5 = v5 + v6
	s_mov_b32 s5,0x8000  ; # asmjit.py:3745 asmjit.py:3957 gemm_fp8_gfx942.py:247 alloc 'sgpr_const_32768's5    s:10(35) v:135(161) a:0(0)    sid:1795 sgpr_const_32768,32768,;	s5 = 0x8000
	s_mov_b32 s6,0x3020706  ; # asmjit.py:3745 asmjit.py:3962 gemm_fp8_gfx942.py:247 alloc 'sgpr_const_50464518's6    s:11(35) v:135(161) a:0(0)    sid:1796 sgpr_const_50464518,50464518,;	s6 = 0x3020706
	v_add_f32 v6,s5,v18  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[0:0]'v18 alloc 'idst'v6    s:11(35) v:135(161) a:0(0)    sid:1797 idst,sgpr_const_32768,accum[0:0],;	v6 = s5 + v18
	v_add_f32 v7,s5,v19  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[1:1]'v19 alloc 'idst'v7    s:11(35) v:135(161) a:0(0)    sid:1798 idst,sgpr_const_32768,accum[1:1],;	v7 = s5 + v19
	v_perm_b32 v12,v6,v7,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v6 free 'idst'v7 alloc 'packed'v[12:15]    s:11(35) v:137(161) a:0(0)    sid:1799 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v6,s5,v36  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[2:2]'v36 alloc 'idst'v6    s:11(35) v:137(161) a:0(0)    sid:1800 idst,sgpr_const_32768,accum[2:2],;	v6 = s5 + v36
	v_add_f32 v7,s5,v37  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[3:3]'v37 alloc 'idst'v7    s:11(35) v:137(161) a:0(0)    sid:1801 idst,sgpr_const_32768,accum[3:3],;	v7 = s5 + v37
	v_perm_b32 v13,v6,v7,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v6 free 'idst'v7   sid:1802 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v6,s5,v38  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[4:4]'v38 alloc 'idst'v6    s:11(35) v:135(161) a:0(0)    sid:1803 idst,sgpr_const_32768,accum[4:4],;	v6 = s5 + v38
	v_add_f32 v7,s5,v39  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[5:5]'v39 alloc 'idst'v7    s:11(35) v:135(161) a:0(0)    sid:1804 idst,sgpr_const_32768,accum[5:5],;	v7 = s5 + v39
	v_perm_b32 v14,v6,v7,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v6 free 'idst'v7   sid:1805 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v6,s5,v40  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[6:6]'v40 alloc 'idst'v6    s:11(35) v:133(161) a:0(0)    sid:1806 idst,sgpr_const_32768,accum[6:6],;	v6 = s5 + v40
	v_add_f32 v7,s5,v41  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[7:7]'v41 alloc 'idst'v7    s:11(35) v:133(161) a:0(0)    sid:1807 idst,sgpr_const_32768,accum[7:7],;	v7 = s5 + v41
	v_perm_b32 v15,v6,v7,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v6 free 'idst'v7   sid:1808 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252 alloc 'exchanged[0:0]'v6    s:11(35) v:132(161) a:0(0)    sid:1809 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252 alloc 'exchanged[1:1]'v7    s:11(35) v:133(161) a:0(0)    sid:1810 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252 alloc 'exchanged[2:2]'v8    s:11(35) v:134(161) a:0(0)    sid:1811 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252 alloc 'exchanged[3:3]'v10    s:11(35) v:135(161) a:0(0)    sid:1812 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:1813 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:1814 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:1815 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:1816 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:1817 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:1818 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1819 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:134(161) a:0(0)    sid:1820 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_4 ; # asmjit.py:1526 contextlib.py:137   sid:1821;	jump if execz is 1 (exec mask == 0)
_bb_no_name_54:	 ;BB#54 predecessors:[_if_else_234_3] successors:[_execmask_end_258_4]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:1822 packed,offset,self.desc,0,
_execmask_end_258_4:	 ;BB#55 predecessors:[_bb_no_name_54,_if_else_234_3] successors:[_bb_no_name_56,_execmask_end_258_5]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1823 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0x20,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:134(161) a:0(0)    sid:1824 column,32,output_col,;	v4 = 0x20 + v2
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:135(161) a:0(0)    sid:1825 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:135(161) a:0(0)    sid:1826 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:136(161) a:0(0)    sid:1827 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:135(161) a:0(0)    sid:1828 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v42  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[8:8]'v42 alloc 'idst'v11    s:11(35) v:135(161) a:0(0)    sid:1829 idst,sgpr_const_32768,accum[8:8],;	v11 = s5 + v42
	v_add_f32 v16,s5,v43  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[9:9]'v43 alloc 'idst'v16    s:11(35) v:135(161) a:0(0)    sid:1830 idst,sgpr_const_32768,accum[9:9],;	v16 = s5 + v43
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:1831 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v44  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[10:10]'v44 alloc 'idst'v11    s:11(35) v:133(161) a:0(0)    sid:1832 idst,sgpr_const_32768,accum[10:10],;	v11 = s5 + v44
	v_add_f32 v16,s5,v45  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[11:11]'v45 alloc 'idst'v16    s:11(35) v:133(161) a:0(0)    sid:1833 idst,sgpr_const_32768,accum[11:11],;	v16 = s5 + v45
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:1834 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v46  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[12:12]'v46 alloc 'idst'v11    s:11(35) v:131(161) a:0(0)    sid:1835 idst,sgpr_const_32768,accum[12:12],;	v11 = s5 + v46
	v_add_f32 v16,s5,v47  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[13:13]'v47 alloc 'idst'v16    s:11(35) v:131(161) a:0(0)    sid:1836 idst,sgpr_const_32768,accum[13:13],;	v16 = s5 + v47
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:1837 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v48  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[14:14]'v48 alloc 'idst'v11    s:11(35) v:129(161) a:0(0)    sid:1838 idst,sgpr_const_32768,accum[14:14],;	v11 = s5 + v48
	v_add_f32 v16,s5,v49  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[15:15]'v49 alloc 'idst'v16    s:11(35) v:129(161) a:0(0)    sid:1839 idst,sgpr_const_32768,accum[15:15],;	v16 = s5 + v49
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:1840 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:1841 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:1842 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:1843 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:1844 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:1845 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:1846 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:1847 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:1848 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:1849 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:1850 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1851 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:126(161) a:0(0)    sid:1852 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_5 ; # asmjit.py:1526 contextlib.py:137   sid:1853;	jump if execz is 1 (exec mask == 0)
_bb_no_name_56:	 ;BB#56 predecessors:[_execmask_end_258_4] successors:[_execmask_end_258_5]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:1854 packed,offset,self.desc,0,
_execmask_end_258_5:	 ;BB#57 predecessors:[_bb_no_name_56,_execmask_end_258_4] successors:[_bb_no_name_58,_execmask_end_258_6]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1855 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0x40,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:126(161) a:0(0)    sid:1856 column,64,output_col,;	v4 = 0x40 + v2
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:127(161) a:0(0)    sid:1857 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:127(161) a:0(0)    sid:1858 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:128(161) a:0(0)    sid:1859 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:127(161) a:0(0)    sid:1860 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v50  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[16:16]'v50 alloc 'idst'v11    s:11(35) v:127(161) a:0(0)    sid:1861 idst,sgpr_const_32768,accum[16:16],;	v11 = s5 + v50
	v_add_f32 v16,s5,v51  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[17:17]'v51 alloc 'idst'v16    s:11(35) v:127(161) a:0(0)    sid:1862 idst,sgpr_const_32768,accum[17:17],;	v16 = s5 + v51
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:1863 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v52  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[18:18]'v52 alloc 'idst'v11    s:11(35) v:125(161) a:0(0)    sid:1864 idst,sgpr_const_32768,accum[18:18],;	v11 = s5 + v52
	v_add_f32 v16,s5,v53  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[19:19]'v53 alloc 'idst'v16    s:11(35) v:125(161) a:0(0)    sid:1865 idst,sgpr_const_32768,accum[19:19],;	v16 = s5 + v53
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:1866 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v54  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[20:20]'v54 alloc 'idst'v11    s:11(35) v:123(161) a:0(0)    sid:1867 idst,sgpr_const_32768,accum[20:20],;	v11 = s5 + v54
	v_add_f32 v16,s5,v55  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[21:21]'v55 alloc 'idst'v16    s:11(35) v:123(161) a:0(0)    sid:1868 idst,sgpr_const_32768,accum[21:21],;	v16 = s5 + v55
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:1869 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v56  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[22:22]'v56 alloc 'idst'v11    s:11(35) v:121(161) a:0(0)    sid:1870 idst,sgpr_const_32768,accum[22:22],;	v11 = s5 + v56
	v_add_f32 v16,s5,v57  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[23:23]'v57 alloc 'idst'v16    s:11(35) v:121(161) a:0(0)    sid:1871 idst,sgpr_const_32768,accum[23:23],;	v16 = s5 + v57
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:1872 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:1873 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:1874 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:1875 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:1876 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:1877 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:1878 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:1879 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:1880 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:1881 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:1882 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1883 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:118(161) a:0(0)    sid:1884 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_6 ; # asmjit.py:1526 contextlib.py:137   sid:1885;	jump if execz is 1 (exec mask == 0)
_bb_no_name_58:	 ;BB#58 predecessors:[_execmask_end_258_5] successors:[_execmask_end_258_6]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:1886 packed,offset,self.desc,0,
_execmask_end_258_6:	 ;BB#59 predecessors:[_bb_no_name_58,_execmask_end_258_5] successors:[_bb_no_name_60,_execmask_end_258_7]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1887 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0x60,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:118(161) a:0(0)    sid:1888 column,96,output_col,;	v4 = 0x60 + v2
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:119(161) a:0(0)    sid:1889 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:119(161) a:0(0)    sid:1890 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:120(161) a:0(0)    sid:1891 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:119(161) a:0(0)    sid:1892 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v58  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[24:24]'v58 alloc 'idst'v11    s:11(35) v:119(161) a:0(0)    sid:1893 idst,sgpr_const_32768,accum[24:24],;	v11 = s5 + v58
	v_add_f32 v16,s5,v59  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[25:25]'v59 alloc 'idst'v16    s:11(35) v:119(161) a:0(0)    sid:1894 idst,sgpr_const_32768,accum[25:25],;	v16 = s5 + v59
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:1895 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v60  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[26:26]'v60 alloc 'idst'v11    s:11(35) v:117(161) a:0(0)    sid:1896 idst,sgpr_const_32768,accum[26:26],;	v11 = s5 + v60
	v_add_f32 v16,s5,v61  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[27:27]'v61 alloc 'idst'v16    s:11(35) v:117(161) a:0(0)    sid:1897 idst,sgpr_const_32768,accum[27:27],;	v16 = s5 + v61
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:1898 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v62  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[28:28]'v62 alloc 'idst'v11    s:11(35) v:115(161) a:0(0)    sid:1899 idst,sgpr_const_32768,accum[28:28],;	v11 = s5 + v62
	v_add_f32 v16,s5,v63  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[29:29]'v63 alloc 'idst'v16    s:11(35) v:115(161) a:0(0)    sid:1900 idst,sgpr_const_32768,accum[29:29],;	v16 = s5 + v63
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:1901 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v64  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[30:30]'v64 alloc 'idst'v11    s:11(35) v:113(161) a:0(0)    sid:1902 idst,sgpr_const_32768,accum[30:30],;	v11 = s5 + v64
	v_add_f32 v16,s5,v65  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[31:31]'v65 alloc 'idst'v16    s:11(35) v:113(161) a:0(0)    sid:1903 idst,sgpr_const_32768,accum[31:31],;	v16 = s5 + v65
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:1904 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:1905 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:1906 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:1907 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:1908 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:1909 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:1910 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:1911 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:1912 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:1913 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:1914 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1915 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:110(161) a:0(0)    sid:1916 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_7 ; # asmjit.py:1526 contextlib.py:137   sid:1917;	jump if execz is 1 (exec mask == 0)
_bb_no_name_60:	 ;BB#60 predecessors:[_execmask_end_258_6] successors:[_execmask_end_258_7]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:1918 packed,offset,self.desc,0,
_execmask_end_258_7:	 ;BB#61 predecessors:[_bb_no_name_60,_execmask_end_258_6] successors:[_bb_no_name_62,_execmask_end_258_8]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1919 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0x80,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:110(161) a:0(0)    sid:1920 column,128,output_col,;	v4 = 0x80 + v2
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:111(161) a:0(0)    sid:1921 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:111(161) a:0(0)    sid:1922 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:112(161) a:0(0)    sid:1923 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:111(161) a:0(0)    sid:1924 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v66  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[32:32]'v66 alloc 'idst'v11    s:11(35) v:111(161) a:0(0)    sid:1925 idst,sgpr_const_32768,accum[32:32],;	v11 = s5 + v66
	v_add_f32 v16,s5,v67  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[33:33]'v67 alloc 'idst'v16    s:11(35) v:111(161) a:0(0)    sid:1926 idst,sgpr_const_32768,accum[33:33],;	v16 = s5 + v67
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:1927 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v68  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[34:34]'v68 alloc 'idst'v11    s:11(35) v:109(161) a:0(0)    sid:1928 idst,sgpr_const_32768,accum[34:34],;	v11 = s5 + v68
	v_add_f32 v16,s5,v69  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[35:35]'v69 alloc 'idst'v16    s:11(35) v:109(161) a:0(0)    sid:1929 idst,sgpr_const_32768,accum[35:35],;	v16 = s5 + v69
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:1930 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v70  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[36:36]'v70 alloc 'idst'v11    s:11(35) v:107(161) a:0(0)    sid:1931 idst,sgpr_const_32768,accum[36:36],;	v11 = s5 + v70
	v_add_f32 v16,s5,v71  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[37:37]'v71 alloc 'idst'v16    s:11(35) v:107(161) a:0(0)    sid:1932 idst,sgpr_const_32768,accum[37:37],;	v16 = s5 + v71
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:1933 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v72  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[38:38]'v72 alloc 'idst'v11    s:11(35) v:105(161) a:0(0)    sid:1934 idst,sgpr_const_32768,accum[38:38],;	v11 = s5 + v72
	v_add_f32 v16,s5,v73  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[39:39]'v73 alloc 'idst'v16    s:11(35) v:105(161) a:0(0)    sid:1935 idst,sgpr_const_32768,accum[39:39],;	v16 = s5 + v73
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:1936 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:1937 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:1938 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:1939 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:1940 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:1941 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:1942 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:1943 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:1944 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:1945 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:1946 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1947 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:102(161) a:0(0)    sid:1948 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_8 ; # asmjit.py:1526 contextlib.py:137   sid:1949;	jump if execz is 1 (exec mask == 0)
_bb_no_name_62:	 ;BB#62 predecessors:[_execmask_end_258_7] successors:[_execmask_end_258_8]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:1950 packed,offset,self.desc,0,
_execmask_end_258_8:	 ;BB#63 predecessors:[_bb_no_name_62,_execmask_end_258_7] successors:[_bb_no_name_64,_execmask_end_258_9]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1951 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0xa0,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:102(161) a:0(0)    sid:1952 column,160,output_col,;	v4 = 0xa0 + v2
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:103(161) a:0(0)    sid:1953 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:103(161) a:0(0)    sid:1954 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:104(161) a:0(0)    sid:1955 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:103(161) a:0(0)    sid:1956 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v74  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[40:40]'v74 alloc 'idst'v11    s:11(35) v:103(161) a:0(0)    sid:1957 idst,sgpr_const_32768,accum[40:40],;	v11 = s5 + v74
	v_add_f32 v16,s5,v75  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[41:41]'v75 alloc 'idst'v16    s:11(35) v:103(161) a:0(0)    sid:1958 idst,sgpr_const_32768,accum[41:41],;	v16 = s5 + v75
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:1959 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v76  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[42:42]'v76 alloc 'idst'v11    s:11(35) v:101(161) a:0(0)    sid:1960 idst,sgpr_const_32768,accum[42:42],;	v11 = s5 + v76
	v_add_f32 v16,s5,v77  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[43:43]'v77 alloc 'idst'v16    s:11(35) v:101(161) a:0(0)    sid:1961 idst,sgpr_const_32768,accum[43:43],;	v16 = s5 + v77
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:1962 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v78  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[44:44]'v78 alloc 'idst'v11    s:11(35) v:99(161) a:0(0)    sid:1963 idst,sgpr_const_32768,accum[44:44],;	v11 = s5 + v78
	v_add_f32 v16,s5,v79  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[45:45]'v79 alloc 'idst'v16    s:11(35) v:99(161) a:0(0)    sid:1964 idst,sgpr_const_32768,accum[45:45],;	v16 = s5 + v79
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:1965 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v80  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[46:46]'v80 alloc 'idst'v11    s:11(35) v:97(161) a:0(0)    sid:1966 idst,sgpr_const_32768,accum[46:46],;	v11 = s5 + v80
	v_add_f32 v16,s5,v81  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[47:47]'v81 alloc 'idst'v16    s:11(35) v:97(161) a:0(0)    sid:1967 idst,sgpr_const_32768,accum[47:47],;	v16 = s5 + v81
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:1968 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:1969 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:1970 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:1971 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:1972 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:1973 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:1974 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:1975 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:1976 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:1977 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:1978 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:1979 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:94(161) a:0(0)    sid:1980 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_9 ; # asmjit.py:1526 contextlib.py:137   sid:1981;	jump if execz is 1 (exec mask == 0)
_bb_no_name_64:	 ;BB#64 predecessors:[_execmask_end_258_8] successors:[_execmask_end_258_9]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:1982 packed,offset,self.desc,0,
_execmask_end_258_9:	 ;BB#65 predecessors:[_bb_no_name_64,_execmask_end_258_8] successors:[_bb_no_name_66,_execmask_end_258_10]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:1983 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0xc0,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:94(161) a:0(0)    sid:1984 column,192,output_col,;	v4 = 0xc0 + v2
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:95(161) a:0(0)    sid:1985 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:95(161) a:0(0)    sid:1986 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:96(161) a:0(0)    sid:1987 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:95(161) a:0(0)    sid:1988 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v82  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[48:48]'v82 alloc 'idst'v11    s:11(35) v:95(161) a:0(0)    sid:1989 idst,sgpr_const_32768,accum[48:48],;	v11 = s5 + v82
	v_add_f32 v16,s5,v83  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[49:49]'v83 alloc 'idst'v16    s:11(35) v:95(161) a:0(0)    sid:1990 idst,sgpr_const_32768,accum[49:49],;	v16 = s5 + v83
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:1991 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v84  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[50:50]'v84 alloc 'idst'v11    s:11(35) v:93(161) a:0(0)    sid:1992 idst,sgpr_const_32768,accum[50:50],;	v11 = s5 + v84
	v_add_f32 v16,s5,v85  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[51:51]'v85 alloc 'idst'v16    s:11(35) v:93(161) a:0(0)    sid:1993 idst,sgpr_const_32768,accum[51:51],;	v16 = s5 + v85
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:1994 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v86  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[52:52]'v86 alloc 'idst'v11    s:11(35) v:91(161) a:0(0)    sid:1995 idst,sgpr_const_32768,accum[52:52],;	v11 = s5 + v86
	v_add_f32 v16,s5,v87  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[53:53]'v87 alloc 'idst'v16    s:11(35) v:91(161) a:0(0)    sid:1996 idst,sgpr_const_32768,accum[53:53],;	v16 = s5 + v87
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:1997 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v88  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[54:54]'v88 alloc 'idst'v11    s:11(35) v:89(161) a:0(0)    sid:1998 idst,sgpr_const_32768,accum[54:54],;	v11 = s5 + v88
	v_add_f32 v16,s5,v89  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[55:55]'v89 alloc 'idst'v16    s:11(35) v:89(161) a:0(0)    sid:1999 idst,sgpr_const_32768,accum[55:55],;	v16 = s5 + v89
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:2000 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:2001 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:2002 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:2003 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:2004 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:2005 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:2006 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:2007 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:2008 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:2009 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:2010 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2011 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:86(161) a:0(0)    sid:2012 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_10 ; # asmjit.py:1526 contextlib.py:137   sid:2013;	jump if execz is 1 (exec mask == 0)
_bb_no_name_66:	 ;BB#66 predecessors:[_execmask_end_258_9] successors:[_execmask_end_258_10]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:2014 packed,offset,self.desc,0,
_execmask_end_258_10:	 ;BB#67 predecessors:[_bb_no_name_66,_execmask_end_258_9] successors:[_bb_no_name_68,_execmask_end_258_11]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2015 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0xe0,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:86(161) a:0(0)    sid:2016 column,224,output_col,;	v4 = 0xe0 + v2
	v_add_u32_e32 v5,0x0,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:87(161) a:0(0)    sid:2017 src0_gprs,0,local_row,;	v5 = 0x0 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:87(161) a:0(0)    sid:2018 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:88(161) a:0(0)    sid:2019 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:87(161) a:0(0)    sid:2020 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v90  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[56:56]'v90 alloc 'idst'v11    s:11(35) v:87(161) a:0(0)    sid:2021 idst,sgpr_const_32768,accum[56:56],;	v11 = s5 + v90
	v_add_f32 v16,s5,v91  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[57:57]'v91 alloc 'idst'v16    s:11(35) v:87(161) a:0(0)    sid:2022 idst,sgpr_const_32768,accum[57:57],;	v16 = s5 + v91
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:2023 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v92  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[58:58]'v92 alloc 'idst'v11    s:11(35) v:85(161) a:0(0)    sid:2024 idst,sgpr_const_32768,accum[58:58],;	v11 = s5 + v92
	v_add_f32 v16,s5,v93  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[59:59]'v93 alloc 'idst'v16    s:11(35) v:85(161) a:0(0)    sid:2025 idst,sgpr_const_32768,accum[59:59],;	v16 = s5 + v93
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:2026 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v94  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[60:60]'v94 alloc 'idst'v11    s:11(35) v:83(161) a:0(0)    sid:2027 idst,sgpr_const_32768,accum[60:60],;	v11 = s5 + v94
	v_add_f32 v16,s5,v95  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[61:61]'v95 alloc 'idst'v16    s:11(35) v:83(161) a:0(0)    sid:2028 idst,sgpr_const_32768,accum[61:61],;	v16 = s5 + v95
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:2029 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v96  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[62:62]'v96 alloc 'idst'v11    s:11(35) v:81(161) a:0(0)    sid:2030 idst,sgpr_const_32768,accum[62:62],;	v11 = s5 + v96
	v_add_f32 v16,s5,v97  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[63:63]'v97 alloc 'idst'v16    s:11(35) v:81(161) a:0(0)    sid:2031 idst,sgpr_const_32768,accum[63:63],;	v16 = s5 + v97
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:2032 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:2033 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:2034 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:2035 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:2036 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:2037 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:2038 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:2039 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:2040 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:2041 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:2042 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2043 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:78(161) a:0(0)    sid:2044 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_11 ; # asmjit.py:1526 contextlib.py:137   sid:2045;	jump if execz is 1 (exec mask == 0)
_bb_no_name_68:	 ;BB#68 predecessors:[_execmask_end_258_10] successors:[_execmask_end_258_11]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:2046 packed,offset,self.desc,0,
_execmask_end_258_11:	 ;BB#69 predecessors:[_bb_no_name_68,_execmask_end_258_10] successors:[_bb_no_name_70,_execmask_end_258_12]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2047 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0x0,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:78(161) a:0(0)    sid:2048 column,0,output_col,;	v4 = 0x0 + v2
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:79(161) a:0(0)    sid:2049 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:79(161) a:0(0)    sid:2050 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:80(161) a:0(0)    sid:2051 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:79(161) a:0(0)    sid:2052 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v98  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[64:64]'v98 alloc 'idst'v11    s:11(35) v:79(161) a:0(0)    sid:2053 idst,sgpr_const_32768,accum[64:64],;	v11 = s5 + v98
	v_add_f32 v16,s5,v99  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[65:65]'v99 alloc 'idst'v16    s:11(35) v:79(161) a:0(0)    sid:2054 idst,sgpr_const_32768,accum[65:65],;	v16 = s5 + v99
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:2055 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v100  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[66:66]'v100 alloc 'idst'v11    s:11(35) v:77(161) a:0(0)    sid:2056 idst,sgpr_const_32768,accum[66:66],;	v11 = s5 + v100
	v_add_f32 v16,s5,v101  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[67:67]'v101 alloc 'idst'v16    s:11(35) v:77(161) a:0(0)    sid:2057 idst,sgpr_const_32768,accum[67:67],;	v16 = s5 + v101
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:2058 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v102  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[68:68]'v102 alloc 'idst'v11    s:11(35) v:75(161) a:0(0)    sid:2059 idst,sgpr_const_32768,accum[68:68],;	v11 = s5 + v102
	v_add_f32 v16,s5,v103  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[69:69]'v103 alloc 'idst'v16    s:11(35) v:75(161) a:0(0)    sid:2060 idst,sgpr_const_32768,accum[69:69],;	v16 = s5 + v103
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:2061 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v104  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[70:70]'v104 alloc 'idst'v11    s:11(35) v:73(161) a:0(0)    sid:2062 idst,sgpr_const_32768,accum[70:70],;	v11 = s5 + v104
	v_add_f32 v16,s5,v105  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[71:71]'v105 alloc 'idst'v16    s:11(35) v:73(161) a:0(0)    sid:2063 idst,sgpr_const_32768,accum[71:71],;	v16 = s5 + v105
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:2064 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:2065 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:2066 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:2067 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:2068 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:2069 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:2070 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:2071 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:2072 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:2073 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:2074 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2075 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:70(161) a:0(0)    sid:2076 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_12 ; # asmjit.py:1526 contextlib.py:137   sid:2077;	jump if execz is 1 (exec mask == 0)
_bb_no_name_70:	 ;BB#70 predecessors:[_execmask_end_258_11] successors:[_execmask_end_258_12]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:2078 packed,offset,self.desc,0,
_execmask_end_258_12:	 ;BB#71 predecessors:[_bb_no_name_70,_execmask_end_258_11] successors:[_bb_no_name_72,_execmask_end_258_13]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2079 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0x20,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:70(161) a:0(0)    sid:2080 column,32,output_col,;	v4 = 0x20 + v2
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:71(161) a:0(0)    sid:2081 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:71(161) a:0(0)    sid:2082 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:72(161) a:0(0)    sid:2083 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:71(161) a:0(0)    sid:2084 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v106  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[72:72]'v106 alloc 'idst'v11    s:11(35) v:71(161) a:0(0)    sid:2085 idst,sgpr_const_32768,accum[72:72],;	v11 = s5 + v106
	v_add_f32 v16,s5,v107  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[73:73]'v107 alloc 'idst'v16    s:11(35) v:71(161) a:0(0)    sid:2086 idst,sgpr_const_32768,accum[73:73],;	v16 = s5 + v107
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:2087 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v108  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[74:74]'v108 alloc 'idst'v11    s:11(35) v:69(161) a:0(0)    sid:2088 idst,sgpr_const_32768,accum[74:74],;	v11 = s5 + v108
	v_add_f32 v16,s5,v109  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[75:75]'v109 alloc 'idst'v16    s:11(35) v:69(161) a:0(0)    sid:2089 idst,sgpr_const_32768,accum[75:75],;	v16 = s5 + v109
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:2090 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v110  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[76:76]'v110 alloc 'idst'v11    s:11(35) v:67(161) a:0(0)    sid:2091 idst,sgpr_const_32768,accum[76:76],;	v11 = s5 + v110
	v_add_f32 v16,s5,v111  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[77:77]'v111 alloc 'idst'v16    s:11(35) v:67(161) a:0(0)    sid:2092 idst,sgpr_const_32768,accum[77:77],;	v16 = s5 + v111
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:2093 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v112  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[78:78]'v112 alloc 'idst'v11    s:11(35) v:65(161) a:0(0)    sid:2094 idst,sgpr_const_32768,accum[78:78],;	v11 = s5 + v112
	v_add_f32 v16,s5,v113  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[79:79]'v113 alloc 'idst'v16    s:11(35) v:65(161) a:0(0)    sid:2095 idst,sgpr_const_32768,accum[79:79],;	v16 = s5 + v113
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:2096 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:2097 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:2098 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:2099 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:2100 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:2101 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:2102 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:2103 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:2104 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:2105 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:2106 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2107 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:62(161) a:0(0)    sid:2108 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_13 ; # asmjit.py:1526 contextlib.py:137   sid:2109;	jump if execz is 1 (exec mask == 0)
_bb_no_name_72:	 ;BB#72 predecessors:[_execmask_end_258_12] successors:[_execmask_end_258_13]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:2110 packed,offset,self.desc,0,
_execmask_end_258_13:	 ;BB#73 predecessors:[_bb_no_name_72,_execmask_end_258_12] successors:[_bb_no_name_74,_execmask_end_258_14]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2111 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0x40,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:62(161) a:0(0)    sid:2112 column,64,output_col,;	v4 = 0x40 + v2
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:63(161) a:0(0)    sid:2113 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:63(161) a:0(0)    sid:2114 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:64(161) a:0(0)    sid:2115 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:63(161) a:0(0)    sid:2116 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v114  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[80:80]'v114 alloc 'idst'v11    s:11(35) v:63(161) a:0(0)    sid:2117 idst,sgpr_const_32768,accum[80:80],;	v11 = s5 + v114
	v_add_f32 v16,s5,v115  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[81:81]'v115 alloc 'idst'v16    s:11(35) v:63(161) a:0(0)    sid:2118 idst,sgpr_const_32768,accum[81:81],;	v16 = s5 + v115
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:2119 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v116  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[82:82]'v116 alloc 'idst'v11    s:11(35) v:61(161) a:0(0)    sid:2120 idst,sgpr_const_32768,accum[82:82],;	v11 = s5 + v116
	v_add_f32 v16,s5,v117  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[83:83]'v117 alloc 'idst'v16    s:11(35) v:61(161) a:0(0)    sid:2121 idst,sgpr_const_32768,accum[83:83],;	v16 = s5 + v117
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:2122 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v118  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[84:84]'v118 alloc 'idst'v11    s:11(35) v:59(161) a:0(0)    sid:2123 idst,sgpr_const_32768,accum[84:84],;	v11 = s5 + v118
	v_add_f32 v16,s5,v119  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[85:85]'v119 alloc 'idst'v16    s:11(35) v:59(161) a:0(0)    sid:2124 idst,sgpr_const_32768,accum[85:85],;	v16 = s5 + v119
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:2125 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v120  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[86:86]'v120 alloc 'idst'v11    s:11(35) v:57(161) a:0(0)    sid:2126 idst,sgpr_const_32768,accum[86:86],;	v11 = s5 + v120
	v_add_f32 v16,s5,v121  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[87:87]'v121 alloc 'idst'v16    s:11(35) v:57(161) a:0(0)    sid:2127 idst,sgpr_const_32768,accum[87:87],;	v16 = s5 + v121
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:2128 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:2129 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:2130 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:2131 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:2132 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:2133 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:2134 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:2135 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:2136 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:2137 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:2138 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2139 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:54(161) a:0(0)    sid:2140 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_14 ; # asmjit.py:1526 contextlib.py:137   sid:2141;	jump if execz is 1 (exec mask == 0)
_bb_no_name_74:	 ;BB#74 predecessors:[_execmask_end_258_13] successors:[_execmask_end_258_14]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:2142 packed,offset,self.desc,0,
_execmask_end_258_14:	 ;BB#75 predecessors:[_bb_no_name_74,_execmask_end_258_13] successors:[_bb_no_name_76,_execmask_end_258_15]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2143 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0x60,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:54(161) a:0(0)    sid:2144 column,96,output_col,;	v4 = 0x60 + v2
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:55(161) a:0(0)    sid:2145 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:55(161) a:0(0)    sid:2146 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:56(161) a:0(0)    sid:2147 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:55(161) a:0(0)    sid:2148 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v122  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[88:88]'v122 alloc 'idst'v11    s:11(35) v:55(161) a:0(0)    sid:2149 idst,sgpr_const_32768,accum[88:88],;	v11 = s5 + v122
	v_add_f32 v16,s5,v123  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[89:89]'v123 alloc 'idst'v16    s:11(35) v:55(161) a:0(0)    sid:2150 idst,sgpr_const_32768,accum[89:89],;	v16 = s5 + v123
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:2151 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v124  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[90:90]'v124 alloc 'idst'v11    s:11(35) v:53(161) a:0(0)    sid:2152 idst,sgpr_const_32768,accum[90:90],;	v11 = s5 + v124
	v_add_f32 v16,s5,v125  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[91:91]'v125 alloc 'idst'v16    s:11(35) v:53(161) a:0(0)    sid:2153 idst,sgpr_const_32768,accum[91:91],;	v16 = s5 + v125
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:2154 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v126  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[92:92]'v126 alloc 'idst'v11    s:11(35) v:51(161) a:0(0)    sid:2155 idst,sgpr_const_32768,accum[92:92],;	v11 = s5 + v126
	v_add_f32 v16,s5,v127  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[93:93]'v127 alloc 'idst'v16    s:11(35) v:51(161) a:0(0)    sid:2156 idst,sgpr_const_32768,accum[93:93],;	v16 = s5 + v127
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:2157 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v128  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[94:94]'v128 alloc 'idst'v11    s:11(35) v:49(161) a:0(0)    sid:2158 idst,sgpr_const_32768,accum[94:94],;	v11 = s5 + v128
	v_add_f32 v16,s5,v129  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[95:95]'v129 alloc 'idst'v16    s:11(35) v:49(161) a:0(0)    sid:2159 idst,sgpr_const_32768,accum[95:95],;	v16 = s5 + v129
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:2160 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:2161 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:2162 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:2163 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:2164 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:2165 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:2166 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:2167 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:2168 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:2169 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:2170 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2171 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:46(161) a:0(0)    sid:2172 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_15 ; # asmjit.py:1526 contextlib.py:137   sid:2173;	jump if execz is 1 (exec mask == 0)
_bb_no_name_76:	 ;BB#76 predecessors:[_execmask_end_258_14] successors:[_execmask_end_258_15]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:2174 packed,offset,self.desc,0,
_execmask_end_258_15:	 ;BB#77 predecessors:[_bb_no_name_76,_execmask_end_258_14] successors:[_bb_no_name_78,_execmask_end_258_16]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2175 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0x80,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:46(161) a:0(0)    sid:2176 column,128,output_col,;	v4 = 0x80 + v2
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:47(161) a:0(0)    sid:2177 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:47(161) a:0(0)    sid:2178 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:48(161) a:0(0)    sid:2179 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:47(161) a:0(0)    sid:2180 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v130  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[96:96]'v130 alloc 'idst'v11    s:11(35) v:47(161) a:0(0)    sid:2181 idst,sgpr_const_32768,accum[96:96],;	v11 = s5 + v130
	v_add_f32 v16,s5,v131  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[97:97]'v131 alloc 'idst'v16    s:11(35) v:47(161) a:0(0)    sid:2182 idst,sgpr_const_32768,accum[97:97],;	v16 = s5 + v131
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:2183 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v132  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[98:98]'v132 alloc 'idst'v11    s:11(35) v:45(161) a:0(0)    sid:2184 idst,sgpr_const_32768,accum[98:98],;	v11 = s5 + v132
	v_add_f32 v16,s5,v133  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[99:99]'v133 alloc 'idst'v16    s:11(35) v:45(161) a:0(0)    sid:2185 idst,sgpr_const_32768,accum[99:99],;	v16 = s5 + v133
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:2186 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v134  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[100:100]'v134 alloc 'idst'v11    s:11(35) v:43(161) a:0(0)    sid:2187 idst,sgpr_const_32768,accum[100:100],;	v11 = s5 + v134
	v_add_f32 v16,s5,v135  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[101:101]'v135 alloc 'idst'v16    s:11(35) v:43(161) a:0(0)    sid:2188 idst,sgpr_const_32768,accum[101:101],;	v16 = s5 + v135
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:2189 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v136  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[102:102]'v136 alloc 'idst'v11    s:11(35) v:41(161) a:0(0)    sid:2190 idst,sgpr_const_32768,accum[102:102],;	v11 = s5 + v136
	v_add_f32 v16,s5,v137  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[103:103]'v137 alloc 'idst'v16    s:11(35) v:41(161) a:0(0)    sid:2191 idst,sgpr_const_32768,accum[103:103],;	v16 = s5 + v137
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:2192 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:2193 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:2194 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:2195 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:2196 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:2197 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:2198 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:2199 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:2200 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:2201 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:2202 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2203 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:38(161) a:0(0)    sid:2204 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_16 ; # asmjit.py:1526 contextlib.py:137   sid:2205;	jump if execz is 1 (exec mask == 0)
_bb_no_name_78:	 ;BB#78 predecessors:[_execmask_end_258_15] successors:[_execmask_end_258_16]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:2206 packed,offset,self.desc,0,
_execmask_end_258_16:	 ;BB#79 predecessors:[_bb_no_name_78,_execmask_end_258_15] successors:[_bb_no_name_80,_execmask_end_258_17]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2207 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0xa0,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:38(161) a:0(0)    sid:2208 column,160,output_col,;	v4 = 0xa0 + v2
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:39(161) a:0(0)    sid:2209 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:39(161) a:0(0)    sid:2210 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:40(161) a:0(0)    sid:2211 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:39(161) a:0(0)    sid:2212 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v138  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[104:104]'v138 alloc 'idst'v11    s:11(35) v:39(161) a:0(0)    sid:2213 idst,sgpr_const_32768,accum[104:104],;	v11 = s5 + v138
	v_add_f32 v16,s5,v139  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[105:105]'v139 alloc 'idst'v16    s:11(35) v:39(161) a:0(0)    sid:2214 idst,sgpr_const_32768,accum[105:105],;	v16 = s5 + v139
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:2215 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v140  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[106:106]'v140 alloc 'idst'v11    s:11(35) v:37(161) a:0(0)    sid:2216 idst,sgpr_const_32768,accum[106:106],;	v11 = s5 + v140
	v_add_f32 v16,s5,v141  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[107:107]'v141 alloc 'idst'v16    s:11(35) v:37(161) a:0(0)    sid:2217 idst,sgpr_const_32768,accum[107:107],;	v16 = s5 + v141
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:2218 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v142  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[108:108]'v142 alloc 'idst'v11    s:11(35) v:35(161) a:0(0)    sid:2219 idst,sgpr_const_32768,accum[108:108],;	v11 = s5 + v142
	v_add_f32 v16,s5,v143  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[109:109]'v143 alloc 'idst'v16    s:11(35) v:35(161) a:0(0)    sid:2220 idst,sgpr_const_32768,accum[109:109],;	v16 = s5 + v143
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:2221 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v144  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[110:110]'v144 alloc 'idst'v11    s:11(35) v:33(161) a:0(0)    sid:2222 idst,sgpr_const_32768,accum[110:110],;	v11 = s5 + v144
	v_add_f32 v16,s5,v145  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[111:111]'v145 alloc 'idst'v16    s:11(35) v:33(161) a:0(0)    sid:2223 idst,sgpr_const_32768,accum[111:111],;	v16 = s5 + v145
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:2224 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:2225 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:2226 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:2227 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:2228 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:2229 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:2230 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:2231 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:2232 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:2233 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:2234 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2235 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:30(161) a:0(0)    sid:2236 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_17 ; # asmjit.py:1526 contextlib.py:137   sid:2237;	jump if execz is 1 (exec mask == 0)
_bb_no_name_80:	 ;BB#80 predecessors:[_execmask_end_258_16] successors:[_execmask_end_258_17]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:2238 packed,offset,self.desc,0,
_execmask_end_258_17:	 ;BB#81 predecessors:[_bb_no_name_80,_execmask_end_258_16] successors:[_bb_no_name_82,_execmask_end_258_18]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2239 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v4,0xc0,v2  ; # gemm_fp8_gfx942.py:245 alloc 'column'v4    s:11(35) v:30(161) a:0(0)    sid:2240 column,192,output_col,;	v4 = 0xc0 + v2
	v_add_u32_e32 v5,0x80,v9  ; # gemm_fp8_gfx942.py:246 alloc 'src0_gprs'v5    s:11(35) v:31(161) a:0(0)    sid:2241 src0_gprs,128,local_row,;	v5 = 0x80 + v9
	v_lshlrev_b32 v5,0xd,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 alloc 'src0_gprs'v5    s:11(35) v:31(161) a:0(0)    sid:2242 src0_gprs,13,src0_gprs,;	v5.b32 = v5 << 0xd[4:0];
	v_lshlrev_b32 v11,0x1,v4  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v11    s:11(35) v:32(161) a:0(0)    sid:2243 src1_gprs,1,column,;	v11.b32 = v4 << 0x1[4:0];
	v_add_u32_e32 v5,v5,v11  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v5 free 'src1_gprs'v11 alloc 'offset'v5    s:11(35) v:31(161) a:0(0)    sid:2244 offset,src0_gprs,src1_gprs,;	v5 = v5 + v11
	v_add_f32 v11,s5,v146  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[112:112]'v146 alloc 'idst'v11    s:11(35) v:31(161) a:0(0)    sid:2245 idst,sgpr_const_32768,accum[112:112],;	v11 = s5 + v146
	v_add_f32 v16,s5,v147  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[113:113]'v147 alloc 'idst'v16    s:11(35) v:31(161) a:0(0)    sid:2246 idst,sgpr_const_32768,accum[113:113],;	v16 = s5 + v147
	v_perm_b32 v12,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v11 free 'idst'v16   sid:2247 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v148  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[114:114]'v148 alloc 'idst'v11    s:11(35) v:29(161) a:0(0)    sid:2248 idst,sgpr_const_32768,accum[114:114],;	v11 = s5 + v148
	v_add_f32 v16,s5,v149  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[115:115]'v149 alloc 'idst'v16    s:11(35) v:29(161) a:0(0)    sid:2249 idst,sgpr_const_32768,accum[115:115],;	v16 = s5 + v149
	v_perm_b32 v13,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v11 free 'idst'v16   sid:2250 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v150  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[116:116]'v150 alloc 'idst'v11    s:11(35) v:27(161) a:0(0)    sid:2251 idst,sgpr_const_32768,accum[116:116],;	v11 = s5 + v150
	v_add_f32 v16,s5,v151  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[117:117]'v151 alloc 'idst'v16    s:11(35) v:27(161) a:0(0)    sid:2252 idst,sgpr_const_32768,accum[117:117],;	v16 = s5 + v151
	v_perm_b32 v14,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v11 free 'idst'v16   sid:2253 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v11,s5,v152  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[118:118]'v152 alloc 'idst'v11    s:11(35) v:25(161) a:0(0)    sid:2254 idst,sgpr_const_32768,accum[118:118],;	v11 = s5 + v152
	v_add_f32 v16,s5,v153  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[119:119]'v153 alloc 'idst'v16    s:11(35) v:25(161) a:0(0)    sid:2255 idst,sgpr_const_32768,accum[119:119],;	v16 = s5 + v153
	v_perm_b32 v15,v11,v16,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'idst'v11 free 'idst'v16   sid:2256 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:2257 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:2258 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:2259 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252   sid:2260 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:2261 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254   sid:2262 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256   sid:2263 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257   sid:2264 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256   sid:2265 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257   sid:2266 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v4  ; # asmjit.py:1520 contextlib.py:137 free 'column'v4   sid:2267 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v4.u32 )
	s_and_saveexec_b64 s[8:9],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[8:9]    s:13(35) v:22(161) a:0(0)    sid:2268 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[8:9]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_18 ; # asmjit.py:1526 contextlib.py:137   sid:2269;	jump if execz is 1 (exec mask == 0)
_bb_no_name_82:	 ;BB#82 predecessors:[_execmask_end_258_17] successors:[_execmask_end_258_18]
	buffer_store_dwordx4 v[12:15],v5,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'offset'v5   sid:2270 packed,offset,self.desc,0,
_execmask_end_258_18:	 ;BB#83 predecessors:[_bb_no_name_82,_execmask_end_258_17] successors:[_bb_no_name_84,_execmask_end_258_19]
	s_mov_b64 exec,s[8:9]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[8:9]   sid:2271 exec,ExecMask_exec_backup,;	exec = s[8:9]
	v_add_u32_e32 v2,0xe0,v2  ; # gemm_fp8_gfx942.py:245 free 'output_col'v2 alloc 'column'v2    s:11(35) v:21(161) a:0(0)    sid:2272 column,224,output_col,;	v2 = 0xe0 + v2
	v_add_u32_e32 v4,0x80,v9  ; # gemm_fp8_gfx942.py:246 free 'local_row'v9 alloc 'src0_gprs'v4    s:11(35) v:21(161) a:0(0)    sid:2273 src0_gprs,128,local_row,;	v4 = 0x80 + v9
	v_lshlrev_b32 v4,0xd,v4  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v4 alloc 'src0_gprs'v4    s:11(35) v:21(161) a:0(0)    sid:2274 src0_gprs,13,src0_gprs,;	v4.b32 = v4 << 0xd[4:0];
	v_lshlrev_b32 v5,0x1,v2  ; # gemm_fp8_gfx942.py:246 alloc 'src1_gprs'v5    s:11(35) v:22(161) a:0(0)    sid:2275 src1_gprs,1,column,;	v5.b32 = v2 << 0x1[4:0];
	v_add_u32_e32 v4,v4,v5  ; # gemm_fp8_gfx942.py:246 free 'src0_gprs'v4 free 'src1_gprs'v5 alloc 'offset'v4    s:11(35) v:21(161) a:0(0)    sid:2276 offset,src0_gprs,src1_gprs,;	v4 = v4 + v5
	v_add_f32 v5,s5,v154  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[120:120]'v154 alloc 'idst'v5    s:11(35) v:21(161) a:0(0)    sid:2277 idst,sgpr_const_32768,accum[120:120],;	v5 = s5 + v154
	v_add_f32 v9,s5,v155  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'accum[121:121]'v155 alloc 'idst'v9    s:11(35) v:21(161) a:0(0)    sid:2278 idst,sgpr_const_32768,accum[121:121],;	v9 = s5 + v155
	v_perm_b32 v12,v5,v9,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:247 free 'idst'v5 free 'idst'v9   sid:2279 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v5,s5,v156  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[122:122]'v156 alloc 'idst'v5    s:11(35) v:19(161) a:0(0)    sid:2280 idst,sgpr_const_32768,accum[122:122],;	v5 = s5 + v156
	v_add_f32 v9,s5,v157  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'accum[123:123]'v157 alloc 'idst'v9    s:11(35) v:19(161) a:0(0)    sid:2281 idst,sgpr_const_32768,accum[123:123],;	v9 = s5 + v157
	v_perm_b32 v13,v5,v9,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:248 free 'idst'v5 free 'idst'v9   sid:2282 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v5,s5,v158  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[124:124]'v158 alloc 'idst'v5    s:11(35) v:17(161) a:0(0)    sid:2283 idst,sgpr_const_32768,accum[124:124],;	v5 = s5 + v158
	v_add_f32 v9,s5,v159  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'accum[125:125]'v159 alloc 'idst'v9    s:11(35) v:17(161) a:0(0)    sid:2284 idst,sgpr_const_32768,accum[125:125],;	v9 = s5 + v159
	v_perm_b32 v14,v5,v9,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:249 free 'idst'v5 free 'idst'v9   sid:2285 packed,idst,idst,sgpr_const_50464518,
	v_add_f32 v5,s5,v160  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'accum[126:126]'v160 alloc 'idst'v5    s:11(35) v:15(161) a:0(0)    sid:2286 idst,sgpr_const_32768,accum[126:126],;	v5 = s5 + v160
	v_add_f32 v9,s5,v161  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'sgpr_const_32768's5 free 'accum[127:127]'v161 alloc 'idst'v9    s:10(35) v:15(15) a:0(0)    sid:2287 idst,sgpr_const_32768,accum[127:127],;	v9 = s5 + v161
	v_perm_b32 v15,v5,v9,s6  ; # asmjit.py:3958 gemm_fp8_gfx942.py:250 free 'sgpr_const_50464518's6 free 'idst'v5 free 'idst'v9   sid:2288 packed,idst,idst,sgpr_const_50464518,
	ds_bpermute_b32 v6,v1,v12  ; # gemm_fp8_gfx942.py:252   sid:2289 exchanged[0:0],exchange_lane,packed,;	v6 = v12.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v7,v1,v13  ; # gemm_fp8_gfx942.py:252   sid:2290 exchanged[1:1],exchange_lane,packed,;	v7 = v13.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v8,v1,v14  ; # gemm_fp8_gfx942.py:252   sid:2291 exchanged[2:2],exchange_lane,packed,;	v8 = v14.lane[ (v1)/4 % 64 ];   select source lane with v1
	ds_bpermute_b32 v10,v1,v15  ; # gemm_fp8_gfx942.py:252 free 'exchange_lane'v1   sid:2292 exchanged[3:3],exchange_lane,packed,;	v10 = v15.lane[ (v1)/4 % 64 ];   select source lane with v1
	s_waitcnt  lgkmcnt(0) ; # gemm_fp8_gfx942.py:253   sid:2293 
	v_cmp_ne_u32 vcc,v3,0x0  ; # gemm_fp8_gfx942.py:254 free 'odd_group'v3   sid:2294 vcc,odd_group,0,;	vcc.u64[laneId] = (v3.u32  <> 0x0.u32 )
	v_cndmask_b32 v12,v12,v8,vcc  ; # gemm_fp8_gfx942.py:256 free 'exchanged[2:2]'v8   sid:2295 packed,packed,exchanged[2:2],vcc,;	v12.b32 = vcc.u64[laneId] ? v8.u32 : v12.u32
	v_cndmask_b32 v14,v6,v14,vcc  ; # gemm_fp8_gfx942.py:257 free 'exchanged[0:0]'v6   sid:2296 packed,exchanged[0:0],packed,vcc,;	v14.b32 = vcc.u64[laneId] ? v14.u32 : v6.u32
	v_cndmask_b32 v13,v13,v10,vcc  ; # gemm_fp8_gfx942.py:256 free 'exchanged[3:3]'v10   sid:2297 packed,packed,exchanged[3:3],vcc,;	v13.b32 = vcc.u64[laneId] ? v10.u32 : v13.u32
	v_cndmask_b32 v15,v7,v15,vcc  ; # gemm_fp8_gfx942.py:257 free 'exchanged[1:1]'v7   sid:2298 packed,exchanged[1:1],packed,vcc,;	v15.b32 = vcc.u64[laneId] ? v15.u32 : v7.u32
	v_cmp_gt_u32_e32 vcc,0x1000,v2  ; # asmjit.py:1520 contextlib.py:137 free 'column'v2   sid:2299 vcc,4096,column,;	vcc.u64[laneId] = (0x1000.u32  > v2.u32 )
	s_and_saveexec_b64 s[6:7],vcc  ; # asmjit.py:1524 contextlib.py:137 alloc 'ExecMask_exec_backup's[6:7]    s:11(35) v:6(15) a:0(0)    sid:2300 ExecMask_exec_backup,vcc,;	exec=vcc&exec; s[6:7]=old_exec; scc=(exec!=0)
	s_cbranch_execz  _execmask_end_258_19 ; # asmjit.py:1526 contextlib.py:137   sid:2301;	jump if execz is 1 (exec mask == 0)
_bb_no_name_84:	 ;BB#84 predecessors:[_execmask_end_258_18] successors:[_execmask_end_258_19]
	buffer_store_dwordx4 v[12:15],v4,s[32:35],0x0 offen  ; # asmjit.py:829 gemm_fp8_gfx942.py:259 free 'self.desc's[32:35] free 'offset'v4 free 'packed'v[12:15]   sid:2302 packed,offset,self.desc,0,
_execmask_end_258_19:	 ;BB#85 predecessors:[_bb_no_name_84,_execmask_end_258_18] successors:[]
	s_mov_b64 exec,s[6:7]  ; # asmjit.py:1532 contextlib.py:144 free 'ExecMask_exec_backup's[6:7]   sid:2303 exec,ExecMask_exec_backup,;	exec = s[6:7]

	;;#ASMEND
	s_mov_b32 s0, 0                                  ;	s0 = 0
	;;#ASMSTART
	 ; lds_buffer s0 
	;;#ASMEND
	;;#ASMSTART
	.pushsection .rodata
    .align 8
    .asciz  ".git:unknown"
    .popsection
	;;#ASMEND
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
		.amdhsa_group_segment_fixed_size 32768
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 44
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_kernarg_preload_length 0
		.amdhsa_user_sgpr_kernarg_preload_offset 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 1
		.amdhsa_system_sgpr_workgroup_id_z 1
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 240
		.amdhsa_next_free_sgpr 36
		.amdhsa_accum_offset 240
		.amdhsa_reserve_vcc 0
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_tg_split 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i, .Lfunc_end0-_Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
                                        ; -- End function
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.num_vgpr, 240
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.num_agpr, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.numbered_sgpr, 36
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.num_named_barrier, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.private_seg_size, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.uses_vcc, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.uses_flat_scratch, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.has_dyn_sized_stack, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.has_recursion, 0
	.set _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.has_indirect_call, 0
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 18808
; TotalNumSgprs: 42
; NumVgprs: 240
; NumAgprs: 0
; TotalNumVgprs: 240
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 32768 bytes/workgroup (compile time only)
; SGPRBlocks: 5
; VGPRBlocks: 29
; NumSGPRsForWavesPerEU: 42
; NumVGPRsForWavesPerEU: 240
; AccumOffset: 240
; Occupancy: 2
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 2
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 1
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX90A:ACCUM_OFFSET: 59
; COMPUTE_PGM_RSRC3_GFX90A:TG_SPLIT: 0
	.text
	.p2alignl 6, 3212836864
	.fill 256, 4, 3212836864
	.section	.AMDGPU.gpr_maximums,"",@progbits
	.set amdgpu.max_num_vgpr, 0
	.set amdgpu.max_num_agpr, 0
	.set amdgpu.max_num_sgpr, 0
	.text
	.type	__hip_cuid_b19f1dc33ad2f374,@object ; @__hip_cuid_b19f1dc33ad2f374
	.section	.bss,"aw",@nobits
	.globl	__hip_cuid_b19f1dc33ad2f374
__hip_cuid_b19f1dc33ad2f374:
	.byte	0                               ; 0x0
	.size	__hip_cuid_b19f1dc33ad2f374, 1

	.ident	"AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.4 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __hip_cuid_b19f1dc33ad2f374
	.amdgpu_metadata
---
amdhsa.kernels:
  - .agpr_count:     0
    .args:
      - .address_space:  global
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         24
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .offset:         32
        .size:           8
        .value_kind:     global_buffer
      - .offset:         40
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 32768
    .kernarg_segment_align: 8
    .kernarg_segment_size: 44
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 1024
    .name:           _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i
    .private_segment_fixed_size: 0
    .sgpr_count:     42
    .sgpr_spill_count: 0
    .symbol:         _Z33gemm_a8w8_blockscale_8wave_gfx942PvS_S_PfS0_i.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     240
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx942
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
