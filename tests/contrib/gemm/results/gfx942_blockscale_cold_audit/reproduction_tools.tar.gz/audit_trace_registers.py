import argparse
from collections import Counter
import json
from pathlib import Path
import re


def registers(text):
    result = set()
    for match in re.finditer(r"\b([vsa])(?:\[(\d+):(\d+)\]|(\d+))(?![A-Za-z0-9_])", text):
        kind, first, last, single = match.groups()
        if single is not None:
            result.add((kind, int(single)))
        else:
            result.update((kind, index) for index in range(int(first), int(last) + 1))
    return result


assert registers("v[12:15], v4, s[8:11], s0") == {("v", index) for index in (4, 12, 13, 14, 15)} | {("s", index) for index in (0, 8, 9, 10, 11)}


parser = argparse.ArgumentParser()
parser.add_argument("trace", type=Path)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
code = {}
for row in json.loads((args.trace / "code.json").read_text())["code"]:
    text = str(row[0]).split(";", 1)[0].strip()
    opcode = text.split()[0] if text else ""
    operands = text[len(opcode):].strip()
    first, separator, remaining = operands.partition(",")
    is_load = opcode.startswith(("buffer_load", "global_load", "s_load", "ds_read", "ds_bpermute", "ds_swizzle"))
    has_destination = is_load or opcode.startswith(("v_", "s_mov", "s_add", "s_sub", "s_mul", "s_lsh", "s_lshr", "s_ashr", "s_and", "s_xor", "s_abs", "s_min", "s_max", "s_cselect"))
    destination = registers(first) if has_destination else set()
    sources = registers(remaining) if has_destination else registers(operands)
    if opcode.startswith("v_fmac"):
        sources.update(destination)
    code[int(row[2])] = (text, opcode, destination, sources)

counts = Counter()
minimum_mfma_read_margin = None
for path in sorted(args.trace.glob("se*_sm*_sl*_wv*.json")):
    data = json.loads(path.read_text())
    assert data["num_insts"] == data["num_stitched"], path
    pending_vm = []
    pending_lgkm = []
    conservative_smem = set()
    mfma_ready = {}
    for record in data["wave"]["instructions"]:
        text, opcode, destination, sources = code[int(record[4])]
        issue = int(record[0]) + int(record[2])
        if opcode == "s_waitcnt":
            vm = re.search(r"vmcnt\((\d+)\)", text)
            lgkm = re.search(r"lgkmcnt\((\d+)\)", text)
            if vm:
                budget = int(vm.group(1))
                pending_vm = pending_vm[-budget:] if budget else []
            if lgkm:
                budget = int(lgkm.group(1))
                pending_lgkm = pending_lgkm[-budget:] if budget else []
                if budget == 0:
                    conservative_smem.clear()
            counts["waits_checked"] += 1
            continue
        pending = set().union(*pending_vm, *pending_lgkm, conservative_smem)
        assert not sources & pending, (path.name, record[4], "async load-use without completing wait", text, sorted(sources & pending))
        assert not destination & pending, (path.name, record[4], "async register overwritten", text, sorted(destination & pending))
        for register in sources:
            if register in mfma_ready:
                margin = issue - mfma_ready[register]
                assert margin >= 0, (path.name, "MFMA result read before modeled completion", text, margin)
                minimum_mfma_read_margin = margin if minimum_mfma_read_margin is None else min(minimum_mfma_read_margin, margin)
                counts["mfma_result_reads_checked"] += 1
        for register in destination:
            mfma_ready.pop(register, None)
        if opcode.startswith(("buffer_load", "global_load")):
            pending_vm.append(destination)
        elif opcode.startswith(("buffer_store", "global_store")):
            pending_vm.append(set())
        elif opcode.startswith("s_load"):
            pending_lgkm.append(destination)
            conservative_smem.update(destination)
        elif opcode.startswith(("ds_read", "ds_bpermute", "ds_swizzle")):
            pending_lgkm.append(destination)
        elif opcode.startswith("ds_write"):
            pending_lgkm.append(set())
        if opcode.startswith("v_mfma"):
            for register in destination:
                mfma_ready[register] = issue + 16
        counts["instructions_checked"] += 1
    counts["complete_waves_checked"] += 1

assert counts["mfma_result_reads_checked"] > 0 and minimum_mfma_read_margin is not None
report = {
    "trace": str(args.trace), "counts": dict(counts),
    "minimum_mfma_read_margin_cycles": minimum_mfma_read_margin,
    "violations": [],
    "semantics": "Track async destinations in actual dynamic ISA; native buffer waits retire oldest operations, mixed SMEM kept pending until lgkmcnt(0). MFMA read timing uses a 16-cycle window.",
    "scope": "Recorded wave executions; cross-wave LDS lifetime is checked separately by the source/barrier protocol model.",
}
args.output.write_text(json.dumps(report, indent=2) + "\n")
print("ISA_REGISTER_AUDIT_PASS", dict(counts), "minimum_MFMA_read_margin", minimum_mfma_read_margin)