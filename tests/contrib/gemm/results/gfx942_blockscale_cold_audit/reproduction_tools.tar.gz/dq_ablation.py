import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def instruction(line):
    code = line.split(";", 1)[0].strip()
    if not code or code.endswith(":") or code.startswith("."):
        return None
    opcode = code.split()[0]
    return opcode if opcode.startswith(("v_", "s_", "ds_", "buffer_", "global_", "flat_")) else None


parser = argparse.ArgumentParser()
parser.add_argument("--source-isa", required=True, type=Path)
parser.add_argument("--output-isa", required=True, type=Path)
parser.add_argument("--output-co", required=True, type=Path)
parser.add_argument("--report", required=True, type=Path)
args = parser.parse_args()
source = args.source_isa.read_text()
lines = source.splitlines(keepends=True)
removed = []
kept = []
for line in lines:
    opcode = instruction(line)
    if opcode == "v_fmac_f32" or (opcode == "v_mul_f32" and "partial_scale" in line):
        removed.append(line.strip())
    else:
        kept.append(line)
assert removed and any(line.startswith("v_fmac_f32") for line in removed)
assert any(line.startswith("v_mul_f32") for line in removed)
candidate = "".join(kept)
args.output_isa.write_text(candidate)
subprocess.run([
    "/opt/rocm/llvm/bin/clang++", "-x", "assembler", "-target", "amdgcn-amd-amdhsa",
    "-mcpu=gfx942", str(args.output_isa), "-o", str(args.output_co),
], check=True)
memory_prefixes = ("buffer_", "global_", "flat_", "ds_", "s_load", "s_waitcnt", "s_barrier", "v_mfma")
original_memory = [line.split(";", 1)[0].strip() for line in lines if (instruction(line) or "").startswith(memory_prefixes)]
candidate_memory = [line.split(";", 1)[0].strip() for line in kept if (instruction(line) or "").startswith(memory_prefixes)]
assert original_memory == candidate_memory
metadata = [line.strip() for line in lines if line.strip().startswith((".amdhsa_", ".group_segment_fixed_size", ".private_segment_fixed_size", ".sgpr_count", ".vgpr_count"))]
assert metadata == [line.strip() for line in kept if line.strip().startswith((".amdhsa_", ".group_segment_fixed_size", ".private_segment_fixed_size", ".sgpr_count", ".vgpr_count"))]
report = {
    "kind": "NO_DQ_DIAGNOSTIC_NOT_A_CORRECT_GEMM",
    "source_isa": str(args.source_isa), "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
    "candidate_isa": str(args.output_isa), "candidate_isa_sha256": hashlib.sha256(candidate.encode()).hexdigest(),
    "candidate_co": str(args.output_co), "candidate_co_sha256": hashlib.sha256(args.output_co.read_bytes()).hexdigest(),
    "removed_instructions": removed,
    "removed_count": len(removed),
    "memory_mfma_wait_barrier_sequence_unchanged": True,
    "resource_metadata_unchanged": True,
    "resource_metadata": metadata,
    "caveat": "Scale loads remain to preserve the memory schedule. Removing DQ changes code size/PC alignment and dynamic arbitration; elapsed-time difference is not exclusively DQ latency. Output is expected to be zero, not a GEMM reference.",
}
args.report.write_text(json.dumps(report, indent=2) + "\n")
print("DQ_ABLATION_BUILT", len(removed), "removed; memory/MFMA/waits/resources preserved")