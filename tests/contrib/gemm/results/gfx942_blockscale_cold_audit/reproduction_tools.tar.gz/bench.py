import argparse
import hashlib
import importlib.util
import json
import os
import statistics
import threading
import time
from pathlib import Path

import amdsmi

TEST = "/mywork/pyhip/tests/contrib/gemm/test_a8w8_f32_blockscale.py"
KERNEL = "/mywork/pyhip/src/contrib/gemm_fp8_gfx942.py"
HWMON = Path("/sys/bus/pci/devices/0000:0a:00.0/hwmon/hwmon0")


class Telemetry:
    def __init__(self):
        self.samples = []
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self.run, daemon=True)

    def run(self):
        while not self.stop_event.wait(0.005):
            self.samples.append((time.monotonic_ns(),
                                 int((HWMON / "freq1_input").read_text()) / 1e6,
                                 int((HWMON / "power1_input").read_text()) / 1e6))

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *exc):
        self.stop_event.set()
        self.thread.join()

parser = argparse.ArgumentParser()
parser.add_argument("--output", required=True)
parser.add_argument("--repeats", type=int, default=32)
parser.add_argument("--shapes", default="4096,4096,16384;16384,3584,6144;16384,3392,6144")
parser.add_argument("--layouts", default="0,1")
args = parser.parse_args()

amdsmi.amdsmi_init()
handle = amdsmi.amdsmi_get_processor_handles()[0]
gates = []


def snapshot(stage):
    memory = amdsmi.amdsmi_get_gpu_vram_usage(handle)
    record = {
        "stage": stage,
        "time_ns": time.monotonic_ns(),
        "bdf": amdsmi.amdsmi_get_gpu_device_bdf(handle),
        "activity": amdsmi.amdsmi_get_gpu_activity(handle),
        "vram_used_mb": memory["vram_used"],
        "vram_total_mb": memory["vram_total"],
        "ptl": amdsmi.amdsmi_get_gpu_ptl_state(handle),
        "formats": [amdsmi.AmdSmiPtlData(v).name for v in amdsmi.amdsmi_get_gpu_ptl_formats(handle)],
        "pids": sorted({int(p["pid"]) for p in amdsmi.amdsmi_get_gpu_process_list(handle)}),
    }
    gates.append(record)
    print("GATE", json.dumps(record), flush=True)
    assert record["ptl"] and set(record["formats"]) == {"VECTOR", "F8"}, record
    assert record["vram_used_mb"] <= 0.2 * record["vram_total_mb"], record
    if stage == "entry":
        # Before this process touches the GPU, the device itself must be idle.
        assert record["activity"]["gfx_activity"] <= 5 and not record["pids"], record
    else:
        # amdsmi reports host PIDs; entry had none, so a single new PID is this process.
        assert len(record["pids"]) <= 1, record


snapshot("entry")
spec = importlib.util.spec_from_file_location("gemm_test", TEST)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

results = []
for shape in args.shapes.split(";"):
    m, n, k = (int(v) for v in shape.split(","))
    for layout in args.layouts.split(","):
        preshuffle = bool(int(layout))
        with Telemetry() as telemetry:
            report = module.bench_gfx942(
                m, n, k, args.repeats, preshuffle_b=preshuffle,
                sample_gate=lambda stage, tag=f"{shape}:{preshuffle}": snapshot(f"{tag}:{stage}"),
            )
        begin = next(g["time_ns"] for g in gates if g["stage"].endswith(f"{shape}:{preshuffle}:before_samples"))
        end = next(g["time_ns"] for g in gates if g["stage"].endswith(f"{shape}:{preshuffle}:after_samples"))
        window = [s for s in telemetry.samples if begin <= s[0] <= end]
        report["telemetry"] = {
            "samples": telemetry.samples,
            "window_samples": len(window),
            "busy_sclk_median_mhz": statistics.median(s[1] for s in window) if window else None,
            "busy_ppt_median_w": statistics.median(s[2] for s in window) if window else None,
        }
        results.append(report)
snapshot("exit")

cache = Path(os.environ.get("PYHIP_CACHE_DIR", os.path.expanduser("~/.pyhip")))
artifacts = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(cache.glob("gemm_a8w8_blockscale_8wave_gfx942*.co"))}
Path(args.output).write_text(json.dumps({
    "kernel_sha256": hashlib.sha256(Path(KERNEL).read_bytes()).hexdigest(),
    "test_sha256": hashlib.sha256(Path(TEST).read_bytes()).hexdigest(),
    "artifacts": artifacts,
    "gates": gates,
    "results": results,
}, indent=1))
for r in results:
    t = r["telemetry"]
    print(f"SUMMARY {r['shape']} preshuffle={r['preshuffle_b']} median={r['median_us']:.1f}us "
          f"{r['median_tflops']:.1f}TF max={r['max_tflops']:.1f}TF diff={r['diff']:.2e} "
          f"window_sclk={t['busy_sclk_median_mhz']}MHz ppt={t['busy_ppt_median_w']}W n={t['window_samples']}")
amdsmi.amdsmi_shut_down()
