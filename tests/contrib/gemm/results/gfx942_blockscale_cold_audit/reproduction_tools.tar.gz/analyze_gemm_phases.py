import argparse
from collections import defaultdict
import json
from pathlib import Path
import re


def union(intervals):
    merged = []
    for start, end in sorted(intervals):
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return merged


def overlap(intervals, start, end):
    return sum(max(0, min(stop, end) - max(begin, start)) for begin, stop in intervals)


parser = argparse.ArgumentParser()
parser.add_argument("trace", type=Path)
parser.add_argument("--k-blocks", type=int, default=128)
parser.add_argument("--mfma-per-k", type=int, default=128)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
code = {int(row[2]): str(row[0]).strip() for row in json.loads((args.trace / "code.json").read_text())["code"]}
groups = defaultdict(lambda: defaultdict(list))
total_waves = 0
for path in sorted(args.trace.glob("se*_sm*_sl*_wv*.json")):
    payload = json.loads(path.read_text())
    assert payload["num_insts"] == payload["num_stitched"], path
    wave = payload["wave"]
    mfma = []
    for record in wave["instructions"]:
        opcode = code[int(record[4])]
        if opcode.startswith("v_mfma_f32_16x16x32_fp8_fp8"):
            issue = int(record[0]) + int(record[2])
            mfma.append([issue, issue + 16])
    assert len(mfma) == args.k_blocks * args.mfma_per_k, (path, len(mfma))
    shader_engine = int(re.match(r"se(\d+)", path.name).group(1))
    key = (shader_engine, int(wave["cu"]), int(wave["simd"]))
    groups[key][int(wave["slot"])].append({
        "file": path.name, "begin": int(wave["begin"]), "end": int(wave["end"]),
        "main_start": mfma[args.mfma_per_k][0],
        "main_end": mfma[(args.k_blocks - 1) * args.mfma_per_k][0],
        "mfma": mfma,
    })
    total_waves += 1

totals = {name: {"cycles": 0, "mfma_busy_cycles": 0} for name in ("prologue", "mainloop", "epilogue")}
batches = []
for key, slots in sorted(groups.items()):
    assert len(slots) == 2, (key, slots.keys())
    per_slot = [sorted(waves, key=lambda wave: wave["begin"]) for waves in slots.values()]
    assert len(per_slot[0]) == len(per_slot[1])
    for batch in zip(*per_slot):
        start = min(wave["begin"] for wave in batch)
        end = max(wave["end"] for wave in batch)
        main_start = max(wave["main_start"] for wave in batch)
        main_end = min(wave["main_end"] for wave in batch)
        assert start < main_start < main_end < end
        intervals = union([interval for wave in batch for interval in wave["mfma"]])
        windows = {"prologue": (start, main_start), "mainloop": (main_start, main_end), "epilogue": (main_end, end)}
        parts = {}
        for name, (begin, stop) in windows.items():
            busy = overlap(intervals, begin, stop)
            parts[name] = {"cycles": stop - begin, "mfma_busy_cycles": busy, "mfma_efficiency": busy / (stop - begin)}
            totals[name]["cycles"] += stop - begin
            totals[name]["mfma_busy_cycles"] += busy
        assert sum(part["cycles"] for part in parts.values()) == end - start
        batches.append({"physical_simd": key, "wave_files": [wave["file"] for wave in batch], "phases": parts})
lifetime = sum(part["cycles"] for part in totals.values())
for part in totals.values():
    part["mean_cycles_per_resident_batch"] = part["cycles"] / len(batches)
    part["lifetime_fraction"] = part["cycles"] / lifetime
    part["mfma_efficiency"] = part["mfma_busy_cycles"] / part["cycles"]
report = {
    "trace": str(args.trace), "complete_waves": total_waves,
    "physical_simds": len(groups), "resident_batches": len(batches),
    "definitions": {
        "prologue": "resident-batch begin until both waves reach the first MFMA of K block 1; includes startup and K block 0",
        "mainloop": "both resident waves are within K blocks 1..K_blocks-2",
        "epilogue": "first resident wave reaches final K block until both waves end; includes final K block, DQ drain, conversion and stores",
        "mfma_efficiency": "union of 16-cycle MFMA windows, starting at successful issue (attempt+stall), divided by phase cycles",
    },
    "scope": "sampled physical SIMD union, not whole-GPU utilization or ordinary kernel latency",
    "phases": totals,
    "full_lifetime_mfma_efficiency": sum(part["mfma_busy_cycles"] for part in totals.values()) / lifetime,
    "batches": batches,
}
args.output.write_text(json.dumps(report, indent=2) + "\n")
print("PHASES", json.dumps(totals), "full", report["full_lifetime_mfma_efficiency"])