import argparse
import ast
import hashlib
import json
from pathlib import Path


def load_schedule(source, depth):
    tree = ast.parse(source)
    kernel = next(node for node in tree.body if isinstance(node, ast.FunctionDef))
    names = {"k_blocks", "total_packets", "a_order", "a_stages", "requests", "wait_budgets"}
    selected = []
    for node in kernel.body:
        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id in names for target in node.targets):
            selected.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name == "stage_tokens":
            selected.append(node)
        elif isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == "q":
            selected.append(node)
    namespace = {"K": depth}
    exec(compile(ast.Module(body=selected, type_ignores=[]), "kernel_schedule", "exec"), namespace)
    order = next(node.value for node in tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "MFMA_ORDER" for target in node.targets))
    namespace["order"] = eval(compile(ast.Expression(order), "mfma_order", "eval"))
    return namespace


def vm_register_lifetimes(schedule, loosen_wait=False):
    pending = []
    ready = {}
    loaded = set()
    consumed_b = set()
    current_packet = -1
    checks = 0

    def location(token):
        if token[0] == "b":
            return ("b", 0 if token[1] == 0 else (token[1] - 1) % 2)
        return ("a", token[1] % 2, token[2])

    def issue(token):
        nonlocal checks
        key = location(token)
        assert all(location(old) != key for old in pending), ("pending register overwritten", token)
        old = ready.get(key)
        if old is not None:
            if old[0] == "b":
                assert old in consumed_b, ("B staging reused before LDS submission", old)
            else:
                assert current_packet >= (old[1] + 1) * 4, ("A reused before final phase", old)
        pending.append(token)
        loaded.add(token)
        checks += 1

    def wait(budget):
        nonlocal checks
        assert 0 <= budget <= 63
        while len(pending) > budget:
            token = pending.pop(0)
            ready[location(token)] = token
        checks += 1

    def consume(token):
        nonlocal checks
        key = location(token)
        assert all(location(old) != key for old in pending), ("load still pending", token)
        assert ready.get(key) == token, ("wrong register generation", token, ready.get(key))
        if token[0] == "b":
            consumed_b.add(token)
        checks += 1

    issue(("b", 0))
    for part in schedule["a_order"]:
        issue(("a", 0, part))
    wait(len(schedule["a_order"]))
    consume(("b", 0))
    issue(("b", 1))
    issue(("b", 2))
    wait(2)
    for current_packet in range(schedule["total_packets"]):
        budget = schedule["wait_budgets"][current_packet]
        if budget is not None:
            wait(budget + int(loosen_wait))
            consume(("b", current_packet + 1))
        for token in schedule["stage_tokens"](current_packet):
            issue(token)
        for part in schedule["a_order"]:
            consume(("a", current_packet // 4, part))
    assert not pending
    assert consumed_b == {("b", packet) for packet in range(schedule["total_packets"])}
    assert all(token[1] < (schedule["total_packets"] if token[0] == "b" else schedule["k_blocks"]) for token in loaded)
    return checks


def partial_lifetimes(schedule):
    states = [{"phase": -1, "step": 3, "read": set(), "last_issue": -100} for _ in range(4)]
    minimum_distance = 100
    checks = 0
    phase_count = schedule["total_packets"] * 2
    for phase in range(phase_count):
        for index, (partial, step) in enumerate(schedule["order"]):
            state = states[partial]
            if step == 0:
                assert state["phase"] < 0 or state["read"] == {0, 1, 2, 3}, ("partial overwritten before DQ", phase, partial)
                states[partial] = {"phase": phase, "step": 0, "read": set(), "last_issue": phase * 16 + index}
            else:
                assert state["phase"] == phase and state["step"] == step - 1
                state.update(step=step, last_issue=phase * 16 + index)
            if index < 8:
                expected_phase, retired = phase - 1, 2 + index // 4
            else:
                expected_phase, retired = phase, (index - 8) // 4
            state = states[retired]
            assert state["phase"] == expected_phase and state["step"] == 3
            assert index % 4 not in state["read"]
            state["read"].add(index % 4)
            if expected_phase >= 0:
                distance = phase * 16 + index - state["last_issue"]
                minimum_distance = min(minimum_distance, distance)
                assert distance >= 2
            checks += 1
    for partial in (2, 3):
        assert states[partial]["phase"] == phase_count - 1 and states[partial]["step"] == 3
        states[partial]["read"].update(range(4))
    assert all(state["read"] == {0, 1, 2, 3} for state in states)
    return checks, minimum_distance


def lds_lifetimes(schedule, slots=4):
    checks = 0
    for packet in range(schedule["total_packets"]):
        latest_write_release = 0 if packet == 0 else 2 * packet
        for group in range(2):
            earliest_read_begin = 2 * packet + group
            latest_read_retirement = 2 * packet + 2 + group
            assert latest_write_release <= earliest_read_begin
            if packet + slots < schedule["total_packets"]:
                earliest_overwrite = 2 * (packet + slots - 1)
                assert latest_read_retirement < earliest_overwrite
            checks += 1
    return checks


def lds_layout():
    checks = 0
    for preshuffle in (False, True):
        offsets = []
        for thread in range(512):
            wave, lane = divmod(thread, 64)
            if preshuffle:
                row, column = (wave // 2) * 16 + lane % 16, (wave % 2) * 4 + lane // 16
            else:
                row, column = divmod(thread, 8)
            offsets.append(row * 128 + ((row ^ column) % 8) * 16)
        assert sorted(offsets) == list(range(0, 8192, 16))
        for packet in range(4):
            for rep_n in range(4):
                for half_k in range(2):
                    for lane in range(64):
                        row, column = lane % 16 + rep_n * 16, lane // 16 + half_k * 4
                        offset = row * 128 + ((row ^ column) % 8) * 16
                        assert offset in offsets
                        assert packet * 8192 + offset + 16 <= 32768
                        checks += 1
    return checks


def global_bounds():
    checks = 0
    for rows in (1, 17, 127, 128, 129, 255, 256):
        for columns in (16, 32, 64, 128, 192, 256):
            for depth in (128, 256, 384, 16384):
                for thread in range(512):
                    wave, lane = divmod(thread, 64)
                    for m_slice in range(2):
                        row = wave * 16 + lane % 16 + m_slice * 128
                        for half in range(2):
                            vector = row * depth + (lane // 16 + half * 4) * 16
                            if vector < rows * depth:
                                assert vector + depth - 128 + 16 <= rows * depth
                            else:
                                assert row >= rows
                            checks += 1
                    for packet in range(4):
                        plain = (thread // 8 + packet * 64) * depth + (thread % 8) * 16
                        shuffled = (wave // 2 + packet * 4) * 16 * depth + (wave % 2) * 1024 + lane * 16
                        for vector, scalar in ((plain, depth - 128), (shuffled, (depth - 128) * 16)):
                            if vector < columns * depth:
                                assert vector + scalar + 16 <= columns * depth
                            checks += 1
    return checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    source = args.source.read_text()
    assert 'J.s_waitcnt(mod="lgkmcnt(8)")' in source
    assert 'J.s_waitcnt(mod="lgkmcnt(0)")' in source
    assert 'J.s_nop(15)' in source
    assert 'lds_b = J.alloc_lds(4 * packet_bytes)' in source
    cases = []
    for blocks in (*range(1, 18), 31, 32, 63, 64, 127, 128, 129, 255):
        schedule = load_schedule(source, blocks * 128)
        vm_checks = vm_register_lifetimes(schedule)
        partial_checks, distance = partial_lifetimes(schedule)
        lds_checks = lds_lifetimes(schedule)
        try:
            vm_register_lifetimes(schedule, loosen_wait=True)
        except AssertionError:
            negative_caught = True
        else:
            raise AssertionError("loosened vmcnt escaped the audit")
        try:
            lds_lifetimes(schedule, slots=2)
        except AssertionError:
            overwrite_caught = True
        else:
            raise AssertionError("early LDS reuse escaped the audit")
        cases.append({"k_blocks": blocks, "vm_checks": vm_checks, "partial_checks": partial_checks,
                      "lds_checks": lds_checks, "minimum_mfma_distance": distance,
                      "wrong_wait_negative_control_caught": negative_caught,
                      "early_lds_reuse_negative_control_caught": overwrite_caught})
    report = {
        "source": str(args.source), "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
        "cases": cases, "global_buffer_bounds_checks": global_bounds(),
        "lds_layout_checks": lds_layout(),
        "lds_slots": 4, "lds_bytes": 32768,
        "protocol": {
            "B_packet_publication": "Q[p] fully published by barrier generation 2*p",
            "B_packet_read": "group g starts at generation 2*p+g; retires reads before 2*p+2+g",
            "B_slot_overwrite": "Q[p+4] first written after generation 2*p+6; latest old read retirement is 2*p+3",
            "A": "two register banks; prefetch k+1 never overwrites k; k-start wait covers all A and A-scale producers",
            "B_staging": "two banks; VM wait completes Q[p+1] before ds_write; same bank then receives Q[p+3]",
            "B_scale": "next-bank SMEM issued at packet 1 after compute-entry lgkmcnt(0); later compute-entry lgkmcnt(0) completes it before next K",
            "partial": "each partial is retired before overwrite; MFMA and DQ use distinct current/previous partials",
            "early_barrier": "preshuffle barrier precedes only final register-only MFMA/DQ; every LDS read is already complete",
            "epilogue": "full-wave lane exchange precedes masked stores; final group0 barrier balances group1 entry",
        },
        "assumptions": ["native gfx942 buffer and DS wait-counter completion semantics", "M>0, N%16=0, K>=128 and K%128=0", "32-bit buffer offsets and extents do not overflow", "correct 512-thread launch and exact grid"],
        "scope": "source-derived logical lifetime and address proof, not a hardware race detector or proof for arbitrary unsupported shapes",
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print("PIPELINE_AUDIT_PASS", len(cases), "K lengths; bounds", report["global_buffer_bounds_checks"])


if __name__ == "__main__":
    main()