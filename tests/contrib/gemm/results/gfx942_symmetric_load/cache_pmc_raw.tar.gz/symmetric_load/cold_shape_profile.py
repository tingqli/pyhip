import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import statistics
import time

import amdsmi
import torch
import pyhip
from pyhip.core.hiptools import _build_hip_func


parser = argparse.ArgumentParser()
parser.add_argument("--baseline", required=True, type=Path)
parser.add_argument("--no-dq", required=True, type=Path)
parser.add_argument("--mode", choices=("compare", "profile-baseline", "profile-no-dq"), required=True)
parser.add_argument("--output", required=True, type=Path)
parser.add_argument("--shape", default="8192,8192,16384")
parser.add_argument("--pmc-diagnostic", action="store_true")
args = parser.parse_args()
if args.pmc_diagnostic:
    assert args.mode == "profile-baseline"
rows, columns, depth = map(int, args.shape.split(","))
flops = 2 * rows * columns * depth
symbol = "gemm_a8w8_blockscale_8wave_gfx942"
amdsmi.amdsmi_init()
handle = amdsmi.amdsmi_get_processor_handles()[0]
gates = []


def gate(stage):
    memory = amdsmi.amdsmi_get_gpu_vram_usage(handle)
    record = {
        "stage": stage, "bdf": amdsmi.amdsmi_get_gpu_device_bdf(handle),
        "activity": amdsmi.amdsmi_get_gpu_activity(handle), "memory": memory,
        "pids": [int(process["pid"]) for process in amdsmi.amdsmi_get_gpu_process_list(handle)],
        "ptl": amdsmi.amdsmi_get_gpu_ptl_state(handle),
    }
    try:
        record["formats"] = [amdsmi.AmdSmiPtlData(value).name for value in amdsmi.amdsmi_get_gpu_ptl_formats(handle)]
    except amdsmi.AmdSmiLibraryException as error:
        if not args.pmc_diagnostic:
            raise
        record["formats"] = None
        record["formats_error"] = str(error)
    record["ordinary_perf_ptl_gate_passed"] = record["ptl"] and set(record["formats"] or ()) == {"VECTOR", "F8"}
    gates.append(record)
    print("GATE", json.dumps(record), flush=True)
    if args.pmc_diagnostic:
        args.output.write_text(json.dumps({"status": "collecting_pmc", "gates": gates}, indent=1) + "\n")
        assert (record["ptl"], record["formats"]) == (gates[0]["ptl"], gates[0]["formats"])
    else:
        assert record["ordinary_perf_ptl_gate_passed"]
    assert memory["vram_used"] <= memory["vram_total"] * 0.2
    if stage == "entry":
        assert record["activity"]["gfx_activity"] <= 5
        if args.pmc_diagnostic:
            assert len(record["pids"]) <= 1
        else:
            assert not record["pids"]
    else:
        assert len(record["pids"]) <= 1


gate("entry")
spec = importlib.util.spec_from_file_location("gemm_test", "/mywork/pyhip/tests/contrib/gemm/test_a8w8_f32_blockscale.py")
test = importlib.util.module_from_spec(spec)
spec.loader.exec_module(test)
torch.manual_seed(0)
activation = (torch.rand((rows, depth), device="cuda") / 10).to(test.dtypes.fp8)
weight = (torch.rand((columns, depth), device="cuda") / 10).to(test.dtypes.fp8)
scale_a = torch.rand((rows, depth // 128), device="cuda")
scale_b = torch.rand((columns // 128, depth // 128), device="cuda")
reference = test.run_torch(activation, weight, scale_a, scale_b).cpu()
weight = test.shuffle_weight(weight, layout=(16, 16))
scale_a = scale_a.T.contiguous()
buffers = [tuple(tensor.clone() for tensor in (activation, weight, scale_a, scale_b)) for _ in range(32)]
output = torch.empty((rows, columns), dtype=torch.bfloat16, device="cuda")
selected = ("baseline", "no_dq") if args.mode == "compare" else (("baseline",) if args.mode == "profile-baseline" else ("no_dq",))
paths = {"baseline": args.baseline, "no_dq": args.no_dq}
kernels = {name: _build_hip_func(str(paths[name]), "", None, symbol) for name in selected}
intervals = sorted((tensor.data_ptr(), tensor.data_ptr() + tensor.numel() * tensor.itemsize) for group in buffers for tensor in group)
assert all(left[1] <= right[0] for left, right in zip(intervals, intervals[1:]))


def launch(name, index):
    x, weights, activation_scale, weight_scale = buffers[index]
    kernels[name]([pyhip.div_up(rows, 256) * pyhip.div_up(columns, 256)], [512], x, weights, output, activation_scale, weight_scale, rows)


def validate(name, candidate):
    with torch.device("cpu"):
        if name == "baseline":
            assert test.checkAllclose(reference, candidate, msg="cold baseline", tol_err_ratio=0) == 0
            return {"calc_diff": pyhip.calc_diff(reference, candidate, diff_thr=1e-5)}
        assert torch.count_nonzero(candidate).item() == 0
        return {"diagnostic_zero_output": True, "is_correct_gemm": False}


checks = {}
samples = []
timed_outputs = {}
if args.mode == "compare":
    orders = [("baseline", "no_dq"), ("no_dq", "baseline")]
else:
    orders = [selected]
for sweep, order in enumerate(orders):
    for name in order:
        for index in range(32):
            launch(name, index)
        torch.cuda.synchronize()
        checks[f"warmup_{sweep}_{name}"] = validate(name, output.cpu())
        gate(f"before_{sweep}_{name}")
        count = 32 if args.mode == "compare" else 1
        for index in range(count):
            if args.mode == "compare":
                begin = time.monotonic_ns()
                with pyhip.cudaPerf(flops, 0, name=name, verbose=0) as perf:
                    launch(name, index)
                samples.append({"sweep": sweep, "variant": name, "buffer": index,
                                "begin_ns": begin, "end_ns": time.monotonic_ns(), "us": perf.latencies[0] * 1e6})
            else:
                launch(name, index)
        torch.cuda.synchronize()
        timed_outputs[f"{sweep}_{name}"] = output.cpu()
        checks[f"timed_{sweep}_{name}"] = validate(name, timed_outputs[f"{sweep}_{name}"])
        print("RAW_SAMPLES", json.dumps(samples), flush=True)
        gate(f"after_{sweep}_{name}")

summary = {}
for name in selected:
    values = [sample["us"] for sample in samples if sample["variant"] == name]
    if values:
        summary[name] = {"samples": len(values), "median_us": statistics.median(values),
                         "min_us": min(values), "max_us": max(values),
                         "equivalent_mfma_tflops": flops / (statistics.median(values) * 1e6),
                         "is_correct_gemm": name == "baseline"}
report = {
    "mode": args.mode, "shape": [rows, columns, depth], "preshuffle_b": True,
    "pmc_diagnostic": args.pmc_diagnostic,
    "measurement_scope": "PMC diagnostic at recorded PTL; not ordinary benchmark timing" if args.pmc_diagnostic else "ordinary PTL-gated run",
    "cache_protocol": {"independent_buffers": 32, "A_B_bytes": 32 * (rows + columns) * depth,
                       "bytes_between_reuse": 31 * (rows + columns) * depth, "warmup_order": list(range(32)),
                       "profile_target": "dispatch 33, buffer 0 after warmup of buffers 0..31",
                       "explicit_flush": False, "note": "Each timing sweep warms all buffers then restarts at 0; no immediate A/B same-address reuse across variants."},
    "input_pointers": [[tensor.data_ptr() for tensor in group] for group in buffers],
    "output_pointer": output.data_ptr(), "gates": gates, "checks": checks,
    "samples": samples, "summary": summary,
    "code_objects": {name: {"path": str(paths[name]), "sha256": hashlib.sha256(paths[name].read_bytes()).hexdigest()} for name in selected},
}
args.output.write_text(json.dumps(report, indent=1) + "\n")
print("SUMMARY", json.dumps(summary), flush=True)
amdsmi.amdsmi_shut_down()