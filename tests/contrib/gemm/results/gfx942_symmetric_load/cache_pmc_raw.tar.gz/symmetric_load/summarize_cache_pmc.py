import argparse
import csv
import hashlib
import json
from pathlib import Path


parser = argparse.ArgumentParser()
parser.add_argument("--input-root", required=True, type=Path)
parser.add_argument("--output", required=True, type=Path)
args = parser.parse_args()
summary = {
    "date": "2026-10-31",
    "baseline": "v25, preshuffled B, K16384, 256x256 tile, 8 waves",
    "scope": "Whole target kernel, all hardware instances; not an active-mainloop-only counter window",
    "condition": "PMC automatically disables PTL; no PTL, clock or power setting was changed by the harness",
    "protocol": "32 disjoint A/B/scale clones; warm buffers 0..31, capture target kernel iteration 33 on buffer 0",
    "samples_per_shape_per_group": 1,
    "formula_source": "ROCm 7.2.4 rocprofiler-compute gfx942/0300_memory_chart.yaml",
    "formulas": {
        "vl1d_hit_pct": "100 * (1 - (TCP_TCC_READ_REQ_sum + TCP_TCC_WRITE_REQ_sum) / TCP_TOTAL_CACHE_ACCESSES_sum); target ISA has no atomics",
        "l2_hit_pct": "100 * TCC_HIT_sum / (TCC_HIT_sum + TCC_MISS_sum)",
        "fabric_read_cycles": "TCC_EA0_RDREQ_LEVEL_sum / TCC_EA0_RDREQ_sum",
        "tcp_pending_stall_pct": "100 * TCP_PENDING_STALL_CYCLES_sum / TCP_GATE_EN1_sum",
    },
    "caveats": [
        "Cannot directly transfer Disabled-PTL PMC results to Enabled-PTL ATT or ordinary timing",
        "Groups are separate processes/allocations, not same-address paired samples",
        "No estimate of run-to-run variance from one target dispatch per group",
        "Summed TCP stall cycles are not additive wall-time or MFMA-idle cycles",
        "Fabric read cycles include the external request path; not a direct HBM-only latency measurement",
        "No byte conversion of mixed 32/64-byte external read requests",
    ],
    "shapes": {},
}
for shape in (4096, 8192):
    groups = {}
    counters = {}
    workgroups = (shape // 256) ** 2
    for group in ("l1", "l2", "memory"):
        prefix = f"pmc{shape}_{group}_single"
        paths = list((args.input_root / prefix).rglob("*counter_collection.csv"))
        assert len(paths) == 1
        with paths[0].open() as stream:
            rows = list(csv.DictReader(stream))
        report = json.loads((args.input_root / f"{prefix}_run.json").read_text())
        assert report["shape"] == [shape, shape, 16384]
        assert report["pmc_diagnostic"] and report["preshuffle_b"]
        assert report["cache_protocol"]["independent_buffers"] == 32
        assert all(value["calc_diff"] <= 1e-5 for value in report["checks"].values())
        assert len({row["Dispatch_Id"] for row in rows}) == 1
        assert all("gemm_a8w8_blockscale_8wave_gfx942" in row["Kernel_Name"] for row in rows)
        assert all(int(row["Grid_Size"]) == workgroups * 512 for row in rows)
        assert all(int(row["Workgroup_Size"]) == 512 and int(row["Scratch_Size"]) == 0 for row in rows)
        assert all(gate["bdf"] == "0000:0a:00.0" and gate["ptl"] is False and len(gate["pids"]) <= 1 for gate in report["gates"])
        artifact = report["code_objects"]["baseline"]
        assert hashlib.sha256(Path(artifact["path"]).read_bytes()).hexdigest() == artifact["sha256"]
        values = {row["Counter_Name"]: float(row["Counter_Value"]) for row in rows}
        assert len(values) == len(rows)
        counters.update(values)
        groups[group] = {
            "csv": str(paths[0].relative_to(args.input_root)),
            "run_report": f"{prefix}_run.json",
            "dispatch_id": int(rows[0]["Dispatch_Id"]),
            "profiled_duration_us": (int(rows[0]["End_Timestamp"]) - int(rows[0]["Start_Timestamp"])) / 1000,
            "code_object": artifact,
            "checks": report["checks"],
            "ptl": [gate["ptl"] for gate in report["gates"]],
            "counters": values,
        }
    assert len({group["code_object"]["sha256"] for group in groups.values()}) == 1
    clocks = counters["TCP_GATE_EN1_sum"]
    metrics = {
        "vl1d_hit_pct": 100 * (1 - (counters["TCP_TCC_READ_REQ_sum"] + counters["TCP_TCC_WRITE_REQ_sum"]) / counters["TCP_TOTAL_CACHE_ACCESSES_sum"]),
        "l2_hit_pct": 100 * counters["TCC_HIT_sum"] / (counters["TCC_HIT_sum"] + counters["TCC_MISS_sum"]),
        "fabric_read_cycles": counters["TCC_EA0_RDREQ_LEVEL_sum"] / counters["TCC_EA0_RDREQ_sum"],
        "tcp_pending_stall_pct": 100 * counters["TCP_PENDING_STALL_CYCLES_sum"] / clocks,
        "tcp_read_tagconflict_pct": 100 * counters["TCP_READ_TAGCONFLICT_STALL_CYCLES_sum"] / clocks,
        "tcp_tcr_stall_pct": 100 * counters["TCP_TCR_TCP_STALL_CYCLES_sum"] / clocks,
    }
    assert 0 <= metrics["vl1d_hit_pct"] <= 100 and 0 <= metrics["l2_hit_pct"] <= 100
    summary["shapes"][str(shape)] = {
        "shape": [shape, shape, 16384],
        "workgroups": workgroups,
        "metrics": metrics,
        "per_wg": {name: value / workgroups for name, value in counters.items()},
        "groups": groups,
    }
    print(shape, json.dumps(metrics))
args.output.write_text(json.dumps(summary, indent=2) + "\n")