import ast
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


repository = Path("/mywork/pyhip")
root = Path("/tmp/gfx942_perf/flydsl_2x4")
output = repository / "tests/contrib/gemm/results/gfx942_flydsl_2x4"
output.mkdir(parents=True, exist_ok=True)
source = repository / "src/contrib/flydsl/gemm_a8w8_blockscale_gfx942.py"
baseline = repository / "src/contrib/gemm_fp8_gfx942.py"
frozen = repository / "tests/contrib/gemm/results/gfx942_blockscale_v32/v32.py"
assert ast.dump(ast.parse(baseline.read_text())) == ast.dump(ast.parse(frozen.read_text()))
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
reference = Path("/sgl-workspace/aiter/aiter/ops/flydsl/kernels/gemm_a8w8_blockscale_8wave.py")
peak = 80 * 1850000000 * 4096 / 1e12


def checked_report(path):
    report = json.loads(path.read_text())
    assert report["results"]
    assert all(gate["ptl"] and set(gate["formats"]) == {"VECTOR", "F8"} and len(gate["pids"]) <= 1 for gate in report["gates"])
    assert all(gate["bdf"] == "0001:0b:00.0" for gate in report["gates"])
    for item in report["results"]:
        assert len(item["input_pointers"]) == 32
        for values in item["summary"].values():
            assert values["samples"] == 64 and values["diff"] <= 1e-5
    return report


baselines = {}
for columns in (4096, 8192):
    report = checked_report(root.parent / f"verify_8x1_current_{columns}.json")
    baselines[str(columns)] = report["results"][0]["summary"]
comparisons = {}
for version in ("r3", "r4", "r5"):
    report = checked_report(root / f"{version}_cold.json")
    comparisons[version] = [
        {"shape": item["shape"], "preshuffle_b": item["preshuffle_b"], "summary": item["summary"], "artifacts": item["artifacts"]}
        for item in report["results"]
    ]
for item in comparisons["r3"]:
    assert item["artifacts"]["fly2x4"]["sha256"] == source_hash

pipeline = json.loads((root / "r3_pipeline_audit.json").read_text())
assert pipeline["source_sha256"] == source_hash and not pipeline["violations"]
assert len(pipeline["negative_controls"]) == 3
isa_checks = {}
for columns in (4096, 8192):
    report = json.loads((root / f"r3_{columns}_isa_wait_audit.json").read_text())
    assert not report["violations"] and len(report["negative_controls"]) == 2
    isa_checks[str(columns)] = report
testsuites = ET.parse(root / "r3_final_correctness.xml").getroot().findall(".//testsuite")
assert sum(int(suite.get("tests", "0")) for suite in testsuites) == 24
assert all(int(suite.get("errors", "0")) == 0 and int(suite.get("failures", "0")) == 0 for suite in testsuites)
failed = json.loads((root / "r6_cold.json").read_text())
assert failed["gates"][0]["pids"] and not failed.get("results")
summary = {
    "date": "2026-10-31",
    "selected_version": "r3",
    "source": str(source.relative_to(repository)), "source_sha256": source_hash,
    "reference": str(reference), "reference_sha256": hashlib.sha256(reference.read_bytes()).hexdigest(),
    "contract": "MI308/gfx942, FP8 E4M3FNUZ, FP32 K128 block scales and FMA accumulation, BF16 output; ScaleA[KB,M], ScaleB[ceil(N/128),KB]",
    "layout": "256x256 tile, 512 threads, real (M,N) wave grid (2,4), A/B each occupy 32KiB LDS; no gfx950 16-byte direct-to-LDS instructions",
    "selected_change": "Right B LDS reads issue after the stage-0 publication barrier and overlap left-side MFMA; shared B slots are not overwritten until their consumers retire",
    "baseline_preservation": {"current_source_sha256": hashlib.sha256(baseline.read_bytes()).hexdigest(), "frozen_v32_sha256": hashlib.sha256(frozen.read_bytes()).hexdigest(), "ast_identical": True, "performance_rechecks": baselines},
    "hardware_peak": {"device": "MI308X", "bdf": "0001:0b:00.0", "compute_units": 80, "maximum_gfx_hz": 1850000000, "dense_fp8_flops_per_cu_cycle": 4096, "dense_fp8_peak_tflops": peak, "not_sparse_peak": True, "caveat": "Maximum-clock theoretical arithmetic roof; actual clocks, data movement, scaling and stores prevent treating this as guaranteed GEMM throughput"},
    "selected_performance": [
        {"shape": item["shape"], "candidate": item["summary"]["fly2x4"], "same_run_8x1": item["summary"]["current8x1"], "percent_of_max_clock_dense_peak": 100 * item["summary"]["fly2x4"]["median_tflops"] / peak}
        for item in comparisons["r3"]
    ],
    "experiments": {"r2": "Original both-B-first LDS read schedule: recorded 394.9T/482.1T", "r3": "Overlap right B read with left compute: selected", "r4": "SMEM B-scale, no stable benefit: 412.2T/505.2T", "r5": "Compute priority boost, regression: 410.2T/500.9T", "r6": "16-byte output coalescing passed directed correctness; cold timing blocked by external GPU4 process; not selected"},
    "comparisons": comparisons,
    "correctness": {"pytest_cases": 24, "repeated_nan_runs": 3, "prefix_suffix_guard": True, "graph_replay": True, "atol": 0.01, "rtol": 0.01, "allowed_mismatch_ratio": 0, "calc_diff_max": 1e-5},
    "lifetime": {"source_barrier_model": pipeline, "actual_isa_wait_checks": isa_checks, "resource": {"vgpr": 250, "lds_bytes": 65536, "scratch_bytes": 0}},
    "limitations": [
        "Hardware peak has not been reached; no claim of a 606.2T kernel",
        "r3 dynamic ATT/MFMA cycle-margin audit is pending because GPUs became occupied; source and static ISA audits are not a race-detector proof",
        "The available r2 ATT is retained only as a diagnostic of the previous version",
        "r6 cold benchmark was stopped at entry, not retried or reported as passed",
        "The 8x1 performance recheck covers the two target square shapes; other historical shapes were preserved but not all re-timed",
        "Experimental direct entry requires contiguous same-device buffers honoring the documented dtype and scale layout; no automatic production dispatch switch",
    ],
}
(output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print("RESULTS_VERIFIED", "selected", source_hash, "peak", peak)
for result in summary["selected_performance"]:
    print(result["shape"], result["candidate"]["median_tflops"], "TFLOPS", result["percent_of_max_clock_dense_peak"], "% of theoretical peak")