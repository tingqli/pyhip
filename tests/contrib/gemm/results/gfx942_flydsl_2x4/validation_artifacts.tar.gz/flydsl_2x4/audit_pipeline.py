import argparse
import ast
from collections import defaultdict
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace


@dataclass
class Token:
    kind: str
    block: int
    packet: int
    part: int = 0
    used: bool = False


class Bank:
    def __init__(self):
        self.values = {}

    def __getitem__(self, key):
        index = key[-1] if isinstance(key, tuple) else key
        bank = self

        class Slot:
            def load(self):
                assert index in bank.values, ("uninitialized staging", index)
                value = bank.values[index]
                value.used = True
                return Token(value.kind, value.block, value.packet, value.part)

            def store(self, value):
                old = bank.values.get(index)
                if old is not None:
                    assert old.used, ("staging overwritten before consumption", old)
                bank.values[index] = value

        return Slot()


class HostSelect(ast.NodeTransformer):
    def visit_Call(self, node):
        node = self.generic_visit(node)
        if isinstance(node.func, ast.Attribute) and node.func.attr == "select":
            return ast.copy_location(
                ast.Call(func=ast.Name(id="select", ctx=ast.Load()), args=[node.func.value, *node.args], keywords=[]), node,
            )
        return node


def extract_schedule(source):
    tree = ast.parse(source)
    kernel = next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name == "gemm_kernel")
    body = next(node for node in kernel.body if isinstance(node, ast.FunctionDef) and node.name == "run_block")
    stage_loop = next(node for node in body.body if isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == "stage")
    compute_loop = next(node for node in stage_loop.body if isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == "side")
    position = stage_loop.body.index(compute_loop)
    stage_loop.body[position] = ast.Expr(value=ast.Call(
        func=ast.Name(id="consume", ctx=ast.Load()),
        args=[ast.Name(id=name, ctx=ast.Load()) for name in ("stage", "a_ops", "b_ops")], keywords=[],
    ))
    start = next(index for index, node in enumerate(kernel.body) if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "next_block" for target in node.targets))
    prologue = []
    for node in kernel.body[start:kernel.body.index(body)]:
        names = {item.id for item in ast.walk(node) if isinstance(item, ast.Name)}
        if names & {"c_acc", "pending", "pending_scale"}:
            continue
        prologue.append(node)
    prologue_tree = HostSelect().visit(ast.Module(body=prologue, type_ignores=[]))
    body_tree = HostSelect().visit(ast.Module(body=[body], type_ignores=[]))
    return (
        compile(ast.fix_missing_locations(prologue_tree), "source_prologue", "exec"),
        compile(ast.fix_missing_locations(body_tree), "source_memory_stages", "exec"),
    )


def audit_blocks(prologue, body, blocks, early_overwrite=False, missing_publication=False):
    events = defaultdict(list)
    barrier_counts = []
    for wave in range(8):
        state = {"epoch": 0, "block": 0}
        banks = {name: Bank() for name in ("a_stage", "b_stage", "scale_a", "scale_b", "scale_b_next")}

        def load(kind, block, packet, part=0):
            assert 0 <= block < blocks, ("out-of-range K prefetch", kind, block)
            return Token(kind, block, packet, part)

        def write(kind, packet, token):
            assert token.kind == kind and token.packet == packet, (kind, packet, token)
            token.used = True
            if missing_publication and state["epoch"] == 0 and kind == "b" and packet == 0:
                return
            epoch = state["epoch"]
            if early_overwrite and wave < 4 and kind == "a" and packet == 0 and token.block == 1:
                epoch -= 1
            events[epoch].append(("write", wave, kind, packet, token.block, 0, 0))

        def read(kind, packet, repeat, half):
            events[state["epoch"]].append(("read", wave, kind, packet, state["block"], repeat, half))
            return Token(kind, state["block"], packet, repeat * 2 + half)

        def consume(stage, activation, weight):
            block = state["block"]
            for repeat in range(2):
                for half in range(2):
                    token = activation[repeat][half]
                    assert (token.kind, token.block, token.packet, token.part) == ("a", block, stage, repeat * 2 + half)
                scale = banks["scale_a"][None, stage * 2 + repeat].load()
                assert (scale.kind, scale.block, scale.packet, scale.part) == ("sa", block, stage, repeat)
                scale.used = True
            for side in range(2):
                for repeat in range(2):
                    for half in range(2):
                        token = weight[side][repeat][half]
                        assert (token.kind, token.block, token.packet) == ("b", block, side * 2 + repeat)
                scale = banks["scale_b"][None, side].load()
                assert (scale.kind, scale.block, scale.packet) == ("sb", block, side)
                scale.used = True

        def barrier():
            state["epoch"] += 1

        namespace = {
            "KB": blocks, "wave_m": wave // 4, "last_pair": [30, 31],
            "range_constexpr": range, "const_expr": bool,
            "select": lambda condition, yes, no: yes if condition else no,
            "load_a": lambda block, packet: load("a", block, packet),
            "load_b": lambda block, packet: load("b", block, packet),
            "load_scale_a": lambda block, packet, repeat: load("sa", block, packet, repeat),
            "load_scale_b": lambda block, side: load("sb", block, side),
            "write_a": lambda packet, token: write("a", packet, token),
            "write_b": lambda packet, token: write("b", packet, token),
            "read_a": lambda packet, repeat, half: read("a", packet, repeat, half),
            "read_b": lambda side, repeat, half: read("b", side * 2 + repeat, 0, half),
            "barrier": barrier, "consume": consume,
            "rocdl": SimpleNamespace(s_waitcnt=lambda **kwargs: None, sched_barrier=lambda mask: None),
            **banks,
        }
        exec(prologue, namespace)
        exec(body, namespace)
        for block in range(blocks):
            state["block"] = block
            namespace["run_block"](block)
        if wave // 4 == 0:
            barrier()
        barrier_counts.append(state["epoch"])
    assert len(set(barrier_counts)) == 1, ("unbalanced barriers", barrier_counts)

    current = {}
    checked_reads = 0
    for epoch in sorted(events):
        writes = {}
        reads = {}
        for action, wave, kind, packet, block, repeat, half in events[epoch]:
            for lane in range(64):
                if action == "write":
                    if kind == "a":
                        row, column = divmod(wave * 64 + lane, 8)
                    else:
                        row = wave // 2 * 16 + lane % 16
                        column = wave % 2 * 4 + lane // 16
                else:
                    row = (wave // 4 * 16 + lane % 16 + repeat * 32) if kind == "a" else (wave % 4 * 16 + lane % 16)
                    column = lane // 16 + half * 4
                address = packet * 8192 + row * 128 + ((row ^ column) & 7) * 16
                assert 0 <= address <= 32768 - 16 and address % 16 == 0
                key = kind, address
                if action == "write":
                    assert key not in writes, ("duplicate producer", epoch, key)
                    writes[key] = block
                else:
                    assert key not in reads or reads[key] == block
                    reads[key] = block
                    checked_reads += 1
        assert not writes.keys() & reads.keys(), ("read/write in same barrier epoch", epoch)
        for key, block in reads.items():
            assert current.get(key) == block, ("wrong/unpublished LDS generation", epoch, key, block, current.get(key))
        current.update(writes)
    return {"K_blocks": blocks, "barriers_per_wave": barrier_counts[0], "lds_vector_reads_checked": checked_reads}


def audit_partials(blocks, wrong_index=False):
    histories = [[] for _ in range(32)]
    pending = None
    retired = 0
    for block in range(blocks):
        pending_index = [30, 31]
        for stage in range(4):
            for side in range(2):
                for repeat in range(2):
                    targets = [((stage * 2 + side) * 2 + repeat) * 2 + column for column in range(2)]
                    retired_elements = set()
                    for step in range(4):
                        for column in range(2):
                            old_column, element = divmod(step * 2 + column, 4)
                            assert (old_column, element) not in retired_elements
                            retired_elements.add((old_column, element))
                            if pending is not None:
                                assert pending_index[old_column] == pending[1][old_column]
                    assert len(retired_elements) == 8
                    if pending is not None:
                        for target in pending[1]:
                            histories[target].append(pending[0])
                        retired += 8
                    pending = block, targets
                    pending_index = [target ^ 1 for target in targets] if wrong_index else targets
    for target in pending[1]:
        histories[target].append(pending[0])
    assert all(history == list(range(blocks)) for history in histories)
    return retired + 8


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    source = args.source.read_text()
    prologue, body = extract_schedule(source)
    records = [audit_blocks(prologue, body, blocks) for blocks in (1, 2, 3, 4, 5, 7, 8, 16, 17, 128)]
    partial_checks = sum(audit_partials(record["K_blocks"]) for record in records)
    negative_controls = {}
    for label, operation in (
        ("early_A_overwrite", lambda: audit_blocks(prologue, body, 3, early_overwrite=True)),
        ("missing_B_publication", lambda: audit_blocks(prologue, body, 3, missing_publication=True)),
        ("wrong_partial_destination", lambda: audit_partials(3, wrong_index=True)),
    ):
        try:
            operation()
        except AssertionError as error:
            negative_controls[label] = str(error)
        else:
            raise AssertionError(("negative control not caught", label))
    result = {
        "source": str(args.source), "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
        "records": records, "partial_FMA_elements_checked": partial_checks,
        "negative_controls": negative_controls, "violations": [],
        "scope": "Memory stages/prologue extracted from source AST; producer tokens, scales and register reuse checked; all eight waves and 16-byte LDS vectors compared per barrier epoch",
        "limitations": [
            "Assumes LLVM retires each LDS read before its first MFMA use and each DS write before the explicit lgkmcnt(0)/publication barrier",
            "The barrier-epoch model checks all orderings between epochs, not individual instruction timing within a wave",
            "Dynamic async register waits and MFMA result latency must additionally be checked against generated ISA/ATT",
            "Partial arithmetic ordering is a symbolic check of the current pair-FIFO formula, not a floating-point simulator",
        ],
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print("PIPELINE_AUDIT_PASS", sum(record["lds_vector_reads_checked"] for record in records), "LDS reads; negative controls", list(negative_controls))


if __name__ == "__main__":
    main()