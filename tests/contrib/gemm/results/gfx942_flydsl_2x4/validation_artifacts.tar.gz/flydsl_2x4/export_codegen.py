import argparse
import hashlib
import json
from pathlib import Path
import subprocess

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl._mlir import ir
from flydsl._mlir.dialects import gpu
import torch

from pyhip.contrib.flydsl.gemm_a8w8_blockscale_gfx942 import compile_gemm_a8w8_blockscale_gfx942_2x4


parser = argparse.ArgumentParser()
parser.add_argument("--columns", type=int, required=True)
parser.add_argument("--depth", type=int, default=16384)
parser.add_argument("--output", required=True, type=Path)
args = parser.parse_args()
assert not torch.cuda.is_initialized()
launch = compile_gemm_a8w8_blockscale_gfx942_2x4(args.columns, args.depth, True)
launch._compile_only(
    *[flyc.from_c_void_p(dtype, 0x10000000 + index * 0x10000000) for index, dtype in enumerate((fx.Int32, fx.Int32, fx.Int32, fx.Float32, fx.Float32))],
    args.columns,
)
assert not torch.cuda.is_initialized()
artifacts = list(launch._mem_cache.values())
assert len(artifacts) == 1
artifact = artifacts[0]
assert artifact._engine is None
images = []
with ir.Context():
    module = ir.Module.parse(artifact._ir_text)
    for operation in module.body.operations:
        if operation.operation.name == "gpu.binary":
            objects = ir.ArrayAttr(operation.attributes["objects"])
            assert len(objects) == 1
            images.append(gpu.ObjectAttr(objects[0]).object)
assert len(images) == 1 and images[0].startswith(b"\x7fELF")
args.output.parent.mkdir(parents=True, exist_ok=True)
with args.output.open("xb") as stream:
    stream.write(images[0])
disassembly = subprocess.run(
    ["/opt/rocm/llvm/bin/llvm-objdump", "--disassemble", "--no-show-raw-insn", "--mcpu=gfx942", str(args.output)],
    check=True, capture_output=True, text=True,
).stdout
args.output.with_suffix(".s").write_text(disassembly)
metadata = subprocess.run(
    ["/opt/rocm/llvm/bin/llvm-readelf", "--notes", str(args.output)],
    check=True, capture_output=True, text=True,
).stdout
args.output.with_suffix(".notes").write_text(metadata)
print(json.dumps({"N": args.columns, "K": args.depth, "elf": str(args.output), "sha256": hashlib.sha256(images[0]).hexdigest(), "torch_gpu_initialized": torch.cuda.is_initialized(), "execution_engine_created": artifact._engine is not None}))