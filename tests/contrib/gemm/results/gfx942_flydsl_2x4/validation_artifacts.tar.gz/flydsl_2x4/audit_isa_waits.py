import argparse
from collections import Counter
import hashlib
from itertools import product
import json
from pathlib import Path
import re


def registers(text):
    result = set()
    for match in re.finditer(r"\b([vsa])(?:\[(\d+):(\d+)\]|(\d+))(?![A-Za-z0-9_])", text):
        kind, first, last, single = match.groups()
        result.update((kind, index) for index in ([int(single)] if single is not None else range(int(first), int(last) + 1)))
    return result


def parse(path):
    instructions = {}
    for line in path.read_text().splitlines():
        if "//" not in line:
            continue
        assembly, comment = line.split("//", 1)
        match = re.match(r"\s*([0-9A-Fa-f]+):", comment)
        if not match:
            continue
        opcode, *remaining = assembly.strip().split(None, 1)
        operands = remaining[0] if remaining else ""
        address = int(match.group(1), 16)
        instructions[address] = opcode, operands
    assert instructions
    return instructions


def branch_target(address, operands):
    displacement = int(operands.split()[0], 0)
    if displacement >= 32768:
        displacement -= 65536
    return address + 4 + displacement * 4


def audit(instructions, blocks, loosen_vm=False, loosen_lgkm=False):
    addresses = sorted(instructions)
    following = dict(zip(addresses, addresses[1:]))
    forward_branches = [address for address in addresses if instructions[address][0].startswith("s_cbranch") and branch_target(address, instructions[address][1]) > address]
    backward = [address for address in addresses if instructions[address][0].startswith("s_cbranch") and branch_target(address, instructions[address][1]) < address]
    assert len(backward) == 1 and len(forward_branches) <= 4
    totals = Counter()
    for choices in product((False, True), repeat=len(forward_branches)):
        decisions = dict(zip(forward_branches, choices))
        pending_vm = []
        pending_lgkm = []
        smem_pending = set()
        loops = 0
        address = addresses[0]
        path_counts = Counter()
        while True:
            opcode, operands = instructions[address]
            text = f"{opcode} {operands}"
            first, _, rest = operands.partition(",")
            is_load = opcode.startswith(("buffer_load", "global_load", "s_load", "s_buffer_load", "ds_read", "ds_bpermute", "ds_swizzle"))
            has_destination = is_load or opcode.startswith("v_") or opcode.startswith(("s_mov", "s_add", "s_sub", "s_mul", "s_lsh", "s_ash", "s_and", "s_or", "s_xor", "s_abs", "s_min", "s_max", "s_cselect"))
            destination = registers(first) if has_destination else set()
            sources = registers(rest) if has_destination else registers(operands)
            if opcode.startswith("v_fmac"):
                sources.update(destination)
            if opcode == "s_waitcnt":
                vm = re.search(r"vmcnt\((\d+)\)", operands)
                lgkm = re.search(r"lgkmcnt\((\d+)\)", operands)
                if vm:
                    count = int(vm.group(1)) + int(loosen_vm)
                    pending_vm = pending_vm[-count:] if count else []
                if lgkm:
                    count = int(lgkm.group(1)) + int(loosen_lgkm)
                    pending_lgkm = pending_lgkm[-count:] if count else []
                    if count == 0:
                        smem_pending.clear()
                path_counts["waits_checked"] += 1
            else:
                pending = set().union(*pending_vm, *pending_lgkm, smem_pending)
                assert not sources & pending, (hex(address), "load-use without wait", text, sorted(sources & pending))
                assert not destination & pending, (hex(address), "overwrite of pending destination", text, sorted(destination & pending))
                if opcode.startswith(("buffer_load", "global_load")):
                    pending_vm.append(destination)
                elif opcode.startswith(("buffer_store", "global_store")):
                    pending_vm.append(set())
                elif opcode.startswith(("s_load", "s_buffer_load")):
                    pending_lgkm.append(destination)
                    smem_pending.update(destination)
                elif opcode.startswith(("ds_read", "ds_bpermute", "ds_swizzle")):
                    pending_lgkm.append(destination)
                elif opcode.startswith("ds_write"):
                    pending_lgkm.append(set())
                if opcode.startswith("v_mfma"):
                    path_counts["mfma_instructions_checked"] += 1
                if opcode == "s_barrier":
                    path_counts["barriers"] += 1
            path_counts["instructions_checked"] += 1
            if opcode == "s_endpgm":
                break
            if opcode.startswith("s_cbranch"):
                if address in backward:
                    loops += 1
                    take = loops < blocks
                else:
                    take = decisions[address]
                address = branch_target(address, operands) if take else following[address]
            elif opcode == "s_branch":
                address = branch_target(address, operands)
            else:
                address = following[address]
        assert loops == blocks and path_counts["mfma_instructions_checked"] == blocks * 128
        totals.update(path_counts)
        totals["control_paths_checked"] += 1
    return dict(totals)


parser = argparse.ArgumentParser()
parser.add_argument("isa", type=Path)
parser.add_argument("--blocks", type=int, default=128)
parser.add_argument("--output", required=True, type=Path)
args = parser.parse_args()
instructions = parse(args.isa)
counts = audit(instructions, args.blocks)
negative_controls = {}
for label, options in (("looser_vmcnt", {"loosen_vm": True}), ("looser_lgkmcnt", {"loosen_lgkm": True})):
    try:
        audit(instructions, args.blocks, **options)
    except AssertionError as error:
        negative_controls[label] = str(error)
    else:
        raise AssertionError(("negative control not caught", label))
report = {
    "isa": str(args.isa), "isa_sha256": hashlib.sha256(args.isa.read_bytes()).hexdigest(),
    "counts": counts, "negative_controls": negative_controls, "violations": [],
    "scope": "Actual disassembled control flow, all forward-branch combinations and exact K-loop count; VMEM/LGKM load-use and WAW based on oldest-first counter retirement, SMEM conservatively requires lgkmcnt(0)",
    "limitations": ["Not an instruction-cycle model of MFMA result latency", "Cross-wave LDS publication/retirement checked by separate source/barrier audit", "Forward branch combinations include impossible wave-group combinations, making register checks conservative"],
}
args.output.write_text(json.dumps(report, indent=2) + "\n")
print("ISA_WAIT_AUDIT_PASS", counts, list(negative_controls))