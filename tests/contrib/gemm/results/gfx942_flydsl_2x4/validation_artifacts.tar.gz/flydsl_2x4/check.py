import argparse
import importlib.util

import torch

parser = argparse.ArgumentParser()
parser.add_argument("--shapes", default="256,256,128;257,272,256;17,528,384")
parser.add_argument("--layouts", default="0,1")
args = parser.parse_args()

spec = importlib.util.spec_from_file_location("gemm_test", "/mywork/pyhip/tests/contrib/gemm/test_a8w8_f32_blockscale.py")
test = importlib.util.module_from_spec(spec)
spec.loader.exec_module(test)
from pyhip.contrib.flydsl.gemm_a8w8_blockscale_gfx942 import gemm_a8w8_blockscale_gfx942_2x4


def run(x, weight, out, x_scale_t, w_scale, preshuffle_b, kernel=None):
    gemm_a8w8_blockscale_gfx942_2x4(x, weight, out, x_scale_t, w_scale, preshuffle_b)


test.run_gfx942 = run
for shape in args.shapes.split(";"):
    rows, columns, depth = map(int, shape.split(","))
    for layout in map(int, args.layouts.split(",")):
        print("CHECK", rows, columns, depth, bool(layout), flush=True)
        test.test_gfx942_pipeline(rows, columns, depth, bool(layout), None)
print("PASS", torch.cuda.get_device_name())
