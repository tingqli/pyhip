"""Offline (no GPU) compile of a FlyDSL gfx942 GEMM kernel: export ELF + disassembly + resource summary."""

import argparse
import collections
import hashlib
import importlib
import json
from pathlib import Path
import re
import subprocess

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl._mlir import ir
from flydsl._mlir.dialects import gpu
import torch

MODULES = {
    "8x1": ("pyhip.contrib.flydsl.gemm_a8w8_blockscale_gfx942_8x1", "compile_gemm_a8w8_blockscale_gfx942_8x1"),
    "4x2_lds": ("pyhip.contrib.flydsl.gemm_a8w8_blockscale_gfx942_4x2_lds", "compile_gemm_a8w8_blockscale_gfx942_4x2_lds"),
    "2x4": ("pyhip.contrib.flydsl.gemm_a8w8_blockscale_gfx942", "compile_gemm_a8w8_blockscale_gfx942_2x4"),
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--kernel", choices=sorted(MODULES), required=True)
    parser.add_argument("--columns", type=int, required=True)
    parser.add_argument("--depth", type=int, default=16384)
    parser.add_argument("--preshuffle", type=int, default=1)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    module_name, function = MODULES[args.kernel]
    launch = getattr(importlib.import_module(module_name), function)(args.columns, args.depth, bool(args.preshuffle))
    launch._compile_only(
        *[flyc.from_c_void_p(dtype, 0x10000000 + index * 0x10000000) for index, dtype in enumerate((fx.Int32, fx.Int32, fx.Int32, fx.Float32, fx.Float32))],
        args.columns,
    )
    assert not torch.cuda.is_initialized()
    artifacts = list(launch._mem_cache.values())
    assert len(artifacts) == 1 and artifacts[0]._engine is None
    images = []
    with ir.Context():
        module = ir.Module.parse(artifacts[0]._ir_text)
        for operation in module.body.operations:
            if operation.operation.name == "gpu.binary":
                objects = ir.ArrayAttr(operation.attributes["objects"])
                images.append(gpu.ObjectAttr(objects[0]).object)
    assert len(images) == 1 and images[0].startswith(b"\x7fELF")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(images[0])
    disassembly = subprocess.run(
        ["/opt/rocm/llvm/bin/llvm-objdump", "-d", "--mcpu=gfx942", str(args.output)], check=True, capture_output=True, text=True
    ).stdout
    args.output.with_suffix(".s").write_text(disassembly)
    notes = subprocess.run(["/opt/rocm/llvm/bin/llvm-readelf", "--notes", str(args.output)], check=True, capture_output=True, text=True).stdout
    resources = {key: int(value) for key, value in re.findall(r"\.(vgpr_count|sgpr_count|agpr_count|group_segment_fixed_size|private_segment_fixed_size|vgpr_spill_count|sgpr_spill_count):\s+(\d+)", notes)}
    rows = re.findall(r"^\s+(\S+)\s+(.*?)\s*//\s+([0-9A-F]+):", disassembly, re.M)
    rows = [(int(address, 16), opcode, operands) for opcode, operands, address in rows]
    backward = [
        (address, address + 4 + 4 * (int(operands) - (1 << 16)))
        for address, opcode, operands in rows
        if opcode.startswith("s_cbranch") and operands.isdigit() and int(operands) >= 1 << 15
    ]
    loops = []
    for end, begin in backward:
        body = [opcode for address, opcode, _ in rows if begin <= address <= end]
        counts = collections.Counter(body)
        loops.append({"begin": hex(begin), "end": hex(end), "instructions": len(body), "mfma": sum(v for k, v in counts.items() if k.startswith("v_mfma")), "counts": dict(counts.most_common(18))})
    report = {
        "kernel": args.kernel,
        "N": args.columns,
        "K": args.depth,
        "preshuffle_b": bool(args.preshuffle),
        "elf": str(args.output),
        "sha256": hashlib.sha256(images[0]).hexdigest(),
        "resources": resources,
        "total_instructions": len(rows),
        "total_mfma": sum(1 for _, opcode, _ in rows if opcode.startswith("v_mfma")),
        "scratch": [opcode for _, opcode, _ in rows if opcode.startswith("scratch_")][:5],
        "loops": loops,
    }
    args.output.with_suffix(".json").write_text(json.dumps(report, indent=1) + "\n")
    print(json.dumps(report, indent=1))


if __name__ == "__main__":
    main()
