"""Bitwise comparison of FlyDSL ports against their PyHIP originals, plus reference/guard/graph checks."""

import argparse
import importlib.util
import json
import sys

import torch
import pyhip

SHAPES = [
    (256, 256, 128), (257, 272, 256), (17, 528, 384), (129, 272, 512), (255, 528, 640), (257, 272, 2048),
    (1, 4096, 128), (129, 4096, 256), (257, 4096, 384), (4097, 4096, 512), (255, 4096, 640), (257, 4096, 2048),
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--kernel", choices=["8x1", "4x2_lds"], required=True)
    parser.add_argument("--shapes", default="all")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location("gemm_test", "/mywork/pyhip/tests/contrib/gemm/test_a8w8_f32_blockscale.py")
    tests = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tests)
    if args.kernel == "8x1":
        from pyhip.contrib.gemm_fp8_gfx942 import gemm_a8w8_blockscale_8wave_gfx942 as original
        from pyhip.contrib.flydsl.gemm_a8w8_blockscale_gfx942_8x1 import gemm_a8w8_blockscale_gfx942_8x1 as port
    else:
        from pyhip.contrib.gemm_fp8_gfx942_4x2_lds import gemm_a8w8_blockscale_8wave_gfx942_4x2_lds as original
        from pyhip.contrib.flydsl.gemm_a8w8_blockscale_gfx942_4x2_lds import gemm_a8w8_blockscale_gfx942_4x2_lds as port
    shapes = SHAPES if args.shapes == "all" else [tuple(map(int, s.split(","))) for s in args.shapes.split(";")]
    records = []
    for rows, cols, depth in shapes:
        for preshuffle in (False, True):
            torch.manual_seed(rows * 131 + cols * 7 + depth + preshuffle)
            x = (torch.randn((rows, depth), device="cuda") / 10).to(tests.dtypes.fp8)
            weight = (torch.randn((cols, depth), device="cuda") / 10).to(tests.dtypes.fp8)
            scale_a = torch.rand((rows, depth // 128), device="cuda")
            scale_b = torch.rand((pyhip.div_up(cols, 128), depth // 128), device="cuda")
            reference = tests.run_torch(x, weight, scale_a, scale_b)
            weight = tests.shuffle_weight(weight, layout=(16, 16)) if preshuffle else weight
            scale_a = scale_a.T.contiguous()
            expected = torch.full((rows, cols), float("nan"), dtype=torch.bfloat16, device="cuda")
            tests.run_gfx942(x, weight, expected, scale_a, scale_b, preshuffle, kernel=original)
            storage = torch.full((rows * cols + 128,), 123, dtype=torch.bfloat16, device="cuda")
            output = storage[64:-64].view(rows, cols)
            record = {"shape": [rows, cols, depth], "preshuffle_b": preshuffle}
            for run in range(3):
                output.fill_(float("nan"))
                port(x, weight, output, scale_a, scale_b, preshuffle)
                torch.cuda.synchronize()
                assert tests.checkAllclose(reference, output, msg=f"{args.kernel} port", tol_err_ratio=0) == 0
                assert torch.all(storage[:64] == 123) and torch.all(storage[-64:] == 123)
                assert torch.equal(output.view(torch.int16), expected.view(torch.int16)), "not bitwise identical to PyHIP"
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                port(x, weight, output, scale_a, scale_b, preshuffle)
            output.fill_(float("nan"))
            graph.replay()
            torch.cuda.synchronize()
            assert torch.equal(output.view(torch.int16), expected.view(torch.int16)), "graph replay differs"
            record["bitwise_identical_to_pyhip"] = True
            record["calc_diff"] = pyhip.calc_diff(reference, output, diff_thr=1e-5)
            records.append(record)
            print("OK", record, flush=True)
    with open(args.output, "w") as stream:
        json.dump({"kernel": args.kernel, "records": records}, stream, indent=1)
    print("ALL_BITWISE_IDENTICAL", len(records))


if __name__ == "__main__":
    main()
