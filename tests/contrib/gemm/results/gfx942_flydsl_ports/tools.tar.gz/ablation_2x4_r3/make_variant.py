"""Generate and export source-level ceiling variants of the selected FlyDSL 2x4 kernel.

cache_k0: every K block still issues the same A/B/scale loads, but all addresses use
k_block & (M >> 31), a runtime zero, so every load hits the K block 0 working set.
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

SOURCE = Path("/mywork/pyhip/src/contrib/flydsl/gemm_a8w8_blockscale_gfx942.py")
R3_SHA256 = "8a627da81c67dfb6b369c955eb224c5759e7b5cbb1cf9394da8e04775cea794c"
REPLACEMENTS = {
    "cache_k0": [
        ("from .helpers import BufferTensor", "from pyhip.contrib.flydsl.helpers import BufferTensor"),
        (
            "        scale_b_block = col_base // 128\n",
            "        scale_b_block = col_base // 128\n"
            "        k_mask = M >> 31\n\n"
            "        def k0(k_block):\n"
            "            return 0 if isinstance(k_block, int) else k_block & k_mask\n",
        ),
        ("soffset_bytes=k_block * TILE_K)", "soffset_bytes=k0(k_block) * TILE_K)"),
        ("soffset_bytes=k_block * b_k_bytes)", "soffset_bytes=k0(k_block) * b_k_bytes)"),
        ("(k_block * M + (packet", "(k0(k_block) * M + (packet"),
        ("(row * KB + k_block) * 4", "(row * KB + k0(k_block)) * 4"),
    ],
    # Measurement-only: per-WG SCLK/realtime stamps and hardware placement in a 7th pointer.
    "probe": [
        ("from .helpers import BufferTensor", "from pyhip.contrib.flydsl.helpers import BufferTensor\nfrom flydsl._mlir.dialects import llvm as llvm_dialect"),
        (
            "        pScaleB: fx.Pointer,\n        M: fx.Int32,\n    ):\n        tid = fx.thread_idx.x\n",
            "        pScaleB: fx.Pointer,\n        pProbe: fx.Pointer,\n        M: fx.Int32,\n    ):\n"
            "        def intrinsic(result, name, *operands):\n"
            "            return llvm_dialect.call_intrinsic(result, name, list(operands), [], [])\n\n"
            "        t_start = intrinsic(T.i64, \"llvm.amdgcn.s.memtime\")\n"
            "        rt_start = intrinsic(T.i64, \"llvm.amdgcn.s.memrealtime\")\n"
            "        tid = fx.thread_idx.x\n",
        ),
        (
            "        for k_block in range(0, KB):\n",
            "        t_loop_begin = intrinsic(T.i64, \"llvm.amdgcn.s.memtime\")\n"
            "        for k_block in range(0, KB):\n",
        ),
        (
            "        final_scale = Vec.filled(",
            "        t_loop_end = intrinsic(T.i64, \"llvm.amdgcn.s.memtime\")\n"
            "        final_scale = Vec.filled(",
        ),
        (
            "                aux=ir.IntegerAttr.get(T.i32, 0),\n            )\n\n    @flyc.jit\n",
            "                aux=ir.IntegerAttr.get(T.i32, 0),\n            )\n"
            "        t_end = intrinsic(T.i64, \"llvm.amdgcn.s.memtime\")\n"
            "        rt_end = intrinsic(T.i64, \"llvm.amdgcn.s.memrealtime\")\n"
            "        hw_id = intrinsic(T.i32, \"llvm.amdgcn.s.getreg\", fx.Int32(4 | 31 << 11).ir_value())\n"
            "        xcc_id = intrinsic(T.i32, \"llvm.amdgcn.s.getreg\", fx.Int32(20 | 31 << 11).ir_value())\n"
            "        grid = num_m * n_tiles\n"
            "        probe_tensor = fx.rocdl.make_buffer_tensor(\n"
            "            fx.make_view(pProbe, fx.make_layout(grid * 16, 1)), max_size=False, num_records_bytes=grid * 64\n"
            "        )\n"
            "        probe_rsrc = fx.rocdl.get_buffer_rsrc(fx.get_iter(probe_tensor))\n"
            "        probe_offset = (tid == 0).select(pid * 64, fx.Int32(0x7FFFFFF0))\n"
            "        stamps = [\n"
            "            Vec.from_elements([fx.Int64(t_start), fx.Int64(t_loop_begin)], fx.Int64).bitcast(fx.Int32),\n"
            "            Vec.from_elements([fx.Int64(t_loop_end), fx.Int64(t_end)], fx.Int64).bitcast(fx.Int32),\n"
            "            Vec.from_elements([fx.Int64(rt_start), fx.Int64(rt_end)], fx.Int64).bitcast(fx.Int32),\n"
            "            Vec.from_elements([fx.Int32(hw_id), fx.Int32(xcc_id), fx.Int32(0), fx.Int32(0)], fx.Int32),\n"
            "        ]\n"
            "        for index in range_constexpr(4):\n"
            "            rocdl.raw_ptr_buffer_store(\n"
            "                stamps[index].ir_value(),\n"
            "                probe_rsrc,\n"
            "                (probe_offset + index * 16).ir_value(),\n"
            "                fx.Int32(0).ir_value(),\n"
            "                aux=ir.IntegerAttr.get(T.i32, 0),\n"
            "            )\n\n    @flyc.jit\n",
        ),
        (
            "        pScaleB: fx.Pointer,\n        M: fx.Int32,\n        stream: fx.Stream = fx.Stream(None),\n    ):\n        gemm_kernel(\n            pA, pB, pC, pScaleA, pScaleB, M,\n",
            "        pScaleB: fx.Pointer,\n        pProbe: fx.Pointer,\n        M: fx.Int32,\n        stream: fx.Stream = fx.Stream(None),\n    ):\n        gemm_kernel(\n            pA, pB, pC, pScaleA, pScaleB, pProbe, M,\n",
        ),
    ],
}


def generate(name, output):
    text = SOURCE.read_text()
    assert hashlib.sha256(text.encode()).hexdigest() == R3_SHA256
    for old, new in REPLACEMENTS[name]:
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    output.write_text(text)
    return output


def export(path, columns, depth, elf, pointer_types):
    import flydsl.compiler as flyc
    import flydsl.expr as fx
    from flydsl._mlir import ir
    from flydsl._mlir.dialects import gpu
    import torch

    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[path.stem] = module
    spec.loader.exec_module(module)
    launch = module.compile_gemm_a8w8_blockscale_gfx942_2x4(columns, depth, True)
    launch._compile_only(
        *[
            flyc.from_c_void_p(dtype, 0x10000000 + index * 0x10000000)
            for index, dtype in enumerate(pointer_types(fx))
        ],
        columns,
    )
    assert not torch.cuda.is_initialized()
    artifacts = list(launch._mem_cache.values())
    assert len(artifacts) == 1 and artifacts[0]._engine is None
    images = []
    with ir.Context():
        parsed = ir.Module.parse(artifacts[0]._ir_text)
        for operation in parsed.body.operations:
            if operation.operation.name == "gpu.binary":
                objects = ir.ArrayAttr(operation.attributes["objects"])
                assert len(objects) == 1
                images.append(gpu.ObjectAttr(objects[0]).object)
    assert len(images) == 1 and images[0].startswith(b"\x7fELF")
    elf.write_bytes(images[0])
    disassembly = subprocess.run(
        ["/opt/rocm/llvm/bin/llvm-objdump", "-d", "--mcpu=gfx942", str(elf)],
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    elf.with_suffix(".s").write_text(disassembly)
    return hashlib.sha256(images[0]).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", choices=sorted(REPLACEMENTS), required=True)
    parser.add_argument("--columns", type=int, nargs="+", required=True)
    parser.add_argument("--depth", type=int, default=16384)
    parser.add_argument("--directory", type=Path, required=True)
    args = parser.parse_args()
    args.directory.mkdir(parents=True, exist_ok=True)
    source = generate(args.variant, args.directory / f"{args.variant}_source.py")
    report = {"variant": args.variant, "source": str(source), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "elfs": {}}
    def pointer_types(fx):
        types = [fx.Int32, fx.Int32, fx.Int32, fx.Float32, fx.Float32]
        return types + [fx.Int32] if args.variant == "probe" else types

    for columns in args.columns:
        elf = args.directory / f"{args.variant}_{columns}.co"
        report["elfs"][columns] = {"path": str(elf), "sha256": export(source, columns, args.depth, elf, pointer_types)}
    print(json.dumps(report, indent=2))
    (args.directory / f"{args.variant}.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
