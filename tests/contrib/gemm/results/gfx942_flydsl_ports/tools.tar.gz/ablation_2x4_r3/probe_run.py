"""Per-WG SCLK/realtime/placement probe for the FlyDSL gfx942 2x4 kernel (measurement only)."""

import argparse
import collections
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import statistics
import time

import amdsmi
import torch
import pyhip
from pyhip.core.hiptools import amdhip_func


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--shapes", default="8192,8192,16384;4096,4096,16384")
    parser.add_argument("--gpu", type=int, default=4)
    parser.add_argument("--variants", nargs="+", required=True, help="name:kind:path_with_{N}; kind gemm|zero|diag; r3 identity uses kind gemm6")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    amdsmi.amdsmi_init()
    handle = amdsmi.amdsmi_get_processor_handles()[args.gpu]
    assert os.environ.get("HIP_VISIBLE_DEVICES") == str(args.gpu)
    rocmsmi = ctypes.CDLL("/opt/rocm/lib/librocm_smi64.so")
    assert rocmsmi.rsmi_init(ctypes.c_uint64(0)) == 0
    gates, results = [], []

    def write(status):
        args.output.write_text(json.dumps({"status": status, "gates": gates, "results": results}, indent=1) + "\n")

    def gate(stage):
        memory = amdsmi.amdsmi_get_gpu_vram_usage(handle)
        process_devices = {}
        for process in amdsmi.amdsmi_get_gpu_process_list(handle):
            pid = int(process["pid"])
            count = ctypes.c_uint32(0)
            assert rocmsmi.rsmi_compute_process_gpus_get(ctypes.c_uint32(pid), None, ctypes.byref(count)) == 0
            devices = (ctypes.c_uint32 * count.value)()
            if count.value:
                assert rocmsmi.rsmi_compute_process_gpus_get(ctypes.c_uint32(pid), devices, ctypes.byref(count)) == 0
            process_devices[pid] = list(devices)
        record = {
            "stage": stage,
            "bdf": amdsmi.amdsmi_get_gpu_device_bdf(handle),
            "activity": amdsmi.amdsmi_get_gpu_activity(handle),
            "memory": memory,
            "pids": [pid for pid, devices in process_devices.items() if args.gpu in devices],
            "ptl": amdsmi.amdsmi_get_gpu_ptl_state(handle),
            "formats": [amdsmi.AmdSmiPtlData(value).name for value in amdsmi.amdsmi_get_gpu_ptl_formats(handle)],
        }
        gates.append(record)
        print("GATE", json.dumps(record), flush=True)
        write("running")
        assert record["ptl"] and set(record["formats"]) == {"VECTOR", "F8"}
        assert memory["vram_used"] <= memory["vram_total"] * 0.2
        if stage == "entry":
            assert not record["pids"] and record["activity"]["gfx_activity"] <= 5
        else:
            assert len(record["pids"]) <= 1

    gate("entry")
    hip = ctypes.CDLL("/opt/rocm/lib/libamdhip64.so")
    runtime_bdf = ctypes.create_string_buffer(32)
    assert hip.hipDeviceGetPCIBusId(runtime_bdf, len(runtime_bdf), 0) == 0
    assert runtime_bdf.value.decode().lower() == gates[0]["bdf"].lower()
    spec = importlib.util.spec_from_file_location("gemm_test", "/mywork/pyhip/tests/contrib/gemm/test_a8w8_f32_blockscale.py")
    tests = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tests)

    for shape in args.shapes.split(";"):
        rows, columns, depth = map(int, shape.split(","))
        blocks = depth // 128
        grid = pyhip.div_up(rows, 256) * pyhip.div_up(columns, 256)
        torch.manual_seed(7)
        activation = (torch.rand((rows, depth), device="cuda") / 10).to(tests.dtypes.fp8)
        weight = (torch.rand((columns, depth), device="cuda") / 10).to(tests.dtypes.fp8)
        scale_a = torch.rand((rows, blocks), device="cuda")
        scale_b = torch.rand((pyhip.div_up(columns, 128), blocks), device="cuda")
        reference = tests.run_torch(activation, weight, scale_a, scale_b).cpu()
        weight = tests.shuffle_weight(weight, layout=(16, 16))
        scale_a = scale_a.T.contiguous()
        buffers = [tuple(tensor.clone() for tensor in (activation, weight, scale_a, scale_b)) for _ in range(32)]
        output = torch.empty((rows, columns), dtype=torch.bfloat16, device="cuda")
        variants = [entry.split(":", 2) for entry in args.variants]
        names = [name for name, _, _ in variants]
        kinds = {name: kind for name, kind, _ in variants}
        assert set(kinds.values()) <= {"gemm", "gemm6", "zero", "diag"}
        probes = {name: torch.zeros((2, 32, grid, 16), dtype=torch.int32, device="cuda") for name in names if kinds[name] != "gemm6"}
        scratch_probe = torch.zeros((grid, 16), dtype=torch.int32, device="cuda")
        paths = {name: Path(template.format(N=columns)) for name, _, template in variants}
        kernels = {
            name: amdhip_func(str(paths[name]), "gemm_kernel_0", "gemm_kernel_0", ["void*"] * (5 if kinds[name] == "gemm6" else 6) + ["int"])
            for name in names
        }
        flops = 2 * rows * columns * depth

        def launch(name, index, probe=None):
            x, weights, activation_scale, weight_scale = buffers[index]
            extra = [] if kinds[name] == "gemm6" else [scratch_probe if probe is None else probe]
            kernels[name]([grid], [512], x, weights, output, activation_scale, weight_scale, *extra, rows)

        def validate(name):
            kind = kinds[name]
            if kind in ("zero", "diag"):
                output.view(torch.int16).fill_(0x7FA5)
                launch(name, 0)
                torch.cuda.synchronize()
            actual = output.cpu()
            with torch.device("cpu"):
                if kind in ("gemm", "gemm6"):
                    assert tests.checkAllclose(reference, actual, msg=name, tol_err_ratio=0) == 0
                    return pyhip.calc_diff(reference, actual, diff_thr=1e-5)
                assert torch.count_nonzero(actual.view(torch.int16) == 0x7FA5).item() == 0
                if kind == "zero":
                    assert torch.count_nonzero(actual).item() == 0
                return f"{kind}: all outputs overwritten; not a GEMM"

        samples, checks = [], {}
        for sweep, order in enumerate((names, list(reversed(names)))):
            for name in order:
                for index in range(32):
                    launch(name, index)
                torch.cuda.synchronize()
                checks[f"warmup_{sweep}_{name}"] = validate(name)
                gate(f"{shape}:{sweep}:{name}:before")
                for index in range(32):
                    with pyhip.cudaPerf(flops, name=name, verbose=0) as perf:
                        launch(name, index, probes[name][sweep, index] if name in probes else None)
                    samples.append({"sweep": sweep, "variant": name, "buffer": index, "us": perf.latencies[0] * 1e6})
                checks[f"timed_{sweep}_{name}"] = validate(name)
                gate(f"{shape}:{sweep}:{name}:after")
        all_stats, aggregates = {}, {}
        for name in probes:
            all_stats[name] = stats = probe_stats(probes[name].cpu(), grid, blocks, samples, name)
            aggregates[name] = {
                key: statistics.median(stat[key] for stat in stats)
                for key in stats[0]
                if isinstance(stats[0][key], (int, float)) and key not in ("sweep", "buffer")
            }
        summary = {}
        for name in names:
            times = [s["us"] for s in samples if s["variant"] == name]
            summary[name] = {
                "kind": kinds[name],
                "median_us": statistics.median(times),
                "tflops": flops / (statistics.median(times) * 1e6),
                "samples": len(times),
                "sweep_medians_us": [statistics.median(s["us"] for s in samples if s["variant"] == name and s["sweep"] == sweep) for sweep in (0, 1)],
            }
        results.append(
            {
                "shape": [rows, columns, depth],
                "grid": grid,
                "summary": summary,
                "probe_aggregate_medians": aggregates,
                "probe_samples": all_stats,
                "samples": samples,
                "checks": checks,
                "artifacts": {name: {"kind": kinds[name], "path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in paths.items()},
                "input_pointers": [[tensor.data_ptr() for tensor in group] for group in buffers],
                "output_pointer": output.data_ptr(),
            }
        )
        write("running")
        print("PROBE", shape, json.dumps(summary), json.dumps(aggregates), flush=True)
        del buffers, output, activation, weight, scale_a, scale_b, reference, probes
    write("complete")
    amdsmi.amdsmi_shut_down()
    assert rocmsmi.rsmi_shut_down() == 0


def probe_stats(records, grid, blocks, samples, name):
    stats = []
    for sweep in range(2):
        for index in range(32):
            data = records[sweep, index].to(torch.int64)
            low = lambda column: data[:, column] & 0xFFFFFFFF
            value = lambda column: low(column) | (data[:, column + 1] << 32)
            t_start, t_loop, t_loop_end, t_end = value(0), value(2), value(4), value(6)
            rt_start, rt_end = value(8), value(10)
            hw_id, xcc = data[:, 12] & 0xFFFFFFFF, data[:, 13] & 0xF
            assert bool((t_end > t_start).all()) and bool((rt_end > rt_start).all())
            cu = (xcc << 16) | (((hw_id >> 13) & 0x7) << 8) | (((hw_id >> 12) & 1) << 4) | ((hw_id >> 8) & 0xF)
            per_cu = collections.defaultdict(list)
            for wg in range(grid):
                per_cu[int(cu[wg])].append(wg)
            gaps = []
            for wgs in per_cu.values():
                wgs.sort(key=lambda wg: int(rt_start[wg]))
                for left, right in zip(wgs, wgs[1:]):
                    gaps.append(int(rt_start[right] - rt_end[left]) * 10)
            span_ns = int(rt_end.max() - rt_start.min()) * 10
            sclk = ((t_end - t_start).double() / ((rt_end - rt_start).double() * 10)).tolist()
            loop = (t_loop_end - t_loop).double() / blocks
            sample = next(s for s in samples if s["variant"] == name and s["sweep"] == sweep and s["buffer"] == index)
            stats.append(
                {
                    "sweep": sweep,
                    "buffer": index,
                    "event_us": sample["us"],
                    "wg_span_us": span_ns / 1000,
                    "cus": len(per_cu),
                    "wgs_per_cu": dict(collections.Counter(len(v) for v in per_cu.values())),
                    "sclk_ghz_median": statistics.median(sclk),
                    "sclk_ghz_min": min(sclk),
                    "sclk_ghz_max": max(sclk),
                    "prologue_cycles_median": statistics.median((t_loop - t_start).tolist()),
                    "loop_cycles_per_kblock_median": statistics.median(loop.tolist()),
                    "loop_cycles_per_kblock_p05": float(torch.quantile(loop, 0.05)),
                    "loop_cycles_per_kblock_p95": float(torch.quantile(loop, 0.95)),
                    "epilogue_cycles_median": statistics.median((t_end - t_loop_end).tolist()),
                    "wg_total_cycles_median": statistics.median((t_end - t_start).tolist()),
                    "same_cu_gap_ns_median": statistics.median(gaps) if gaps else None,
                    "same_cu_gap_ns_p95": float(torch.quantile(torch.tensor(gaps, dtype=torch.float64), 0.95)) if gaps else None,
                    "first_start_to_last_start_us": int(rt_start.max() - rt_start.min()) / 100,
                }
            )
    return stats


if __name__ == "__main__":
    main()
