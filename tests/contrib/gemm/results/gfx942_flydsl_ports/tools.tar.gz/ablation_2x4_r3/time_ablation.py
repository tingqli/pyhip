"""Cold same-address timing of FlyDSL 2x4 ELF ablations launched through one HIP path.

Every variant is a FlyDSL-exported code object launched with hipModuleLaunchKernel.
Diagnostic variants are not GEMMs; their outputs are checked only for the exact
diagnostic contract (k0-repeated reference or complete zero writes).
"""

import argparse
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

import amdsmi
import torch
import pyhip
from pyhip.core.hiptools import amdhip_func

PEAK_TFLOPS = 80 * 1.85e9 * 4096 / 1e12
# BF16 NaN with a non-canonical payload; kernels never produce this exact bit pattern from conversion.
SENTINEL = 0x7FA5


class Sampler:
    """Out-of-process SMI sampler so metric polling never holds the launcher's GIL."""

    def __init__(self, gpu):
        self.gpu = gpu
        self.records = []

    def __enter__(self):
        self.process = subprocess.Popen(
            [sys.executable, str(Path(__file__).with_name("smi_sampler.py")), str(self.gpu)],
            stdout=subprocess.PIPE,
            text=True,
            env={key: value for key, value in os.environ.items() if key != "HIP_VISIBLE_DEVICES"},
        )
        assert "ready" in json.loads(self.process.stdout.readline())
        return self

    def __exit__(self, *exc):
        self.process.terminate()
        output, _ = self.process.communicate(timeout=30)
        assert self.process.returncode == 0, self.process.returncode
        self.records = [json.loads(line) for line in output.splitlines() if line.strip()]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--shapes", default="8192,8192,16384;4096,4096,16384")
    parser.add_argument("--variants", nargs="+", required=True, help="name:kind:path_with_{N}")
    parser.add_argument("--gpu", type=int, default=4)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    amdsmi.amdsmi_init()
    handle = amdsmi.amdsmi_get_processor_handles()[args.gpu]
    assert os.environ.get("HIP_VISIBLE_DEVICES") == str(args.gpu)
    rocmsmi = ctypes.CDLL("/opt/rocm/lib/librocm_smi64.so")
    assert rocmsmi.rsmi_init(ctypes.c_uint64(0)) == 0
    gates = []
    results = []

    def write(status):
        args.output.write_text(json.dumps({"status": status, "gates": gates, "results": results}, indent=1) + "\n")

    def gate(stage):
        memory = amdsmi.amdsmi_get_gpu_vram_usage(handle)
        process_devices = {}
        for process in amdsmi.amdsmi_get_gpu_process_list(handle):
            pid = int(process["pid"])
            count = ctypes.c_uint32(0)
            assert rocmsmi.rsmi_compute_process_gpus_get(ctypes.c_uint32(pid), None, ctypes.byref(count)) == 0
            devices = (ctypes.c_uint32 * count.value)()
            if count.value:
                assert rocmsmi.rsmi_compute_process_gpus_get(ctypes.c_uint32(pid), devices, ctypes.byref(count)) == 0
            process_devices[pid] = list(devices)
        record = {
            "stage": stage,
            "bdf": amdsmi.amdsmi_get_gpu_device_bdf(handle),
            "activity": amdsmi.amdsmi_get_gpu_activity(handle),
            "memory": memory,
            "pids": [pid for pid, devices in process_devices.items() if args.gpu in devices],
            "process_devices": process_devices,
            "ptl": amdsmi.amdsmi_get_gpu_ptl_state(handle),
            "formats": [amdsmi.AmdSmiPtlData(value).name for value in amdsmi.amdsmi_get_gpu_ptl_formats(handle)],
        }
        gates.append(record)
        print("GATE", json.dumps(record), flush=True)
        write("running")
        assert record["ptl"] and set(record["formats"]) == {"VECTOR", "F8"}
        assert memory["vram_used"] <= memory["vram_total"] * 0.2
        if stage == "entry":
            assert not record["pids"] and record["activity"]["gfx_activity"] <= 5
        else:
            assert len(record["pids"]) <= 1

    gate("entry")
    hip = ctypes.CDLL("/opt/rocm/lib/libamdhip64.so")
    runtime_bdf = ctypes.create_string_buffer(32)
    assert hip.hipDeviceGetPCIBusId(runtime_bdf, len(runtime_bdf), 0) == 0
    assert runtime_bdf.value.decode().lower() == gates[0]["bdf"].lower()
    spec = importlib.util.spec_from_file_location("gemm_test", "/mywork/pyhip/tests/contrib/gemm/test_a8w8_f32_blockscale.py")
    tests = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tests)
    variants = [entry.split(":", 2) for entry in args.variants]
    assert all(kind in ("gemm", "k0", "zero", "k0zero", "diag") for _, kind, _ in variants)

    for shape in args.shapes.split(";"):
        rows, columns, depth = map(int, shape.split(","))
        blocks = depth // 128
        torch.manual_seed(7)
        activation = (torch.rand((rows, depth), device="cuda") / 10).to(tests.dtypes.fp8)
        weight = (torch.rand((columns, depth), device="cuda") / 10).to(tests.dtypes.fp8)
        scale_a = torch.rand((rows, blocks), device="cuda")
        scale_b = torch.rand((pyhip.div_up(columns, 128), blocks), device="cuda")
        references = {"gemm": tests.run_torch(activation, weight, scale_a, scale_b).cpu()}
        references["k0"] = tests.run_torch(
            activation[:, :128].repeat(1, blocks),
            weight[:, :128].repeat(1, blocks),
            scale_a[:, :1].repeat(1, blocks),
            scale_b[:, :1].repeat(1, blocks),
        ).cpu()
        weight = tests.shuffle_weight(weight, layout=(16, 16))
        scale_a = scale_a.T.contiguous()
        buffers = [tuple(tensor.clone() for tensor in (activation, weight, scale_a, scale_b)) for _ in range(32)]
        output = torch.empty((rows, columns), dtype=torch.bfloat16, device="cuda")
        intervals = sorted(
            (tensor.data_ptr(), tensor.data_ptr() + tensor.numel() * tensor.itemsize)
            for group in buffers
            for tensor in group
        )
        assert all(left[1] <= right[0] for left, right in zip(intervals, intervals[1:]))
        kernels, artifacts = {}, {}
        for name, kind, template in variants:
            path = Path(template.format(N=columns))
            kernels[name] = amdhip_func(str(path), "gemm_kernel_0", "gemm_kernel_0", ["void*"] * 5 + ["int"])
            artifacts[name] = {"kind": kind, "path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        flops = 2 * rows * columns * depth

        def launch(name, index):
            x, weights, activation_scale, weight_scale = buffers[index]
            kernels[name](
                [pyhip.div_up(rows, 256) * pyhip.div_up(columns, 256)],
                [512],
                x,
                weights,
                output,
                activation_scale,
                weight_scale,
                rows,
            )

        def validate(name, kind):
            if kind in ("zero", "k0zero", "diag"):
                output.view(torch.int16).fill_(SENTINEL)
                launch(name, 0)
                torch.cuda.synchronize()
            actual = output.cpu()
            with torch.device("cpu"):
                if kind in ("gemm", "k0"):
                    assert tests.checkAllclose(references[kind], actual, msg=f"{name}:{kind}", tol_err_ratio=0) == 0
                    return {"kind": kind, "calc_diff": pyhip.calc_diff(references[kind], actual, diff_thr=1e-5)}
                remaining = torch.count_nonzero(actual.view(torch.int16) == SENTINEL).item()
                assert remaining == 0, (name, remaining)
                if kind == "diag":
                    return {"kind": kind, "all_outputs_overwritten": True, "is_correct_gemm": False}
                assert torch.count_nonzero(actual).item() == 0
                return {"kind": kind, "all_outputs_written_zero": True, "is_correct_gemm": False}

        samples, checks, clocks = [], {}, []
        names = [name for name, _, _ in variants]
        kinds = {name: kind for name, kind, _ in variants}
        for sweep, order in enumerate((names, list(reversed(names)))):
            for name in order:
                for index in range(32):
                    launch(name, index)
                torch.cuda.synchronize()
                checks[f"warmup_{sweep}_{name}"] = validate(name, kinds[name])
                gate(f"{shape}:{sweep}:{name}:before")
                with Sampler(args.gpu) as sampler:
                    for index in range(32):
                        begin = time.monotonic_ns()
                        with pyhip.cudaPerf(flops, name=name, verbose=0) as perf:
                            launch(name, index)
                        samples.append(
                            {
                                "sweep": sweep,
                                "variant": name,
                                "buffer": index,
                                "us": perf.latencies[0] * 1e6,
                                "begin_ns": begin,
                                "end_ns": time.monotonic_ns(),
                            }
                        )
                clocks.append({"sweep": sweep, "variant": name, "records": sampler.records})
                checks[f"timed_{sweep}_{name}"] = validate(name, kinds[name])
                gate(f"{shape}:{sweep}:{name}:after")
        summary = {}
        for name in names:
            times = [sample["us"] for sample in samples if sample["variant"] == name]
            median = statistics.median(times)
            busy = [
                record
                for block in clocks
                if block["variant"] == name
                for record in block["records"]
                if any(
                    sample["variant"] == name and sample["begin_ns"] <= record["ns"] <= sample["end_ns"]
                    for sample in samples
                )
            ]
            gfx = [statistics.mean(record["gfxclk"]) for record in busy if record["gfxclk"]]
            power = [record["power_w"] for record in busy]
            summary[name] = {
                "kind": kinds[name],
                "samples": len(times),
                "median_us": median,
                "min_us": min(times),
                "max_us": max(times),
                "sweep_medians_us": [
                    statistics.median(sample["us"] for sample in samples if sample["variant"] == name and sample["sweep"] == sweep)
                    for sweep in (0, 1)
                ],
                "equivalent_tflops": flops / (median * 1e6),
                "fraction_of_606T": flops / (median * 1e6) / PEAK_TFLOPS,
                "is_correct_gemm": kinds[name] == "gemm",
                "smi_in_kernel_samples": len(busy),
                "gfxclk_mhz_median": statistics.median(gfx) if gfx else None,
                "gfxclk_mhz_min": min(gfx) if gfx else None,
                "socket_power_w_median": statistics.median(power) if power else None,
                "socket_power_w_max": max(power) if power else None,
            }
        results.append(
            {
                "shape": [rows, columns, depth],
                "preshuffle_b": True,
                "summary": summary,
                "checks": checks,
                "samples": samples,
                "clock_records": clocks,
                "artifacts": artifacts,
                "input_pointers": [[tensor.data_ptr() for tensor in group] for group in buffers],
                "output_pointer": output.data_ptr(),
            }
        )
        write("running")
        print("ABLATION", shape, json.dumps(summary), flush=True)
        del buffers, output, activation, weight, scale_a, scale_b, references
    write("complete")
    amdsmi.amdsmi_shut_down()
    assert rocmsmi.rsmi_shut_down() == 0


if __name__ == "__main__":
    main()
