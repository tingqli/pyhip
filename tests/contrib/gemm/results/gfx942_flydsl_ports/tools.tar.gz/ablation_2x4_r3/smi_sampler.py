import json
import signal
import sys
import time

import amdsmi

running = True


def stop(*_):
    global running
    running = False


signal.signal(signal.SIGTERM, stop)
amdsmi.amdsmi_init()
handle = amdsmi.amdsmi_get_processor_handles()[int(sys.argv[1])]
print(json.dumps({"ready": time.monotonic_ns()}), flush=True)
while running:
    metrics = amdsmi.amdsmi_get_gpu_metrics_info(handle)
    print(
        json.dumps(
            {
                "ns": time.monotonic_ns(),
                "gfxclk": [value for value in metrics["current_gfxclks"] if value != "N/A"],
                "power_w": metrics["current_socket_power"],
                "energy": metrics["energy_accumulator"],
            }
        ),
        flush=True,
    )
    time.sleep(0.0005)
amdsmi.amdsmi_shut_down()
