"""Same-layout ELF ablation patches for the FlyDSL gfx942 2x4 kernel.

Instructions are replaced in place by ``s_nop 0`` words of identical size, so
every other instruction keeps its address, alignment, and encoding.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

S_NOP_0 = 0xBF800000
LINE = re.compile(r"^\s+(\S+)\s+(.*?)\s*//\s+([0-9A-F]+):\s+((?:[0-9A-F]{8}\s*)+)")


def disassemble(path):
    text = subprocess.run(
        ["/opt/rocm/llvm/bin/llvm-objdump", "-d", "--mcpu=gfx942", str(path)],
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    rows = []
    for line in text.splitlines():
        match = LINE.match(line)
        if match:
            opcode, operands, address, raw = match.groups()
            rows.append((int(address, 16), opcode, operands.strip(), [int(word, 16) for word in raw.split()]))
    return rows


def text_section(path):
    output = subprocess.run(
        ["/opt/rocm/llvm/bin/llvm-readelf", "-S", "-W", str(path)],
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    for line in output.splitlines():
        fields = line.replace("[ ", "[").split()
        if len(fields) > 5 and fields[1] == ".text":
            return int(fields[3], 16), int(fields[4], 16)
    raise RuntimeError("missing .text")


def loop_bounds(rows):
    branches = [(address, operands) for address, opcode, operands, _ in rows if opcode == "s_cbranch_scc1"]
    backward = [
        (address, address + 4 + 4 * (int(operands) - (1 << 16)))
        for address, operands in branches
        if int(operands) >= 1 << 15
    ]
    assert len(backward) == 1, backward
    end, begin = backward[0]
    return begin, end + 4


def conditional_barrier(rows, address):
    """True for an s_barrier skipped by the immediately preceding s_cbranch_scc1 1."""
    index = next(i for i, row in enumerate(rows) if row[0] == address)
    previous = rows[index - 1]
    return previous[1] == "s_cbranch_scc1" and previous[2] == "1"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--remove", required=True, help="comma list of dq,lds_read,lds_write,vmem,barrier,mfma or none")
    args = parser.parse_args()
    remove = set() if args.remove == "none" else set(args.remove.split(","))
    assert remove <= {"dq", "lds_read", "lds_write", "vmem", "barrier", "mfma"}, remove
    data = bytearray(args.input.read_bytes())
    rows = disassemble(args.input)
    text_address, text_offset = text_section(args.input)
    begin, end = loop_bounds(rows)
    mfma = [row for row in rows if begin <= row[0] < end and row[1].startswith("v_mfma")]
    targets = []
    for address, opcode, operands, words in rows:
        in_loop = begin <= address < end
        selected = (
            ("dq" in remove and address >= begin and (opcode == "v_fmac_f32_e32" or (opcode == "v_mul_f32_e32" and in_loop)))
            or ("lds_read" in remove and in_loop and opcode.startswith("ds_read"))
            or ("lds_write" in remove and in_loop and opcode.startswith("ds_write"))
            or ("vmem" in remove and in_loop and opcode.startswith("buffer_load"))
            or ("mfma" in remove and in_loop and opcode.startswith("v_mfma"))
            # Loop barriers plus both 4+4 stagger barriers, which only balance each other.
            or ("barrier" in remove and opcode == "s_barrier" and (in_loop or conditional_barrier(rows, address)))
        )
        if selected:
            targets.append((address, opcode, operands, words))
    for address, opcode, operands, words in targets:
        offset = text_offset + address - text_address
        for index, word in enumerate(words):
            position = offset + 4 * index
            assert int.from_bytes(data[position : position + 4], "little") == word, hex(address)
            data[position : position + 4] = S_NOP_0.to_bytes(4, "little")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(data)
    patched = disassemble(args.output)
    original = {row[0]: row for row in rows}
    target_addresses = {target[0] for target in targets}
    for row in patched:
        if row[0] in original and row[0] not in target_addresses:
            assert original[row[0]][3] == row[3], hex(row[0])
    nops = {row[0]: row for row in patched}
    for address, _, _, words in targets:
        for index in range(len(words)):
            assert nops[address + 4 * index][1] == "s_nop", hex(address)
    summary = {
        "input": str(args.input),
        "input_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(),
        "output": str(args.output),
        "output_sha256": hashlib.sha256(bytes(data)).hexdigest(),
        "remove": sorted(remove),
        "loop": [hex(begin), hex(end)],
        "loop_mfma": len(mfma),
        "removed": {
            name: sum(1 for target in targets if target[1] == name)
            for name in sorted({target[1] for target in targets})
        },
        "removed_outside_loop": [hex(target[0]) + ":" + target[1] for target in targets if not begin <= target[0] < end],
        "same_instruction_addresses": True,
    }
    print(json.dumps(summary, indent=2))
    args.output.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
